import { Pipe, PipeTransform } from '@angular/core'
import { TenantRole } from '../shared'

/**
 * Pipe that transforms a TenantRole enum value to a human-readable label.
 */
@Pipe({
  name: 'roleLabel',
  standalone: true,
})
export class RoleLabelPipe implements PipeTransform {
  /**
   * Transforms a tenant role to its corresponding human-readable label.
   * @param role The tenant role to transform.
   * @returns The human-readable label for the role.
   */
  transform(role: TenantRole): string {
    const labels: Record<TenantRole, string> = {
      owner: 'Owner',
      admin: 'Admin',
      manager: 'Manager',
      user: 'User',
      viewer: 'Viewer',
    }
    return labels[role] || role
  }
}
