import { createSelector } from '@ngrx/store'
import { usersFeature } from './users.feature'

export const {
  selectUsersState,
  selectUsers,
  selectTotal,
  selectPage,
  selectLimit,
  selectTotalPages,
  selectLoading,
  selectError,
} = usersFeature

export const selectUsersList = createSelector(
  selectUsers,
  selectTotal,
  selectPage,
  selectLimit,
  selectTotalPages,
  (users, total, page, limit, totalPages) => ({
    users,
    total,
    page,
    limit,
    totalPages,
  })
)

export const selectUserById = (userId: string) =>
  createSelector(selectUsers, (users) => users.find((user) => user.id === userId))

export const selectActiveUsers = createSelector(selectUsers, (users) =>
  users.filter((user) => user.isActive)
)

export const selectInactiveUsers = createSelector(selectUsers, (users) =>
  users.filter((user) => !user.isActive)
)
