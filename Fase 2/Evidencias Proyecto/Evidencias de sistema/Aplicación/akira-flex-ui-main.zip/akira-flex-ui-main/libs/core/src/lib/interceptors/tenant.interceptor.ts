import { HttpInterceptorFn } from '@angular/common/http'
import { inject } from '@angular/core'
import { GlobalConfigService } from '../services/global-config.service'
import { getCookie, parseJwtPayload } from '../utils/cookie-utils'
import { APP_COOKIE_PREFIX } from '../shared'

/**
 * HTTP interceptor that adds tenant header for API requests.
 * In development, adds x-tenant-id header for tenant-specific requests.
 * In production, relies on subdomain routing.
 * @param req The HTTP request.
 * @param next The next handler in the chain.
 * @returns Observable of HTTP events.
 */
export const tenantInterceptor: HttpInterceptorFn = (req, next) => {
  const globalConfig = inject(GlobalConfigService)
  const cookiePrefix = inject(APP_COOKIE_PREFIX)

  const tenantSubdomain = globalConfig.getTenantSubdomain()
  const tokenKey = `${cookiePrefix}_access_token`

  let tenantId = null
  const token = getCookie(tokenKey)
  if (token) {
    try {
      const payload = parseJwtPayload(token)
      tenantId = payload?.['tenantId'] as string
    } catch (error) {
      console.warn('Failed to parse tenant ID from JWT:', error)
    }
  }

  let tenantReq = req

  if (tenantId) {
    tenantReq = req.clone({
      setHeaders: {
        'x-tenant-id': tenantId,
      },
    })
  } else if (tenantSubdomain) {
    tenantReq = req.clone({
      setHeaders: {
        'x-tenant-subdomain': tenantSubdomain,
      },
    })
  }

  return next(tenantReq)
}
