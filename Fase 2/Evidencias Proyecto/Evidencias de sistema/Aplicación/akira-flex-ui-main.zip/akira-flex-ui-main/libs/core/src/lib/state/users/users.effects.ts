import { Injectable, inject } from '@angular/core'
import { Actions, createEffect, ofType } from '@ngrx/effects'
import { of } from 'rxjs'
import { map, mergeMap, catchError, tap } from 'rxjs/operators'
import { MessageService } from 'primeng/api'
import { UserManagementService } from '../../services/user-management.service'
import { usersActions } from './users.actions'

/**
 * Effects for handling users-related side effects.
 */
@Injectable()
export class UsersEffects {
  private readonly actions$ = inject(Actions)
  private readonly userManagementService = inject(UserManagementService)
  private readonly messageService = inject(MessageService)

  loadUsers$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.loadUsers),
      mergeMap(() =>
        this.userManagementService.getUsers({}).pipe(
          map((response) =>
            usersActions.loadUsersSuccess({
              users: response.users,
              total: response.total,
              page: response.page,
              limit: response.limit,
              totalPages: response.totalPages,
            })
          ),
          catchError((error) =>
            of(usersActions.loadUsersFailure({ error: error.message || 'Failed to load users' }))
          )
        )
      )
    )
  )

  createUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.createUser),
      mergeMap(({ request }) =>
        this.userManagementService.createUser(request).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@userCreatedSuccess:User Created`,
              detail: $localize`:@@userCreatedSuccessDetail:User has been created successfully`,
            })
          }),
          map((user) => usersActions.createUserSuccess({ user })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@userCreatedError:Create User Failed`,
              detail: error.message || $localize`:@@userCreatedErrorDetail:Failed to create user`,
            })
            return of(
              usersActions.createUserFailure({ error: error.message || 'Failed to create user' })
            )
          })
        )
      )
    )
  )

  createTenantUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.createTenantUser),
      mergeMap(({ request }) =>
        this.userManagementService.createTenantUser(request).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@tenantUserCreatedSuccess:Tenant User Created`,
              detail: $localize`:@@tenantUserCreatedSuccessDetail:Tenant user has been created successfully`,
            })
          }),
          map((user) => usersActions.createTenantUserSuccess({ user })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@tenantUserCreatedError:Create Tenant User Failed`,
              detail:
                error.message ||
                $localize`:@@tenantUserCreatedErrorDetail:Failed to create tenant user`,
            })
            return of(
              usersActions.createTenantUserFailure({
                error: error.message || 'Failed to create tenant user',
              })
            )
          })
        )
      )
    )
  )

  updateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.updateUser),
      mergeMap(({ userId, request }) =>
        this.userManagementService.updateUser(userId, request).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@userUpdatedSuccess:User Updated`,
              detail: $localize`:@@userUpdatedSuccessDetail:User has been updated successfully`,
            })
          }),
          map((user) => usersActions.updateUserSuccess({ user })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@userUpdatedError:Update User Failed`,
              detail: error.message || $localize`:@@userUpdatedErrorDetail:Failed to update user`,
            })
            return of(
              usersActions.updateUserFailure({ error: error.message || 'Failed to update user' })
            )
          })
        )
      )
    )
  )

  deleteUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.deleteUser),
      mergeMap(({ userId }) =>
        this.userManagementService.deleteUser(userId).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@userDeletedSuccess:User Deleted`,
              detail: $localize`:@@userDeletedSuccessDetail:User has been deleted successfully`,
            })
          }),
          map(() => usersActions.deleteUserSuccess({ userId })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@userDeletedError:Delete User Failed`,
              detail: error.message || $localize`:@@userDeletedErrorDetail:Failed to delete user`,
            })
            return of(
              usersActions.deleteUserFailure({ error: error.message || 'Failed to delete user' })
            )
          })
        )
      )
    )
  )

  activateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.activateUser),
      mergeMap(({ userId }) =>
        this.userManagementService.activateUser(userId).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@userActivatedSuccess:User Activated`,
              detail: $localize`:@@userActivatedSuccessDetail:User has been activated successfully`,
            })
          }),
          map((user) => usersActions.activateUserSuccess({ user })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@userActivatedError:Activate User Failed`,
              detail:
                error.message || $localize`:@@userActivatedErrorDetail:Failed to activate user`,
            })
            return of(
              usersActions.activateUserFailure({
                error: error.message || 'Failed to activate user',
              })
            )
          })
        )
      )
    )
  )

  deactivateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(usersActions.deactivateUser),
      mergeMap(({ userId }) =>
        this.userManagementService.deactivateUser(userId).pipe(
          tap(() => {
            this.messageService.add({
              severity: 'success',
              summary: $localize`:@@userDeactivatedSuccess:User Deactivated`,
              detail: $localize`:@@userDeactivatedSuccessDetail:User has been deactivated successfully`,
            })
          }),
          map((user) => usersActions.deactivateUserSuccess({ user })),
          catchError((error) => {
            this.messageService.add({
              severity: 'error',
              summary: $localize`:@@userDeactivatedError:Deactivate User Failed`,
              detail:
                error.message || $localize`:@@userDeactivatedErrorDetail:Failed to deactivate user`,
            })
            return of(
              usersActions.deactivateUserFailure({
                error: error.message || 'Failed to deactivate user',
              })
            )
          })
        )
      )
    )
  )
}
