import { createSelector } from '@ngrx/store'
import { userProfileFeature } from './user-profile.feature'

export const selectUserProfileState = userProfileFeature.selectUserProfileState
export const selectUserProfile = userProfileFeature.selectProfile
export const selectUserProfileLoading = userProfileFeature.selectLoading
export const selectUserProfileError = userProfileFeature.selectError
export const selectIsUserProfileLoaded = createSelector(selectUserProfile, (profile) => !!profile)
