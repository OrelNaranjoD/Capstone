import { InjectionToken } from '@angular/core'

/**
 * Injection token for application-specific cookie prefix.
 * Used to separate authentication sessions between different applications.
 */
export const APP_COOKIE_PREFIX = new InjectionToken<string>('APP_COOKIE_PREFIX')
