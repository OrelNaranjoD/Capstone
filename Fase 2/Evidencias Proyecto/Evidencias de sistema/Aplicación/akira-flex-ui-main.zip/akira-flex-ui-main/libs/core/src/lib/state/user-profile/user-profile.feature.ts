import { createFeature, createReducer, on } from '@ngrx/store'
import type { UserProfileState } from '../state.types'
import type { User } from '../../shared'
import { UserProfileActions } from './user-profile.actions'

/**
 * Initial state for user profile.
 */
export const initialUserProfileState: UserProfileState = {
  profile: null,
  loading: false,
  error: null,
}

/**
 * User profile feature reducer.
 */
export const userProfileFeature = createFeature({
  name: 'userProfile',
  reducer: createReducer(
    initialUserProfileState,

    on(UserProfileActions.loadProfileSuccess, (state, { profile }) => ({
      ...state,
      profile,
      loading: false,
      error: null,
    })),

    on(UserProfileActions.updateProfile, (state, { profile }) => ({
      ...state,
      profile: state.profile ? { ...state.profile, ...profile } : (profile as User),
    })),

    on(UserProfileActions.setLoading, (state, { loading }) => ({
      ...state,
      loading,
    })),

    on(UserProfileActions.setError, (state, { error }) => ({
      ...state,
      error,
      loading: false,
    })),

    on(UserProfileActions.clearProfile, (state) => ({
      ...state,
      profile: null,
      loading: false,
      error: null,
    }))
  ),
})
