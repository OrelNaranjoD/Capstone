import '../test'
import { TestBed } from '@angular/core/testing'
import { Store } from '@ngrx/store'
import { of } from 'rxjs'
import { vi } from 'vitest'
import { PermissionService } from '@core'
import type { User } from '@core'
import type { PermissionCode } from '@core'

describe('PermissionService', () => {
  let service: PermissionService
  let store: { select: ReturnType<typeof vi.fn>; dispatch: ReturnType<typeof vi.fn> }

  const mockUser: User = {
    id: '1',
    email: 'test@example.com',
    firstName: 'Test',
    lastName: 'User',
    phone: '+1234567890',
    globalRole: 'user',
    tenantRoles: [
      {
        tenantId: 'tenant-1',
        role: 'user',
        assignedAt: new Date('2023-01-01T00:00:00Z'),
        assignedBy: 'system',
        assignedByRole: 'super_admin',
      },
    ],
    permissions: ['USER_VIEW', 'USER_CREATE'],
    roles: ['user'],
    createdAt: new Date('2023-01-01T00:00:00Z'),
    updatedAt: new Date('2023-01-01T00:00:00Z'),
  }

  const mockAdminUser: User = {
    id: '2',
    email: 'admin@example.com',
    firstName: 'Admin',
    lastName: 'User',
    phone: '+1234567890',
    globalRole: 'super_admin',
    tenantRoles: [
      {
        tenantId: 'tenant-1',
        role: 'admin',
        assignedAt: new Date('2023-01-01T00:00:00Z'),
        assignedBy: 'system',
        assignedByRole: 'super_admin',
      },
    ],
    permissions: ['USER_VIEW', 'USER_CREATE', 'USER_UPDATE', 'USER_DELETE', 'USER_VIEW_ALL'],
    roles: ['admin', 'owner'],
    createdAt: new Date('2023-01-01T00:00:00Z'),
    updatedAt: new Date('2023-01-01T00:00:00Z'),
  }

  const mockOwnerUser: User = {
    id: '3',
    email: 'owner@example.com',
    firstName: 'Owner',
    lastName: 'User',
    phone: '+1234567890',
    globalRole: 'super_admin',
    tenantRoles: [
      {
        tenantId: 'tenant-1',
        role: 'owner',
        assignedAt: new Date('2023-01-01T00:00:00Z'),
        assignedBy: 'system',
        assignedByRole: 'super_admin',
      },
    ],
    permissions: ['USER_VIEW_ALL', 'ROLE_UPDATE', 'TENANT_UPDATE', 'AUDIT_VIEW'],
    roles: ['OWNER'],
    createdAt: new Date('2023-01-01T00:00:00Z'),
    updatedAt: new Date('2023-01-01T00:00:00Z'),
  }

  beforeEach(() => {
    const storeSpy = {
      select: vi.fn(),
      dispatch: vi.fn(),
    }

    storeSpy.select.mockReturnValue(of(mockUser))

    TestBed.configureTestingModule({
      providers: [PermissionService, { provide: Store, useValue: storeSpy }],
    })

    service = TestBed.inject(PermissionService)
    store = storeSpy
  })

  describe('Initialization', () => {
    it('should be created', () => {
      expect(service).toBeTruthy()
    })

    it('should subscribe to user profile on initialization', () => {
      expect(store.select).toHaveBeenCalled()
    })
  })

  describe('hasPermission', () => {
    beforeEach(() => {
      service['updatePermissionsFromUser'](mockUser)
    })

    it('should return true for permissions the user has', () => {
      expect(service.hasPermission('USER_VIEW')).toBe(true)
      expect(service.hasPermission('USER_CREATE')).toBe(true)
    })

    it('should return false for permissions the user does not have', () => {
      expect(service.hasPermission('USER_DELETE')).toBe(false)
      expect(service.hasPermission('USER_UPDATE')).toBe(false)
      expect(service.hasPermission('USER_VIEW_ALL')).toBe(false)
    })

    it('should return false when user has no permissions', () => {
      service['updatePermissionsFromUser'](null)
      expect(service.hasPermission('USER_VIEW')).toBe(false)
    })
  })

  describe('hasAnyPermission', () => {
    beforeEach(() => {
      service['updatePermissionsFromUser'](mockUser)
    })

    it('should return true when user has at least one of the specified permissions', () => {
      const permissions: PermissionCode[] = [
        'USER_VIEW' as unknown as PermissionCode,
        'USER_DELETE' as unknown as PermissionCode,
      ]
      expect(service.hasAnyPermission(permissions)).toBe(true)
    })

    it('should return false when user has none of the specified permissions', () => {
      const permissions: PermissionCode[] = [
        'USER_DELETE' as unknown as PermissionCode,
        'USER_UPDATE' as unknown as PermissionCode,
      ]
      expect(service.hasAnyPermission(permissions)).toBe(false)
    })

    it('should return false when user has no permissions', () => {
      service['updatePermissionsFromUser'](null)
      const permissions: PermissionCode[] = ['USER_VIEW' as unknown as PermissionCode]
      expect(service.hasAllPermissions(permissions)).toBe(false)
    })

    it('should return false for empty permissions array', () => {
      expect(service.hasAnyPermission([])).toBe(false)
    })

    it('should return false when user has no permissions', () => {
      service['updatePermissionsFromUser'](null)
      const permissions: PermissionCode[] = [
        'USER_VIEW' as unknown as PermissionCode,
        'USER_CREATE' as unknown as PermissionCode,
      ]
      expect(service.hasAnyPermission(permissions)).toBe(false)
    })
  })

  describe('hasAllPermissions', () => {
    beforeEach(() => {
      service['updatePermissionsFromUser'](mockUser)
    })

    it('should return true when user has all specified permissions', () => {
      const permissions: PermissionCode[] = [
        'USER_VIEW' as unknown as PermissionCode,
        'USER_CREATE' as unknown as PermissionCode,
      ]
      expect(service.hasAllPermissions(permissions)).toBe(true)
    })

    it('should return false when user is missing at least one permission', () => {
      const permissions: PermissionCode[] = [
        'USER_VIEW' as unknown as PermissionCode,
        'USER_CREATE' as unknown as PermissionCode,
        'USER_DELETE' as unknown as PermissionCode,
      ]
      expect(service.hasAllPermissions(permissions)).toBe(false)
    })

    it('should return true for empty permissions array', () => {
      expect(service.hasAllPermissions([])).toBe(true)
    })

    it('should return false when user has no permissions', () => {
      service['updatePermissionsFromUser'](null)
      const permissions: PermissionCode[] = ['USER_VIEW' as unknown as PermissionCode]
      expect(service.hasAllPermissions(permissions)).toBe(false)
    })
  })

  describe('hasRole', () => {
    beforeEach(() => {
      service['updatePermissionsFromUser'](mockUser)
    })

    it('should return true for roles the user has (case insensitive)', () => {
      expect(service.hasRole('user')).toBe(true)
      expect(service.hasRole('USER')).toBe(true)
    })

    it('should return false for roles the user does not have', () => {
      expect(service.hasRole('owner')).toBe(false)
      expect(service.hasRole('super_admin')).toBe(false)
    })

    it('should return false when user has no roles', () => {
      service['updatePermissionsFromUser'](null)
      expect(service.hasRole('user')).toBe(false)
    })
  })

  describe('Computed permission signals', () => {
    it('should compute canCreateUsers based on USER_CREATE permission', () => {
      service['updatePermissionsFromUser'](mockUser)
      expect(service.canCreateUsers()).toBe(true)

      service['updatePermissionsFromUser'](null)
      expect(service.canCreateUsers()).toBe(false)
    })

    it('should compute canViewAllUsers based on USER_VIEW_ALL permission', () => {
      service['updatePermissionsFromUser'](mockAdminUser)
      expect(service.canViewAllUsers()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.canViewAllUsers()).toBe(false)
    })

    it('should compute canManageRoles based on ROLE_UPDATE permission', () => {
      service['updatePermissionsFromUser'](mockOwnerUser)
      expect(service.canManageRoles()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.canManageRoles()).toBe(false)
    })

    it('should compute canViewAudit based on AUDIT_VIEW permission', () => {
      service['updatePermissionsFromUser'](mockOwnerUser)
      expect(service.canViewAudit()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.canViewAudit()).toBe(false)
    })

    it('should compute canManageTenants based on TENANT_UPDATE permission', () => {
      service['updatePermissionsFromUser'](mockOwnerUser)
      expect(service.canManageTenants()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.canManageTenants()).toBe(false)
    })
  })

  describe('Readonly signals', () => {
    it('should expose userPermissions as readonly signal', () => {
      service['updatePermissionsFromUser'](mockUser)
      expect(service.userPermissions()).toEqual(['USER_VIEW', 'USER_CREATE'])

      service['updatePermissionsFromUser'](null)
      expect(service.userPermissions()).toEqual([])
    })

    it('should expose userRoles as readonly signal', () => {
      service['updatePermissionsFromUser'](mockUser)
      expect(service.userRoles()).toEqual(['user'])

      service['updatePermissionsFromUser'](null)
      expect(service.userRoles()).toEqual([])
    })

    it('should expose isOwner as readonly signal', () => {
      service['updatePermissionsFromUser'](mockOwnerUser)
      expect(service.isOwner()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.isOwner()).toBe(false)
    })

    it('should expose isAdmin as readonly signal', () => {
      service['updatePermissionsFromUser'](mockAdminUser)
      expect(service.isAdmin()).toBe(true)

      service['updatePermissionsFromUser'](mockUser)
      expect(service.isAdmin()).toBe(false)
    })
  })

  describe('updatePermissionsFromUser', () => {
    it('should clear permissions and roles when user is null', () => {
      service['updatePermissionsFromUser'](mockUser)
      expect(service.userPermissions()).toEqual(['USER_VIEW', 'USER_CREATE'])
      expect(service.userRoles()).toEqual(['user'])
      expect(service.isOwner()).toBe(false)
      expect(service.isAdmin()).toBe(false)

      service['updatePermissionsFromUser'](null)
      expect(service.userPermissions()).toEqual([])
      expect(service.userRoles()).toEqual([])
      expect(service.isOwner()).toBe(false)
      expect(service.isAdmin()).toBe(false)
    })

    it('should update permissions from user object', () => {
      service['updatePermissionsFromUser'](mockUser)
      expect(service.userPermissions()).toEqual(['USER_VIEW', 'USER_CREATE'])
    })

    it('should normalize roles to lowercase', () => {
      const userWithMixedCaseRoles: User = {
        ...mockUser,
        roles: ['USER', 'ADMIN', 'Owner'],
      }

      service['updatePermissionsFromUser'](userWithMixedCaseRoles)
      expect(service.userRoles()).toEqual(['user', 'admin', 'owner'])
    })

    it('should handle empty permissions array', () => {
      const userWithNoPermissions: User = {
        ...mockUser,
        permissions: [],
      }

      service['updatePermissionsFromUser'](userWithNoPermissions)
      expect(service.userPermissions()).toEqual([])
    })

    it('should handle undefined permissions', () => {
      const userWithUndefinedPermissions: User = {
        ...mockUser,
        permissions: undefined,
      }

      service['updatePermissionsFromUser'](userWithUndefinedPermissions)
      expect(service.userPermissions()).toEqual([])
    })

    it('should handle empty roles array', () => {
      const userWithNoRoles: User = {
        ...mockUser,
        roles: [],
      }

      service['updatePermissionsFromUser'](userWithNoRoles)
      expect(service.userRoles()).toEqual([])
    })

    it('should handle undefined roles', () => {
      const userWithUndefinedRoles: User = {
        ...mockUser,
        roles: undefined,
      }

      service['updatePermissionsFromUser'](userWithUndefinedRoles)
      expect(service.userRoles()).toEqual([])
    })

    it('should set isOwner to true when user has owner role', () => {
      service['updatePermissionsFromUser'](mockOwnerUser)
      expect(service.isOwner()).toBe(true)
    })

    it('should set isAdmin to true when user has admin role', () => {
      service['updatePermissionsFromUser'](mockAdminUser)
      expect(service.isAdmin()).toBe(true)
    })

    it('should set isAdmin to true when user has platform-admin role', () => {
      const userWithPlatformAdmin: User = {
        ...mockUser,
        roles: ['platform-admin'],
      }

      service['updatePermissionsFromUser'](userWithPlatformAdmin)
      expect(service.isAdmin()).toBe(true)
    })

    it('should handle non-string roles by converting to "user"', () => {
      const userWithInvalidRoles: User = {
        ...mockUser,
        roles: [
          'valid-role',
          123 as unknown as string,
          null as unknown as string,
          undefined as unknown as string,
        ],
      }

      service['updatePermissionsFromUser'](userWithInvalidRoles)
      expect(service.userRoles()).toEqual(['valid-role', 'user', 'user', 'user'])
    })
  })

  describe('Permission types', () => {
    it('should include all expected permission constants', () => {
      const expectedPermissions: PermissionCode[] = [
        'PERMISSION_CREATE' as unknown as PermissionCode,
        'PERMISSION_VIEW_ALL' as unknown as PermissionCode,
        'PERMISSION_UPDATE' as unknown as PermissionCode,
        'PERMISSION_DELETE' as unknown as PermissionCode,
        'USER_ROLE_VIEW_OWN' as unknown as PermissionCode,
        'USER_VIEW' as unknown as PermissionCode,
        'USER_CREATE' as unknown as PermissionCode,
        'USER_UPDATE' as unknown as PermissionCode,
        'USER_DELETE' as unknown as PermissionCode,
        'AUDIT_VIEW_ALL' as unknown as PermissionCode,
        'AUDIT_VIEW' as unknown as PermissionCode,
        'AUDIT_TENANT_VIEW' as unknown as PermissionCode,
        'ROLE_VIEW_ALL' as unknown as PermissionCode,
        'ROLE_VIEW_OWN' as unknown as PermissionCode,
        'ROLE_CREATE' as unknown as PermissionCode,
        'ROLE_UPDATE' as unknown as PermissionCode,
        'ROLE_DELETE' as unknown as PermissionCode,
        'AUTH_REGISTER' as unknown as PermissionCode,
        'TENANT_CREATE' as unknown as PermissionCode,
        'TENANT_UPDATE' as unknown as PermissionCode,
        'TENANT_DISABLE' as unknown as PermissionCode,
        'TENANT_DELETE' as unknown as PermissionCode,
        'TENANT_RESTORE' as unknown as PermissionCode,
        'TENANT_VIEW' as unknown as PermissionCode,
        'TENANT_VIEW_ALL' as unknown as PermissionCode,
        'USER_VIEW_ALL' as unknown as PermissionCode,
        'AUTH_LOGIN' as unknown as PermissionCode,
        'ROLE_VIEW' as unknown as PermissionCode,
        'PERMISSION_VIEW' as unknown as PermissionCode,
      ]

      expectedPermissions.forEach((permission) => {
        expect(typeof permission).toBe('string')
      })
    })
  })
})
