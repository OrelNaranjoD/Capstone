import { inject } from '@angular/core'
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http'
import { catchError, switchMap, throwError } from 'rxjs'
import { AuthService } from '../services/auth.service'

/**
 * HTTP interceptor function that handles automatic token refresh on 401 errors.
 * @param req The outgoing HTTP request.
 * @param next The next interceptor in the chain.
 * @returns Observable of HTTP events.
 */
export const refreshTokenInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService)

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401 && authService.isAuthenticated()) {
        const authEndpoints = [
          '/auth/login',
          '/auth/refresh-token',
          '/auth/logout',
          '/auth/register',
          '/auth/verify-email',
          '/auth/resend-verification',
        ]

        const isAuthEndpoint = authEndpoints.some((endpoint) => req.url.includes(endpoint))

        if (isAuthEndpoint) {
          console.log('Auth endpoint failed with 401, logging out:', req.url)
          authService.logout()
          return throwError(() => error)
        }

        console.log('Request failed with 401, attempting token refresh:', req.url)

        return authService.refreshToken().pipe(
          switchMap(() => {
            console.log('Token refreshed successfully, retrying request:', req.url)
            const authReq = req.clone({
              headers: authService.getAuthHeaders(),
            })
            return next(authReq)
          }),
          catchError((refreshError) => {
            console.log('Token refresh failed, logging out:', refreshError)
            authService.logout()
            return throwError(() => refreshError)
          })
        )
      }
      return throwError(() => error)
    })
  )
}
