﻿import { Injectable, signal, computed, inject } from '@angular/core'
import { Store } from '@ngrx/store'
import type { User, PermissionCode } from '../shared'
import { selectUserProfile } from '../state'

/**
 * Service for managing user permissions and role-based access control.
 * Provides reactive permission checking without exposing sensitive data.
 */
@Injectable({
  providedIn: 'root',
})
export class PermissionService {
  private readonly store = inject(Store)
  private readonly _userPermissions = signal<PermissionCode[]>([])
  private readonly _userRoles = signal<string[]>([])
  private readonly _isOwner = signal(false)
  private readonly _isAdmin = signal(false)

  readonly userPermissions = this._userPermissions.asReadonly()
  readonly userRoles = this._userRoles.asReadonly()
  readonly isOwner = this._isOwner.asReadonly()
  readonly isAdmin = this._isAdmin.asReadonly()

  readonly canCreateUsers = computed(() => this.hasPermission('USER_CREATE'))
  readonly canViewAllUsers = computed(() => this.hasPermission('USER_VIEW_ALL'))
  readonly canManageRoles = computed(() => this.hasPermission('ROLE_UPDATE'))
  readonly canViewAudit = computed(() => this.hasPermission('AUDIT_VIEW'))
  readonly canManageTenants = computed(() => this.hasPermission('TENANT_UPDATE'))

  constructor() {
    this.store.select(selectUserProfile).subscribe((user) => {
      this.updatePermissionsFromUser(user)
    })
  }

  /**
   * Check if user has a specific permission.
   * @param permission The permission to check.
   * @returns True if user has the permission.
   */
  hasPermission(permission: PermissionCode): boolean {
    return this._userPermissions().includes(permission)
  }

  /**
   * Check if user has any of the specified permissions.
   * @param permissions Array of permissions to check.
   * @returns True if user has any of the permissions.
   */
  hasAnyPermission(permissions: PermissionCode[]): boolean {
    return permissions.some((permission) => this.hasPermission(permission))
  }

  /**
   * Check if user has all of the specified permissions.
   * @param permissions Array of permissions to check.
   * @returns True if user has all permissions.
   */
  hasAllPermissions(permissions: PermissionCode[]): boolean {
    return permissions.every((permission) => this.hasPermission(permission))
  }

  /**
   * Check if user has a specific role.
   * @param role The role to check.
   * @returns True if user has the role.
   */
  hasRole(role: string): boolean {
    return this._userRoles().includes(role.toLowerCase())
  }

  /**
   * Update permissions based on user data.
   * This method extracts permissions from user object without storing sensitive data.
   * @param user The user object containing permissions and roles.
   */
  private updatePermissionsFromUser(user: User | null): void {
    if (!user) {
      this._userPermissions.set([])
      this._userRoles.set([])
      this._isOwner.set(false)
      this._isAdmin.set(false)
      return
    }

    const permissions = user.permissions || []
    const roles = user.roles || []

    const normalizedRoles = roles.map((role: string) =>
      typeof role === 'string' ? role.toLowerCase() : 'user'
    )

    this._userPermissions.set(permissions as PermissionCode[])
    this._userRoles.set(normalizedRoles)
    this._isOwner.set(normalizedRoles.includes('owner'))
    this._isAdmin.set(
      normalizedRoles.includes('admin') || normalizedRoles.includes('platform-admin')
    )
  }
}
