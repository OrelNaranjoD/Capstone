﻿import { Injectable, inject, signal, computed } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Router } from '@angular/router'
import { Observable, tap, catchError, throwError, switchMap, map, of, ReplaySubject } from 'rxjs'
import { isPlatformBrowser } from '@angular/common'
import { PLATFORM_ID } from '@angular/core'
import { Store } from '@ngrx/store'
import {
  LoginRequest,
  RegisterRequest,
  RegisterResponse,
  VerifyEmailRequest,
  ResendVerificationRequest,
  AuthTokenResponse,
  LoginResponse,
  User,
  BasicUser,
  TenantRoleAssignment,
  TenantRole,
  PlatformRole,
  ActivateUserRequest,
  APP_COOKIE_PREFIX,
} from '../shared'
import {
  getCookie,
  setSecureCookie,
  removeCookie,
  getJwtExpiration,
  getDaysUntilExpiration,
  parseJwtPayload,
} from '../utils/cookie-utils'

import { GlobalConfigService } from './global-config.service'
import {
  AuthActions,
  UserProfileActions,
  selectCurrentUser,
  selectIsAuthenticated,
  selectAuthInitialized,
} from '../state'

/**
 * Global authentication service for managing user sessions.
 */
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly http = inject(HttpClient)
  private readonly router = inject(Router)
  private readonly platformId = inject(PLATFORM_ID)
  private readonly globalConfig = inject(GlobalConfigService)
  private readonly cookiePrefix = inject(APP_COOKIE_PREFIX)
  private readonly store = inject(Store)
  private readonly TOKEN_KEY = `${this.cookiePrefix}_access_token`
  private readonly REFRESH_TOKEN_KEY = `${this.cookiePrefix}_refresh_token`
  private readonly _isAuthenticated = signal(false)
  private readonly _currentUser = signal<User | null>(null)
  private readonly _isLoading = signal(true)
  private readonly _isInitialized = signal(false)
  private readonly _isRefreshing = signal(false)
  private readonly _pendingVerification = signal<{ email: string; password: string } | null>(null)
  private readonly _refreshTokenSubject = new ReplaySubject<AuthTokenResponse | null>(1)
  private _isInitializing = false
  readonly isAuthenticated = this.store.selectSignal(selectIsAuthenticated)
  readonly currentUser = this.store.selectSignal(selectCurrentUser)
  readonly isInitialized = this.store.selectSignal(selectAuthInitialized)
  readonly isLoading = computed(() => this._isLoading())
  readonly isRefreshing = computed(() => this._isRefreshing())
  readonly pendingVerification = computed(() => this._pendingVerification())

  /**
   * Initialize the authentication service after app configuration is complete.
   * This should be called from the app initializer.
   */
  initialize(): void {
    this.initializeAuthState()
  }

  /**
   * Initialize authentication state from stored tokens.
   */
  private initializeAuthState(): void {
    if (this._isInitializing) {
      console.log('Auth initialization already in progress, skipping')
      return
    }

    this._isInitializing = true

    if (!isPlatformBrowser(this.platformId)) {
      this._isLoading.set(false)
      this._isInitialized.set(true)
      this._isInitializing = false
      this.store.dispatch(AuthActions.initializeAuth())
      return
    }

    const token = getCookie(this.TOKEN_KEY)

    if (token) {
      const expTimestamp = getJwtExpiration(token)
      const isTokenExpired = expTimestamp ? expTimestamp * 1000 < Date.now() : true

      if (isTokenExpired) {
        const expiredRecently = expTimestamp
          ? Date.now() - expTimestamp * 1000 < 24 * 60 * 60 * 1000
          : false

        if (expiredRecently && this.shouldRememberUser()) {
          this.attemptInitialRefresh()
          return
        } else {
          this.clearStoredAuth()
          if (!this.shouldRememberUser()) {
            this.clearRememberPreference()
          }
          this.store.dispatch(AuthActions.clearAuth())
          this._isLoading.set(false)
          this._isInitialized.set(true)
          this._isInitializing = false
          this.store.dispatch(AuthActions.initializeAuth())
          return
        }
      }

      const storedProfile = localStorage.getItem(`${this.cookiePrefix}_user_profile`)
      let user: User | null = null
      if (storedProfile) {
        try {
          user = JSON.parse(storedProfile)
        } catch (e) {
          console.warn('Failed to parse stored user profile', e)
        }
      }

      if (user) {
        const basicUser = this.createBasicUser(user)
        this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
        this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
        this._isLoading.set(false)
        this._isInitialized.set(true)
        this._isInitializing = false
        this.store.dispatch(AuthActions.initializeAuth())

        this.refreshUser().subscribe({
          next: (freshUser: User) => {
            const basicUser = this.createBasicUser(freshUser)
            this.store.dispatch(AuthActions.updateUser({ user: basicUser }))
            this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: freshUser }))
            localStorage.setItem(`${this.cookiePrefix}_user_profile`, JSON.stringify(freshUser))
          },
          error: (error) => {
            console.log('Failed to refresh user profile in background:', error)
          },
        })
      } else {
        this.refreshUser().subscribe({
          next: (freshUser) => {
            const basicUser = this.createBasicUser(freshUser)
            this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
            this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: freshUser }))
            localStorage.setItem(`${this.cookiePrefix}_user_profile`, JSON.stringify(freshUser))
            this._isLoading.set(false)
            this._isInitialized.set(true)
            this._isInitializing = false
            this.store.dispatch(AuthActions.initializeAuth())
          },
          error: (error) => {
            console.log('Failed to fetch user profile, falling back to token payload:', error)
            const payload = parseJwtPayload(token)
            if (payload) {
              const isSuperAdmin = payload['isSuperAdmin'] as boolean
              const user: User = {
                id: payload['sub'] as string,
                email: payload['email'] as string,
                firstName: (payload['firstName'] as string) || '',
                lastName: (payload['lastName'] as string) || '',
                phone: payload['phone'] as string,
                globalRole: isSuperAdmin ? 'super_admin' : 'user',
                isSuperAdmin,
                tenantRoles: [],
                onboardingCompleted: (payload['onboardingCompleted'] as boolean) || false,
                isActive: (payload['active'] as boolean) || true,
                createdAt: (payload['createdAt'] as string)
                  ? new Date(payload['createdAt'] as string)
                  : new Date(),
                updatedAt: (payload['updatedAt'] as string)
                  ? new Date(payload['updatedAt'] as string)
                  : new Date(),
              }
              const basicUser = this.createBasicUser(user)
              this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
              this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
              this._isLoading.set(false)
              this._isInitialized.set(true)
              this._isInitializing = false
              this.store.dispatch(AuthActions.initializeAuth())
            } else {
              console.log('Failed to parse token payload, clearing auth')
              this.clearStoredAuth()
              this.store.dispatch(AuthActions.clearAuth())
              this._isLoading.set(false)
              this._isInitialized.set(true)
              this._isInitializing = false
              this.store.dispatch(AuthActions.initializeAuth())
            }
          },
        })
      }
    } else {
      this._isLoading.set(false)
      this._isInitialized.set(true)
      this._isInitializing = false
      this.store.dispatch(AuthActions.initializeAuth())
    }
  }

  /**
   * Login user with credentials using the API.
   * @param credentials The login credentials.
   * @returns Observable that emits LoginResponse on success.
   */
  login(credentials: LoginRequest): Observable<LoginResponse> {
    this._isLoading.set(true)

    if (isPlatformBrowser(this.platformId) && credentials.remember !== undefined) {
      localStorage.setItem('auth_remember_me', credentials.remember.toString())
    }

    return this.http
      .post<AuthTokenResponse>(this.globalConfig.apiEndpoints.auth.login, credentials, {
        withCredentials: true,
      })
      .pipe(
        switchMap((tokenResponse: AuthTokenResponse) => {
          if (!tokenResponse || !tokenResponse.accessToken) {
            console.warn('Login response missing required fields:', tokenResponse)
            throw new Error('Invalid login response: missing access token')
          }

          if (isPlatformBrowser(this.platformId)) {
            const expTimestamp = getJwtExpiration(tokenResponse.accessToken)
            let daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7

            if (credentials.remember === false) {
              daysUntilExpiration = Math.min(daysUntilExpiration, 1)
            }

            setSecureCookie(this.TOKEN_KEY, tokenResponse.accessToken, {
              days: daysUntilExpiration,
              secure: false,
              sameSite: 'Strict',
            })
          }

          return this.http
            .get<Record<string, unknown>>(this.globalConfig.apiEndpoints.auth.profile, {
              headers: this.getAuthHeaders(),
            })
            .pipe(
              map((backendUser: Record<string, unknown>) => {
                const user = this.mapBackendUserToUser(backendUser)
                const payload = parseJwtPayload(tokenResponse.accessToken)
                if (payload) {
                  const isSuperAdmin = payload['isSuperAdmin'] as boolean
                  user.globalRole = isSuperAdmin ? 'super_admin' : 'user'
                }

                if (user.status === 'pending_verification') {
                  return {
                    accessToken: tokenResponse.accessToken,
                    user,
                    requiresVerification: true,
                  } as LoginResponse
                }

                return {
                  accessToken: tokenResponse.accessToken,
                  user,
                } as LoginResponse
              }),
              catchError((error) => {
                console.log(
                  'Profile endpoint failed, using token payload for landing users:',
                  error
                )
                const payload = parseJwtPayload(tokenResponse.accessToken)
                if (payload) {
                  const isSuperAdmin = payload['isSuperAdmin'] as boolean
                  const user: User = {
                    id: payload['sub'] as string,
                    email: payload['email'] as string,
                    firstName: (payload['firstName'] as string) || '',
                    lastName: (payload['lastName'] as string) || '',
                    phone: payload['phone'] as string,
                    globalRole: isSuperAdmin ? 'super_admin' : 'user',
                    isSuperAdmin,
                    tenantRoles: [],
                    onboardingCompleted: (payload['onboardingCompleted'] as boolean) || false,
                    isActive: (payload['active'] as boolean) || true,
                    createdAt: (payload['createdAt'] as string)
                      ? new Date(payload['createdAt'] as string)
                      : new Date(),
                    updatedAt: (payload['updatedAt'] as string)
                      ? new Date(payload['updatedAt'] as string)
                      : new Date(),
                  }

                  return of({
                    accessToken: tokenResponse.accessToken,
                    user,
                  } as LoginResponse)
                } else {
                  throw new Error('Unable to extract user data from token')
                }
              })
            )
        }),
        tap((response) => {
          if (response.requiresVerification) {
            this._pendingVerification.set({
              email: credentials.email,
              password: credentials.password,
            })
            this._isLoading.set(false)
            return
          }

          this.setSession(response)
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Attempt to refresh token on app initialization if current token is expired.
   * Only attempts refresh if user chose "remember me" during login.
   */
  private attemptInitialRefresh(): void {
    if (!this.shouldRememberUser()) {
      this.clearStoredAuth()
      this.clearRememberPreference()
      this.store.dispatch(AuthActions.clearAuth())
      this._isLoading.set(false)
      this._isInitialized.set(true)
      this._isInitializing = false
      this.store.dispatch(AuthActions.initializeAuth())
      return
    }

    this.refreshToken().subscribe({
      next: () => {
        this.refreshUser().subscribe({
          next: (user) => {
            const basicUser = this.createBasicUser(user)
            this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
            this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
            this._isLoading.set(false)
            this._isInitialized.set(true)
            this._isInitializing = false
            this.store.dispatch(AuthActions.initializeAuth())
          },
          error: (error) => {
            console.log('Failed to refresh user profile after token refresh:', error)
            this.clearStoredAuth()
            this.store.dispatch(AuthActions.clearAuth())
            this._isLoading.set(false)
            this._isInitialized.set(true)
            this._isInitializing = false
            this.store.dispatch(AuthActions.initializeAuth())
          },
        })
      },
      error: (error) => {
        console.log('Initial token refresh failed:', error)
        this.clearStoredAuth()
        this.clearRememberPreference()
        this.store.dispatch(AuthActions.clearAuth())
        this._isLoading.set(false)
        this._isInitialized.set(true)
        this._isInitializing = false
        this.store.dispatch(AuthActions.initializeAuth())
      },
    })
  }

  /**
   * Set mock user session for testing.
   * @param response Mock auth token response.
   * @param user Mock user data.
   */
  private setMockSession(response: AuthTokenResponse, user: User): void {
    if (!isPlatformBrowser(this.platformId)) return

    setSecureCookie(this.TOKEN_KEY, response.accessToken, {
      days: 7,
      secure: false,
      sameSite: 'Strict',
    })

    const basicUser = this.createBasicUser(user)
    this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
    this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
  }

  /**
   * Set pending verification state for email verification flow.
   * @param email The user's email address.
   * @param password The user's password.
   */
  setPendingVerification(email: string, password: string): void {
    this._pendingVerification.set({ email, password })
  }

  /**
   * Get authorization headers for HTTP requests.
   * @returns HttpHeaders with authorization token.
   */
  getAuthHeaders(): HttpHeaders {
    const token = this.getToken()
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders()
  }

  /**
   * Get headers with authorization and tenant identification.
   * @returns HttpHeaders with authorization token and tenant ID.
   */
  getAuthHeadersWithTenant(): HttpHeaders {
    const tenantId = this.getCurrentTenantId()
    const token = this.getToken()

    if (token) {
      return new HttpHeaders({
        Authorization: `Bearer ${token}`,
        'x-tenant-id': tenantId,
      })
    } else {
      return new HttpHeaders({
        'x-tenant-id': tenantId,
      })
    }
  }

  /**
   * Get headers with authorization, tenant ID and tenant subdomain.
   * @returns HttpHeaders with authorization token, tenant ID and subdomain.
   */
  getAuthHeadersWithTenantAndSubdomain(): HttpHeaders {
    const tenantId = this.getCurrentTenantId()
    const tenantSubdomain = this.globalConfig.getTenantSubdomain() || ''
    const token = this.getToken()

    if (token) {
      return new HttpHeaders({
        Authorization: `Bearer ${token}`,
        'x-tenant-id': tenantId,
        'x-tenant-subdomain': tenantSubdomain,
      })
    } else {
      return new HttpHeaders({
        'x-tenant-id': tenantId,
        'x-tenant-subdomain': tenantSubdomain,
      })
    }
  }

  /**
   * Refresh user data from server.
   * @returns Observable with updated user data.
   */
  refreshUser(): Observable<LoginResponse['user']> {
    return this.http
      .get<Record<string, unknown>>(this.globalConfig.apiEndpoints.auth.profile, {
        headers: this.getAuthHeaders(),
      })
      .pipe(
        map((backendUser: Record<string, unknown>) => this.mapBackendUserToUser(backendUser)),
        tap((user) => {
          const basicUser = this.createBasicUser(user)
          this.store.dispatch(AuthActions.updateUser({ user: basicUser }))
          this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
        })
      )
  }

  /**
   * Get stored access token.
   * @returns The stored access token or null.
   */
  getToken(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null
    return getCookie(this.TOKEN_KEY)
  }

  /**
   * Set user session after token refresh.
   * @param response The token response from refresh endpoint.
   */
  private setRefreshedSession(response: AuthTokenResponse): void {
    if (!isPlatformBrowser(this.platformId)) return

    const expTimestamp = getJwtExpiration(response.accessToken)
    const daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7

    setSecureCookie(this.TOKEN_KEY, response.accessToken, {
      days: daysUntilExpiration,
      secure: false,
      sameSite: 'Strict',
    })
  }
  /**
   * Refresh access token using refresh token from HTTP-only cookie.
   * @returns Observable that emits new AuthTokenResponse on success.
   */
  refreshToken(): Observable<AuthTokenResponse> {
    if (this._isRefreshing()) {
      return this._refreshTokenSubject.asObservable().pipe(
        switchMap((result) => {
          if (result) {
            return of(result)
          } else {
            return throwError(() => new Error('Token refresh failed'))
          }
        })
      )
    }

    this._isRefreshing.set(true)

    return this.http
      .post<AuthTokenResponse>(
        this.globalConfig.apiEndpoints.auth.refreshToken,
        {},
        {
          withCredentials: true,
        }
      )
      .pipe(
        tap((response) => {
          this.setRefreshedSession(response)
          this._isRefreshing.set(false)
          this._refreshTokenSubject.next(response)
        }),
        catchError((error) => {
          this._isRefreshing.set(false)
          this._refreshTokenSubject.next(null)
          this.clearStoredAuth()
          this.store.dispatch(AuthActions.clearAuth())
          return throwError(() => error)
        })
      )
  }

  /**
   * Logout current user and clear session.
   */
  logout(): void {
    this.http
      .post<void>(
        this.globalConfig.apiEndpoints.auth.logout,
        {},
        {
          withCredentials: true,
        }
      )
      .subscribe({
        next: () => {
          this.clearStoredAuth()
          this.clearRememberPreference()
          this.store.dispatch(AuthActions.logout())
          this.router.navigate(['/'])
        },
        error: () => {
          this.clearStoredAuth()
          this.clearRememberPreference()
          this.store.dispatch(AuthActions.logout())
          this.router.navigate(['/'])
        },
      })
  }

  /**
   * Set user session after successful login.
   * @param response The login response from server.
   */
  private setSession(response: LoginResponse): void {
    if (!isPlatformBrowser(this.platformId)) return

    const expTimestamp = getJwtExpiration(response.accessToken)
    const daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7

    setSecureCookie(this.TOKEN_KEY, response.accessToken, {
      days: daysUntilExpiration,
      secure: false,
      sameSite: 'Strict',
    })

    const basicUser = this.createBasicUser(response.user)
    this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
    this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: response.user }))

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(`${this.cookiePrefix}_user_profile`, JSON.stringify(response.user))
    }
  }

  /**
   * Clear stored authentication data.
   */
  private clearStoredAuth(): void {
    if (!isPlatformBrowser(this.platformId)) return
    removeCookie(this.TOKEN_KEY)
  }

  /**
   * Register new user.
   * @param userData The registration data.
   * @returns Observable that emits RegisterResponse on success.
   */
  register(userData: RegisterRequest): Observable<RegisterResponse> {
    this._isLoading.set(true)
    return this.http
      .post<RegisterResponse>(this.globalConfig.apiEndpoints.auth.register, userData)
      .pipe(
        tap(() => {
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Register new platform administrator.
   * @param userData The registration data for platform admin.
   * @returns Observable that emits RegisterResponse on success.
   */
  registerPlatformAdmin(userData: RegisterRequest): Observable<RegisterResponse> {
    this._isLoading.set(true)
    return this.http
      .post<RegisterResponse>(this.globalConfig.apiEndpoints.auth.register, userData)
      .pipe(
        tap(() => {
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Create new tenant user.
   * @param userData The user data for tenant user creation.
   * @param tenantId The tenant ID where the user will be created.
   * @returns Observable that emits RegisterResponse on success.
   */
  createTenantUser(userData: RegisterRequest, tenantId?: string): Observable<RegisterResponse> {
    this._isLoading.set(true)
    const tenant = tenantId || this.getCurrentTenantId()
    const endpoint = this.globalConfig.apiEndpoints.users.create.replace(':tenantId', tenant)

    return this.http.post<RegisterResponse>(endpoint, userData).pipe(
      tap(() => {
        this._isLoading.set(false)
      }),
      catchError((error) => {
        this._isLoading.set(false)
        return throwError(() => error)
      })
    )
  }

  /**
   * Create new tenant administrator.
   * @param userData The user data for tenant admin creation.
   * @param tenantId The tenant ID where the admin will be created.
   * @returns Observable that emits RegisterResponse on success.
   */
  createTenantAdmin(userData: RegisterRequest, tenantId: string): Observable<RegisterResponse> {
    this._isLoading.set(true)
    const endpoint = this.globalConfig.apiEndpoints.users.createAdmin.replace(':tenantId', tenantId)

    return this.http
      .post<RegisterResponse>(endpoint, userData, {
        headers: this.getAuthHeaders(),
      })
      .pipe(
        tap(() => {
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Complete email verification and login user.
   * @param verificationCode The verification code entered by user.
   * @returns Observable that emits void on success.
   */
  completeEmailVerification(verificationCode: string): Observable<void> {
    const pendingData = this._pendingVerification()
    if (!pendingData) {
      return throwError(() => new Error('No pending verification'))
    }

    if (!verificationCode || verificationCode.trim() === '') {
      return throwError(() => new Error('Verification code is required'))
    }

    this._isLoading.set(true)

    const verificationData: VerifyEmailRequest = {
      email: pendingData.email,
      verificationCode: verificationCode.trim(),
    }

    if (!this.globalConfig.apiEndpoints.auth.verifyEmail) {
      return throwError(() => new Error('Email verification not supported for this domain'))
    }

    return this.http
      .post<void>(this.globalConfig.apiEndpoints.auth.verifyEmail, verificationData)
      .pipe(
        switchMap(() => {
          const loginRequest: LoginRequest = {
            email: pendingData.email,
            password: pendingData.password,
            remember: false,
          }

          return this.http.post<AuthTokenResponse>(
            this.globalConfig.apiEndpoints.auth.login,
            loginRequest,
            { withCredentials: true }
          )
        }),
        switchMap((tokenResponse: AuthTokenResponse) => {
          if (!tokenResponse || !tokenResponse.accessToken) {
            throw new Error('Invalid login response: missing access token')
          }

          if (isPlatformBrowser(this.platformId)) {
            const expTimestamp = getJwtExpiration(tokenResponse.accessToken)
            const daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7
            setSecureCookie(this.TOKEN_KEY, tokenResponse.accessToken, {
              days: daysUntilExpiration,
              secure: false,
              sameSite: 'Strict',
            })
          }

          return this.http
            .get<Record<string, unknown>>(this.globalConfig.apiEndpoints.auth.profile, {
              headers: this.getAuthHeaders(),
            })
            .pipe(
              map((backendUser: Record<string, unknown>) => ({
                tokenResponse,
                backendUser,
              }))
            )
        }),
        map(({ tokenResponse, backendUser }) => {
          const user = this.mapBackendUserToUser(backendUser)
          const payload = parseJwtPayload(tokenResponse.accessToken)
          if (payload) {
            const isSuperAdmin = payload['isSuperAdmin'] as boolean
            user.globalRole = isSuperAdmin ? 'super_admin' : 'user'
          }
          return { tokenResponse, user }
        }),
        tap(({ tokenResponse, user }) => {
          const loginResponse: LoginResponse = {
            accessToken: tokenResponse.accessToken,
            user,
          }
          this.setSession(loginResponse)
          this._pendingVerification.set(null)
          this._isLoading.set(false)
        }),
        map(() => void 0),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Resend email verification code.
   * @param requestData The resend verification request data.
   * @returns Observable that emits void on success.
   */
  resendVerification(requestData: ResendVerificationRequest): Observable<void> {
    if (!this.globalConfig.apiEndpoints.auth.resendVerification) {
      return throwError(() => new Error('Resend verification not supported for this domain'))
    }
    this._isLoading.set(true)

    return this.http
      .post<void>(this.globalConfig.apiEndpoints.auth.resendVerification, requestData)
      .pipe(
        tap(() => {
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Activate user account with invitation token.
   * @param userData The activation data including token and user details.
   * @returns Observable that emits AuthTokenResponse on success.
   */
  activateUser(userData: ActivateUserRequest): Observable<AuthTokenResponse> {
    if (!this.globalConfig.apiEndpoints.auth.activate) {
      return throwError(() => new Error('User activation not supported for this domain'))
    }
    this._isLoading.set(true)
    return this.http
      .post<AuthTokenResponse>(this.globalConfig.apiEndpoints.auth.activate, userData)
      .pipe(
        tap((response) => {
          this.setTokenAfterVerification(response)
          this._isLoading.set(false)
        }),
        catchError((error) => {
          this._isLoading.set(false)
          return throwError(() => error)
        })
      )
  }

  /**
   * Set user session with token response.
   * @param response The auth token response from server.
   */
  private setTokenSession(response: AuthTokenResponse): void {
    if (!isPlatformBrowser(this.platformId)) return

    const expTimestamp = getJwtExpiration(response.accessToken)
    const daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7

    setSecureCookie(this.TOKEN_KEY, response.accessToken, {
      days: daysUntilExpiration,
      secure: false,
      sameSite: 'Strict',
    })

    this.refreshUser().subscribe({
      next: (user) => {
        const basicUser = this.createBasicUser(user)
        this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
        this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
      },
      error: () => {
        const payload = parseJwtPayload(response.accessToken)
        if (payload) {
          const isSuperAdmin = payload['isSuperAdmin'] as boolean
          const user: User = {
            id: payload['sub'] as string,
            email: payload['email'] as string,
            firstName: (payload['firstName'] as string) || '',
            lastName: (payload['lastName'] as string) || '',
            phone: payload['phone'] as string,
            globalRole: isSuperAdmin ? 'super_admin' : 'user',
            isSuperAdmin,
            tenantRoles: [],
            onboardingCompleted: (payload['onboardingCompleted'] as boolean) || false,
            isActive: (payload['isActive'] as boolean) || true,
            createdAt: (payload['createdAt'] as string)
              ? new Date(payload['createdAt'] as string)
              : new Date(),
            updatedAt: (payload['updatedAt'] as string)
              ? new Date(payload['updatedAt'] as string)
              : new Date(),
          }

          const basicUser = this.createBasicUser(user)
          this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
          this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
        }
      },
    })
  }

  /**
   * Set token after email verification and load user profile.
   * @param response The auth token response from server.
   */
  private setTokenAfterVerification(response: AuthTokenResponse): void {
    if (!isPlatformBrowser(this.platformId)) return

    const expTimestamp = getJwtExpiration(response.accessToken)
    const daysUntilExpiration = expTimestamp ? getDaysUntilExpiration(expTimestamp) : 7

    setSecureCookie(this.TOKEN_KEY, response.accessToken, {
      days: daysUntilExpiration,
      secure: false,
      sameSite: 'Strict',
    })

    this.refreshUser().subscribe({
      next: (user) => {
        const basicUser = this.createBasicUser(user)
        this.store.dispatch(AuthActions.loginSuccess({ user: basicUser }))
        this.store.dispatch(UserProfileActions.loadProfileSuccess({ profile: user }))
      },
      error: () => {
        this._isAuthenticated.set(true)
      },
    })
  }

  /**
   * Get current user profile from server.
   * @returns Observable with user profile data.
   */
  getUserProfile(): Observable<User> {
    return this.http
      .get<Record<string, unknown>>(this.globalConfig.apiEndpoints.auth.profile, {
        headers: this.getAuthHeaders(),
      })
      .pipe(
        map((backendUser: Record<string, unknown>) => this.mapBackendUserToUser(backendUser)),
        tap((user) => {
          const basicUser = this.createBasicUser(user)
          this.store.dispatch(AuthActions.updateUser({ user: basicUser }))
        })
      )
  }

  /**
   * Update current user data (used for local updates like role changes).
   * @param user Updated user data.
   */
  updateCurrentUser(user: User): void {
    const basicUser = this.createBasicUser(user)
    this.store.dispatch(AuthActions.updateUser({ user: basicUser }))
  }

  /**
   * Create a basic user object for auth state (without sensitive data).
   * @param fullUser The complete user object.
   * @returns Basic user object for auth state.
   */
  private createBasicUser(fullUser: User): BasicUser {
    return {
      id: fullUser.id,
      email: fullUser.email,
      firstName: fullUser.firstName,
      lastName: fullUser.lastName,
      phone: fullUser.phone,
      globalRole: fullUser.globalRole,
      isSuperAdmin: fullUser.isSuperAdmin,
      tenantRoles: fullUser.tenantRoles,
      onboardingCompleted: fullUser.onboardingCompleted,
      demoTenantRequested: fullUser.demoTenantRequested,
      demoTenantId: fullUser.demoTenantId,
      tenantId: fullUser.tenantId,
      tenantName: fullUser.tenantName,
      createdAt: fullUser.createdAt,
      updatedAt: fullUser.updatedAt,
    }
  }

  /**
   * Check if user has "remember me" enabled.
   * @returns True if user wants to be remembered.
   */
  shouldRememberUser(): boolean {
    if (!isPlatformBrowser(this.platformId)) return false
    return localStorage.getItem('auth_remember_me') === 'true'
  }

  /**
   * Clear "remember me" preference.
   */
  clearRememberPreference(): void {
    if (!isPlatformBrowser(this.platformId)) return
    localStorage.removeItem('auth_remember_me')
  }

  /**
   * Get current tenant ID from route or context.
   * For mock/demo purposes, returns 'tenant-1'.
   * @returns Current tenant ID.
   */
  getCurrentTenantId(): string {
    return 'tenant-1'
  }

  /**
   * Map backend user response to User interface.
   * @param backendUser The user object from backend response.
   * @returns User object matching the interface.
   */
  private mapBackendUserToUser(backendUser: Record<string, unknown>): User {
    const tenantId = 'tenant-1'

    let tenantRoles: TenantRoleAssignment[] = []

    if (backendUser['tenantRoles']) {
      tenantRoles = backendUser['tenantRoles'] as TenantRoleAssignment[]
    } else if (backendUser['roles']) {
      const roles = backendUser['roles'] as unknown
      if (Array.isArray(roles)) {
        tenantRoles = roles.map((role) => ({
          tenantId,
          role: (typeof role === 'string'
            ? role
            : ((role as Record<string, unknown>)?.['name'] as string) || 'user'
          ).toLowerCase() as TenantRole,
          assignedAt: new Date((backendUser['createdAt'] as string) || Date.now().toString()),
          assignedBy: 'system',
          assignedByRole: 'super_admin' as PlatformRole,
        }))
      }
    }

    const isSuperAdmin = backendUser['isSuperAdmin'] as boolean
    let globalRole: PlatformRole = 'user' as PlatformRole
    if (isSuperAdmin) {
      globalRole = 'super_admin'
    }

    return {
      id: backendUser['id'] as string,
      email: backendUser['email'] as string,
      firstName: (backendUser['firstName'] as string) || '',
      lastName: (backendUser['lastName'] as string) || '',
      phone: backendUser['phone'] as string,
      isActive: (backendUser['active'] as boolean) || true,
      globalRole,
      isSuperAdmin,
      tenantRoles,
      tenant: backendUser['tenant'] as User['tenant'],
      onboardingCompleted: (backendUser['onboardingCompleted'] as boolean) || false,
      createdAt: backendUser['createdAt']
        ? new Date(backendUser['createdAt'] as string)
        : new Date(),
      updatedAt: backendUser['updatedAt']
        ? new Date(backendUser['updatedAt'] as string)
        : new Date(),
    }
  }
}
