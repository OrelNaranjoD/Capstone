/**
 * Inventory permissions interface - defines what actions users can perform on inventory.
 */
export interface InventoryPermissions {
  canCreatePieces: boolean
  canEditPieces: boolean
  canDeletePieces: boolean
  canViewPieces: boolean
  canCreateMovements: boolean
  canViewMovements: boolean
  canViewAlerts: boolean
  canResolveAlerts: boolean
  canViewReports: boolean
}
