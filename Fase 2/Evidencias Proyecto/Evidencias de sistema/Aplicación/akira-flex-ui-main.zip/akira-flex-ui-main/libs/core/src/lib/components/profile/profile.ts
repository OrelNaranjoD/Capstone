import { Component, signal, ChangeDetectionStrategy, inject, computed } from '@angular/core'
import { Router } from '@angular/router'
import { Button } from 'primeng/button'
import { Avatar } from 'primeng/avatar'
import { MenuItem } from 'primeng/api'
import { Menu } from 'primeng/menu'
import { Store } from '@ngrx/store'
import { AuthService } from '../../services/auth.service'
import {
  selectCurrentUser,
  selectUserInitials,
  selectUserFullName,
  selectUserPrimaryRole,
} from '../../state'

/**
 * Profile component displaying user info and a dropdown menu.
 */
@Component({
  selector: 'app-profile',
  imports: [Button, Avatar, Menu],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './profile.html',
})
export class Profile {
  private readonly store = inject(Store)
  private readonly authService = inject(AuthService)
  private readonly router = inject(Router)
  readonly currentUser = this.store.selectSignal(selectCurrentUser)
  readonly userInitials = this.store.selectSignal(selectUserInitials)
  readonly userName = this.store.selectSignal(selectUserFullName)
  readonly userPrimaryRole = this.store.selectSignal(selectUserPrimaryRole)
  readonly displayName = computed(() => {
    const user = this.currentUser()
    if (!user || !user.firstName || !user.lastName) return ''

    const firstName = user.firstName.trim().split(/\s+/)[0] || ''
    const lastName = user.lastName.trim().split(/\s+/)[0] || ''

    const fullName = `${firstName} ${lastName}`.trim()
    return fullName.length > 20 ? fullName.substring(0, 20) : fullName
  })

  readonly roleLabel = computed(() => {
    const role = this.userPrimaryRole()
    return this.getRoleLabel(role)
  })

  items = signal<MenuItem[]>([
    {
      label: $localize`:@@viewProfile:View Profile`,
      icon: 'pi pi-user',
      command: () => this.viewProfile(),
    },
    {
      label: $localize`:@@settings:Settings`,
      icon: 'pi pi-cog',
      command: () => this.settings(),
    },
    {
      separator: true,
    },
    {
      label: $localize`:@@logout:Log Out`,
      icon: 'pi pi-sign-out',
      command: () => this.logout(),
    },
  ])

  /**
   * Returns the localized label for a given role.
   * @param role The role identifier (e.g., 'admin', 'manager', 'owner').
   * @returns The localized label for the role.
   */
  getRoleLabel(role: string | undefined): string {
    if (!role || role === '') return $localize`:@@role.unknown:Unknown`

    switch (role) {
      case 'owner':
        return $localize`:@@role.owner:Owner`
      case 'admin':
        return $localize`:@@role.admin:Administrator`
      case 'manager':
        return $localize`:@@role.manager:Manager`
      case 'user':
        return $localize`:@@role.user:User`
      case 'viewer':
        return $localize`:@@role.viewer:Viewer`
      case 'platform-admin':
        return $localize`:@@role.platform-admin:Platform Admin`
      case 'super_admin':
        return $localize`:@@role.super-admin:Super Admin`
      default:
        return role
    }
  }

  /**
   * Navigates to the profile page.
   */
  viewProfile(): void {
    this.router.navigate(['profile'])
  }

  /**
   * Navigates to the settings page.
   */
  settings(): void {
    this.router.navigate(['settings'])
  }

  /**
   * Logs out the current user by invoking the AuthService.
   */
  logout(): void {
    this.authService.logout()
  }
}
