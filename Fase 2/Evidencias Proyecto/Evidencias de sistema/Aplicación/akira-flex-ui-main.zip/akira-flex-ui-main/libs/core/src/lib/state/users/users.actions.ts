import { createActionGroup, emptyProps, props } from '@ngrx/store'
import { User, CreateUserRequest, CreateTenantUserRequest, UpdateUserRequest } from '../../shared'

export const usersActions = createActionGroup({
  source: 'Users',
  events: {
    'Load Users': emptyProps(),
    'Load Users Success': props<{
      users: User[]
      total: number
      page: number
      limit: number
      totalPages: number
    }>(),
    'Load Users Failure': props<{ error: string }>(),
    'Create User': props<{ request: CreateUserRequest }>(),
    'Create User Success': props<{ user: User }>(),
    'Create User Failure': props<{ error: string }>(),
    'Create Tenant User': props<{ request: CreateTenantUserRequest }>(),
    'Create Tenant User Success': props<{ user: User }>(),
    'Create Tenant User Failure': props<{ error: string }>(),
    'Update User': props<{ userId: string; request: UpdateUserRequest }>(),
    'Update User Success': props<{ user: User }>(),
    'Update User Failure': props<{ error: string }>(),
    'Delete User': props<{ userId: string }>(),
    'Delete User Success': props<{ userId: string }>(),
    'Delete User Failure': props<{ error: string }>(),
    'Activate User': props<{ userId: string }>(),
    'Activate User Success': props<{ user: User }>(),
    'Activate User Failure': props<{ error: string }>(),
    'Deactivate User': props<{ userId: string }>(),
    'Deactivate User Success': props<{ user: User }>(),
    'Deactivate User Failure': props<{ error: string }>(),
    'Clear Users State': emptyProps(),
  },
})
