import { HttpInterceptorFn } from '@angular/common/http'
import { inject } from '@angular/core'
import { GlobalConfigService } from '../services/global-config.service'

/**
 * HTTP interceptor that adds the API base URL to relative API requests.
 * Requests starting with '/' are considered API requests and get the base URL prepended.
 * @param req The HTTP request.
 * @param next The next handler in the chain.
 * @returns Observable of HTTP events.
 */
export const baseUrlInterceptor: HttpInterceptorFn = (req, next) => {
  const globalConfig = inject(GlobalConfigService)

  if (req.url.startsWith('/')) {
    const baseUrl = globalConfig.getApiBaseUrl()
    if (baseUrl) {
      const fullUrl = `${baseUrl}${req.url}`
      const apiReq = req.clone({
        url: fullUrl,
      })
      return next(apiReq)
    }
  }

  return next(req)
}
