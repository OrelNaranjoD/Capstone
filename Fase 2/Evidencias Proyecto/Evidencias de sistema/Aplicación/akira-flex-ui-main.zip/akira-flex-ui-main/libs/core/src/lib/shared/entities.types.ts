import type {
  MovementType,
  AlertType,
  SaleStatus,
  PaymentMethod,
  SupplierStatus,
  PlatformRole,
  TenantRole,
} from './enums.types'

/**
 * Business entities - Core domain objects that represent business concepts.
 */

/**
 * Represents a platform administrator user.
 * These users exist in the public schema and have access to platform administration.
 * They manage tenants, subscriptions, and global platform settings.
 */
export interface PlatformUser {
  id: string
  email: string
  passwordHash: string
  role: PlatformRole
  status: 'active' | 'inactive' | 'suspended'
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a user within a specific tenant (organization).
 * These users exist in their tenant's isolated schema and have access only to their organization's data.
 * Their permissions are controlled by tenant roles and the organization's policies.
 */
export interface TenantUser {
  id: string
  email?: string // Now nullable - users can login with username
  username?: string // New field for username-based login
  contactEmail?: string // Contact email for username-based users
  loginIdentity: string // Calculated field: username || email
  passwordHash: string
  roleId: string
  isActive: boolean
  firstName?: string
  lastName?: string
  phone?: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a role definition within a tenant.
 * Roles define permissions and access levels for tenant users.
 */
export interface TenantRoleEntity {
  id: string
  name: TenantRole
  description: string
  isOwner: boolean // Special flag for tenant owner role
}

/**
 * Represents a permission in the system.
 * Permissions define specific actions users can perform.
 */
export interface Permission {
  id: string
  name: string
  description: string
}

/**
 * Junction table linking roles to their permissions.
 */
export interface RolePermission {
  roleId: string
  permissionId: string
}

/**
 * Represents an application notification.
 */
export interface AppNotification {
  id: number
  title: string
  message: string
  time: string
  read: boolean
  type: 'info' | 'warning' | 'success' | 'error'
}

/**
 * Represents a tenant (company/client) in the system.
 * Tenants are stored in the public schema and each has their own isolated schema.
 */
export interface Tenant {
  id: string
  name: string
  subdomain: string
  schemaName: string // PostgreSQL schema name for data isolation
  status: 'active' | 'on-trial' | 'suspended' | 'cancelled'
  plan: 'basic' | 'premium' | 'enterprise'
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a piece/item in inventory.
 */
export interface Piece {
  id: string
  description: string
  serialNumber: string
  location: string
  category: string
  currentStock: number
  minStock: number
  maxStock?: number
  unitPrice?: number
  purchasePrice?: number
  tags: string[]
  batch?: string
  expirationDate?: string
  supplier?: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a stock movement.
 */
export interface Movement {
  id: string
  pieceId: string
  type: MovementType
  quantity: number
  previousStock: number
  newStock: number
  date: Date
  responsible: string
  notes?: string
  reference?: string
  fromLocation?: string
  toLocation?: string
  createdAt: Date
}

/**
 * Represents an inventory alert.
 */
export interface InventoryAlert {
  id: string
  pieceId: string
  type: AlertType
  message: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  isActive: boolean
  createdAt: Date
  resolvedAt?: Date
}

/**
 * Represents a tenant role assignment for a user.
 */
export interface TenantRoleAssignment {
  tenantId: string
  role: TenantRole
  assignedAt: Date
  assignedBy: string
  assignedByRole: PlatformRole
}

/**
 * Legacy user interface for backward compatibility.
 * Represents a user with all possible fields from both platform and tenant contexts.
 * TODO: Gradually migrate to PlatformUser and TenantUser interfaces.
 */
export interface User {
  id: string
  email: string

  // Platform user fields
  passwordHash?: string
  role?: PlatformRole
  status?: 'active' | 'inactive' | 'suspended' | 'pending_verification'

  // Tenant user fields
  roleId?: string
  isActive?: boolean

  // Common/legacy fields for UI compatibility
  firstName?: string
  lastName?: string
  phone?: string
  globalRole?: PlatformRole
  isSuperAdmin?: boolean
  tenantRoles?: TenantRoleAssignment[] // Updated from unknown[]
  onboardingCompleted?: boolean
  demoTenantRequested?: boolean
  demoTenantId?: string

  // Permission and role fields for UI access control
  permissions?: string[]
  roles?: string[]
  tenantId?: string
  tenantName?: string
  tenant?: {
    id: string
    name: string
    subdomain: string
    email?: string
    active?: boolean
  }

  createdAt: Date
  updatedAt: Date
}

/**
 * Basic user interface for public store state.
 * Contains only non-sensitive user information for UI display.
 * Excludes permissions, roles, and password hash for security.
 */
export interface BasicUser {
  id: string
  email: string
  firstName?: string
  lastName?: string
  phone?: string
  globalRole?: PlatformRole
  isSuperAdmin?: boolean
  tenantRoles?: TenantRoleAssignment[]
  onboardingCompleted?: boolean
  demoTenantRequested?: boolean
  demoTenantId?: string
  tenantId?: string
  tenantName?: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a customer in the system.
 */
export interface Customer {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  taxId?: string
  type: 'individual' | 'company'
  status: 'active' | 'inactive' | 'suspended'
  creditLimit?: number
  currentDebt?: number
  tags: string[]
  notes?: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a sale item in a sale.
 */
export interface SaleItem {
  id: string
  pieceId: string
  pieceDescription: string
  pieceSerialNumber: string
  quantity: number
  unitPrice: number
  discount?: number
  total: number
}

/**
 * Represents a sale in the system.
 */
export interface Sale {
  id: string
  customerId: string
  customerName: string
  customerEmail: string
  items: SaleItem[]
  subtotal: number
  tax: number
  discount: number
  total: number
  status: SaleStatus
  paymentMethod?: PaymentMethod
  paymentDate?: Date
  notes?: string
  createdBy: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a supplier in the system.
 */
export interface Supplier {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  taxId?: string
  contactPerson?: string
  website?: string
  paymentTerms?: string
  status: SupplierStatus
  tags: string[]
  notes?: string
  createdAt: Date
  updatedAt: Date
}

/**
 * Represents a product in the system.
 */
export interface Product {
  id: string
  name: string
  description?: string
  sku: string
  category: string
  unitPrice: number
  purchasePrice?: number
  currentStock: number
  minStock: number
  maxStock?: number
  supplierId?: string
  supplierName?: string
  tags: string[]
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

/**
 * Business entities - Core domain objects that represent business concepts.
 */
