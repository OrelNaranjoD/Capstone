import { Injectable } from '@angular/core'
import { ApiEndpoints } from '../shared'

/**
 * Global configuration service for application-wide settings.
 */
@Injectable({
  providedIn: 'root',
})
export class GlobalConfigService {
  private _apiEndpoints: ApiEndpoints | null = null
  private _tenantSubdomain: string | null = null
  private _apiBaseUrl: string | null = null
  private _appBaseUrl: string | null = null

  /**
   * Configure the global API endpoints for this application.
   * This should be called once during app initialization.
   * @param endpoints The API endpoints configuration.
   */
  configureApiEndpoints(endpoints: ApiEndpoints): void {
    if (this._apiEndpoints) {
      throw new Error('API endpoints already configured. Can only be configured once.')
    }
    this._apiEndpoints = endpoints
  }

  /**
   * Configure the API base URL for this application.
   * This should be called once during app initialization.
   * @param baseUrl The API base URL.
   */
  configureApiBaseUrl(baseUrl: string): void {
    if (this._apiBaseUrl) {
      throw new Error('API base URL already configured. Can only be configured once.')
    }
    this._apiBaseUrl = baseUrl
  }

  /**
   * Configure the tenant subdomain for this application.
   * This should be called once during app initialization.
   * @param subdomain The tenant subdomain.
   */
  configureTenantSubdomain(subdomain: string | null): void {
    if (this._tenantSubdomain !== null) {
      throw new Error('Tenant subdomain already configured. Can only be configured once.')
    }
    this._tenantSubdomain = subdomain
  }

  /**
   * Configure the url base URL for this application.
   * This should be called once during app initialization.
   * @param appBaseUrl The app base URL.
   */
  configureAppBaseUrl(appBaseUrl: string): void {
    if (this._appBaseUrl) {
      throw new Error('App base URL already configured. Can only be configured once.')
    }
    this._appBaseUrl = appBaseUrl
  }

  /**
   * Get the configured API endpoints.
   * Throws an error if not configured yet.
   * @returns The configured API endpoints.
   */
  get apiEndpoints(): ApiEndpoints {
    if (!this._apiEndpoints) {
      throw new Error('API endpoints not configured. Call configureApiEndpoints() first.')
    }
    return this._apiEndpoints
  }

  /**
   * Get the configured tenant subdomain.
   * @returns The tenant subdomain or null if not configured.
   */
  getTenantSubdomain(): string | null {
    return this._tenantSubdomain
  }

  /**
   * Get the configured API base URL.
   * @returns The API base URL or null if not configured.
   */
  getApiBaseUrl(): string | null {
    return this._apiBaseUrl
  }

  /**
   * Get the configured app base URL.
   * @returns The app base URL or null if not configured.
   */
  getAppBaseUrl(): string | null {
    return this._appBaseUrl
  }
}
