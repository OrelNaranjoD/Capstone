import { Injectable, inject } from '@angular/core'
import { HttpClient, HttpParams } from '@angular/common/http'
import { Observable, throwError } from 'rxjs'
import { map } from 'rxjs/operators'
import {
  User,
  CreateUserRequest,
  CreateTenantUserRequest,
  UpdateUserRequest,
  InviteUserRequest,
  InviteUserResponse,
  BulkUserOperationRequest,
  BulkUserOperationResponse,
  UserListQuery,
  UserListResponse,
  UserManagementPermissions,
  TenantRole,
  PlatformRole,
  TenantRoleAssignment,
  ApiTenantUser,
  ApiUserListResponse,
} from '../shared'
import { GlobalConfigService } from './global-config.service'
import { AuthService } from './auth.service'

/**
 * Service for administrative user management operations.
 * Handles user creation, updates, invitations, and bulk operations.
 */
@Injectable({
  providedIn: 'root',
})
export class UserManagementService {
  private readonly http = inject(HttpClient)
  private readonly globalConfig = inject(GlobalConfigService)
  private readonly authService = inject(AuthService)

  /**
   * Get paginated list of users with optional filtering.
   * @param query Query parameters for filtering and pagination.
   * @returns Observable with paginated user list.
   */
  getUsers(query?: UserListQuery): Observable<UserListResponse> {
    let params = new HttpParams()

    if (query) {
      if (query.page !== undefined) params = params.set('page', query.page.toString())
      if (query.limit !== undefined) params = params.set('limit', query.limit.toString())
      if (query.search) params = params.set('search', query.search)
      if (query.globalRole) params = params.set('globalRole', query.globalRole)
      if (query.tenantRole) params = params.set('tenantRole', query.tenantRole)
      if (query.isActive !== undefined) params = params.set('isActive', query.isActive.toString())
      if (query.sortBy) params = params.set('sortBy', query.sortBy)
      if (query.sortOrder) params = params.set('sortOrder', query.sortOrder)
    }

    return this.http
      .get<ApiUserListResponse>(this.globalConfig.apiEndpoints.users.list, { params })
      .pipe(
        map((response: ApiUserListResponse) => {
          const transformedUsers = response.users
            ? response.users.map((user: ApiTenantUser) => this.mapApiUserToUser(user))
            : []

          return {
            ...response,
            users: transformedUsers,
          }
        })
      )
  }

  /**
   * Create a new tenant user (direct creation with password).
   * @param userData Tenant user creation data.
   * @returns Observable with created user.
   */
  createTenantUser(userData: CreateTenantUserRequest): Observable<User> {
    return this.http.post<User>(this.globalConfig.apiEndpoints.users.createTenantUser, userData)
  }

  /**
   * Create a new user (general user creation).
   * @param userData User creation data.
   * @returns Observable with created user.
   */
  createUser(userData: CreateUserRequest): Observable<User> {
    return this.http.post<User>(this.globalConfig.apiEndpoints.users.create, userData)
  }

  /**
   * Update an existing user.
   * @param userId ID of the user to update.
   * @param userData Update data.
   * @returns Observable with updated user.
   */
  updateUser(userId: string, userData: UpdateUserRequest): Observable<User> {
    const endpoint = this.globalConfig.apiEndpoints.users.update.replace(':id', userId)
    return this.http.patch<User>(endpoint, userData)
  }

  /**
   * Delete a user.
   * @param userId ID of the user to delete.
   * @returns Observable that completes on successful deletion.
   */
  deleteUser(userId: string): Observable<void> {
    const endpoint = this.globalConfig.apiEndpoints.users.delete.replace(':id', userId)
    return this.http.delete<void>(endpoint)
  }

  /**
   * Invite a new user to the tenant.
   * @param invitationData The invitation data.
   * @returns Observable with invitation response.
   */
  inviteUser(invitationData: InviteUserRequest): Observable<InviteUserResponse> {
    if (!this.globalConfig.apiEndpoints.auth.invite) {
      return throwError(() => new Error('User invitation not supported for this domain'))
    }
    return this.http.post<InviteUserResponse>(
      this.globalConfig.apiEndpoints.auth.invite,
      invitationData
    )
  }

  /**
   * Perform bulk operations on multiple users.
   * @param operationData Bulk operation data.
   * @returns Observable with operation results.
   */
  bulkUserOperation(
    operationData: BulkUserOperationRequest
  ): Observable<BulkUserOperationResponse> {
    return this.http.post<BulkUserOperationResponse>(
      this.globalConfig.apiEndpoints.users.bulkOperation,
      operationData
    )
  }

  /**
   * Get user management permissions for current user.
   * @returns Observable with permissions.
   */
  getUserManagementPermissions(): Observable<UserManagementPermissions> {
    return this.http.get<UserManagementPermissions>(
      this.globalConfig.apiEndpoints.users.permissions
    )
  }

  /**
   * Get a specific user by ID.
   * @param userId ID of the user to retrieve.
   * @returns Observable with user data.
   */
  getUser(userId: string): Observable<User> {
    const endpoint = this.globalConfig.apiEndpoints.users.getById.replace(':id', userId)
    return this.http.get<User>(endpoint)
  }

  /**
   * Activate a user account.
   * @param userId ID of the user to activate.
   * @returns Observable with updated user.
   */
  activateUser(userId: string): Observable<User> {
    const endpoint = this.globalConfig.apiEndpoints.users.restore.replace(':id', userId)
    return this.http.patch<User>(endpoint, {})
  }

  /**
   * Deactivate a user account.
   * @param userId ID of the user to deactivate.
   * @returns Observable with updated user.
   */
  deactivateUser(userId: string): Observable<User> {
    const endpoint = this.globalConfig.apiEndpoints.users.delete.replace(':id', userId)
    return this.http.delete<User>(endpoint)
  }

  /**
   * Update user roles.
   * @param userId ID of the user to update.
   * @param roles Array of roles to assign.
   * @returns Observable with updated user.
   */
  updateUserRoles(userId: string, roles: TenantRole[]): Observable<User> {
    const endpoint = this.globalConfig.apiEndpoints.users.update.replace(':id', userId)
    return this.http.patch<User>(endpoint, { roles })
  }

  /**
   * Assign a specific role to a user.
   * @param userId ID of the user.
   * @param roleId ID of the role to assign.
   * @returns Observable that completes on successful assignment.
   */
  assignRole(userId: string, roleId: string): Observable<void> {
    const endpoint = this.globalConfig.apiEndpoints.users.assignRole
      .replace(':userId', userId)
      .replace(':roleId', roleId)
    return this.http.post<void>(endpoint, {})
  }

  /**
   * Transfer ownership to another user.
   * @param newOwnerId ID of the new owner.
   * @returns Observable that completes on successful transfer.
   */
  transferOwnership(newOwnerId: string): Observable<void> {
    return this.http.post<void>(`${this.globalConfig.apiEndpoints.users.list}/transfer-ownership`, {
      newOwnerId,
    })
  }

  /**
   * Soft delete a user (deactivate).
   * @param userId ID of the user to soft delete.
   * @returns Observable that completes on successful deletion.
   */
  softDeleteUser(userId: string): Observable<void> {
    const endpoint = this.globalConfig.apiEndpoints.users.delete.replace(':id', userId)
    return this.http.delete<void>(endpoint)
  }

  /**
   * Hard delete a user (permanent removal).
   * @param userId ID of the user to hard delete.
   * @returns Observable that completes on successful deletion.
   */
  hardDeleteUser(userId: string): Observable<void> {
    const endpoint = this.globalConfig.apiEndpoints.users.hardDelete.replace(':id', userId)
    return this.http.delete<void>(endpoint)
  }

  /**
   * Map API user response to User interface.
   * @param apiUser The user object from API response.
   * @returns User object matching the interface.
   */
  private mapApiUserToUser(apiUser: ApiTenantUser): User {
    const tenantId = apiUser.tenant?.id || apiUser.tenantId || 'tenant-1'

    const tenantRoles: TenantRoleAssignment[] = apiUser.roles
      ? apiUser.roles.map((role) => ({
          tenantId,
          role: (typeof role === 'string' ? role : role.name || 'user').toLowerCase() as TenantRole,
          assignedAt: new Date(apiUser.createdAt || Date.now()),
          assignedBy: 'system',
          assignedByRole: 'super_admin' as PlatformRole,
        }))
      : []

    const activeRole = apiUser.roles?.find((role) => role.active)
    let globalRole: PlatformRole = 'user' as PlatformRole
    if (activeRole) {
      switch (activeRole.name) {
        case 'SUPER_ADMIN':
          globalRole = 'super_admin'
          break
        case 'PLATFORM_ADMIN':
          globalRole = 'platform-admin'
          break
        default:
          globalRole = 'user'
      }
    }

    return {
      id: apiUser.id,
      email: apiUser.email,
      firstName: apiUser.firstName || '',
      lastName: apiUser.lastName || '',
      phone: apiUser.phone,
      isActive: apiUser.active,
      globalRole,
      tenantRoles,
      tenant: apiUser.tenant
        ? {
            id: apiUser.tenant.id,
            name: apiUser.tenant.name,
            subdomain: apiUser.tenant.subdomain,
            email: apiUser.tenant.email,
            active: apiUser.tenant.active,
          }
        : undefined,
      onboardingCompleted: true,
      createdAt: new Date(apiUser.createdAt),
      updatedAt: new Date(apiUser.updatedAt),
    }
  }
}
