import { createFeature, createReducer, on } from '@ngrx/store'
import type { AuthState } from '../state.types'
import { AuthActions } from './auth.actions'

/**
 * Initial state for authentication.
 */
export const initialAuthState: AuthState = {
  user: null,
  loading: false,
  error: null,
  initialized: false,
}

/**
 * Authentication feature reducer.
 */
export const authFeature = createFeature({
  name: 'auth',
  reducer: createReducer(
    initialAuthState,

    on(AuthActions.initializeAuth, (state) => ({
      ...state,
      initialized: true,
    })),

    on(AuthActions.loginSuccess, (state, { user }) => ({
      ...state,
      user,
      loading: false,
      error: null,
      initialized: true,
    })),

    on(AuthActions.logout, (state) => ({
      ...state,
      user: null,
      loading: false,
      error: null,
    })),

    on(AuthActions.setLoading, (state, { loading }) => ({
      ...state,
      loading,
    })),

    on(AuthActions.setError, (state, { error }) => ({
      ...state,
      error,
      loading: false,
    })),

    on(AuthActions.updateUser, (state, { user }) => ({
      ...state,
      user: state.user ? { ...state.user, ...user } : null,
    })),

    on(AuthActions.clearAuth, (state) => ({
      ...state,
      user: null,
      loading: false,
      error: null,
    }))
  ),
})
