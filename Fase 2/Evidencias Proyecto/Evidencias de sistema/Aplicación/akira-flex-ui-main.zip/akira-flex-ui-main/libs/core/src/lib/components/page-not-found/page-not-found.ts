import { Component, inject, ChangeDetectionStrategy } from '@angular/core'
import { Router } from '@angular/router'
import { ButtonModule } from 'primeng/button'
import { CardModule } from 'primeng/card'
import { GlobalConfigService } from '../../services/global-config.service'

/**
 * Page not found component that handles 404 errors intelligently.
 * Shows different content based on authentication status.
 */
@Component({
  selector: 'app-page-not-found',
  imports: [ButtonModule, CardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './page-not-found.html',
})
export class PageNotFound {
  private readonly router = inject(Router)
  private readonly globalConfig = inject(GlobalConfigService)

  /**
   * Navigate to the dashboard page.
   */
  goToDashboard(): void {
    const appBaseUrl = this.globalConfig.getAppBaseUrl()
    if (appBaseUrl) {
      const appOrigin = new URL(appBaseUrl).origin
      if (window.location.origin === appOrigin) {
        this.router.navigate([''])
      } else {
        window.location.href = appBaseUrl
      }
    } else {
      this.router.navigate([''])
    }
  }

  /**
   * Navigate to the sign-in page.
   */
  goToSignIn(): void {
    this.router.navigate(['/'])
  }

  /**
   * Navigate back in history or to appropriate fallback page.
   */
  goBack(): void {
    if (window.history.length > 1) {
      window.history.back()
    } else {
      this.goToDashboard()
    }
  }
}
