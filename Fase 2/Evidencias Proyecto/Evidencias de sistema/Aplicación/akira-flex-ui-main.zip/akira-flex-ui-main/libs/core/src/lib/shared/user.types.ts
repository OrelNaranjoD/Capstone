import type { PlatformRole, TenantRole } from './enums.types'
import type { User, PlatformUser, TenantUser } from './entities.types'

/**
 * Request payload for creating a new user (administrative).
 */
export interface CreateUserRequest {
  firstName: string
  lastName: string
  email?: string
  username?: string
  contactEmail?: string
  phone?: string
  globalRole: PlatformRole
  tenantRoles?: CreateTenantRoleRequest[]
  password?: string
  sendInvitation?: boolean
  invitationMessage?: string
}

/**
 * Request payload for creating a tenant user.
 * Supports username or email based login with contact email for username users.
 */
export interface CreateTenantUserRequest {
  firstName: string
  lastName: string
  email?: string
  username?: string
  contactEmail?: string
  phone?: string
  roles: TenantRole[]
  password: string
}

/**
 * Request payload for creating tenant roles when creating a user.
 */
export interface CreateTenantRoleRequest {
  tenantId: string
  role: TenantRole
}

/**
 * Request payload for updating an existing user.
 */
export interface UpdateUserRequest {
  firstName?: string
  lastName?: string
  phone?: string
  globalRole?: PlatformRole
  tenantRoles?: UpdateTenantRoleRequest[]
  isActive?: boolean
}

/**
 * Request payload for updating tenant roles.
 */
export interface UpdateTenantRoleRequest {
  tenantId: string
  role?: TenantRole
  remove?: boolean
}

/**
 * Request payload for inviting a user to a tenant.
 * Uses email for login identity.
 */
export interface InviteUserRequest {
  email: string
  firstName?: string
  lastName?: string
  roles: TenantRole[]
  message?: string
}

/**
 * Response for user invitation.
 */
export interface InviteUserResponse {
  invitationId: string
  email: string
  expiresAt: string
  status: 'sent' | 'pending' | 'accepted' | 'expired'
}

/**
 * Request payload for bulk user operations.
 */
export interface BulkUserOperationRequest {
  userIds: string[]
  operation: 'activate' | 'deactivate' | 'delete'
}

/**
 * Response for bulk user operations.
 */
export interface BulkUserOperationResponse {
  successCount: number
  failureCount: number
  failures: Array<{
    userId: string
    error: string
  }>
}

/**
 * User list query parameters.
 */
export interface UserListQuery {
  page?: number
  limit?: number
  search?: string
  globalRole?: PlatformRole
  tenantRole?: TenantRole
  isActive?: boolean
  sortBy?: 'createdAt' | 'updatedAt' | 'firstName' | 'lastName' | 'email'
  sortOrder?: 'asc' | 'desc'
}

/**
 * Paginated platform user list response.
 */
export interface PlatformUserListResponse {
  users: PlatformUser[]
  total: number
  page: number
  limit: number
  totalPages: number
}

/**
 * Paginated tenant user list response.
 */
export interface TenantUserListResponse {
  users: TenantUser[]
  total: number
  page: number
  limit: number
  totalPages: number
}

/**
 * Legacy paginated user list response (for backward compatibility).
 */
export interface UserListResponse {
  users: User[]
  total: number
  page: number
  limit: number
  totalPages: number
}

/**
 * User management permissions for current user.
 */
export interface UserManagementPermissions {
  canCreateUsers: boolean
  canUpdateUsers: boolean
  canDeleteUsers: boolean
  canInviteUsers: boolean
  canManageRoles: boolean
  canViewAllUsers: boolean
  canManageTenantUsers: boolean
  allowedGlobalRoles: PlatformRole[]
  allowedTenantRoles: TenantRole[]
}

/**
 * Hierarchical user structure for platform user management.
 * Groups users by tenant ownership for better organization.
 * Note: This interface is being updated to work with the new multi-tenant architecture.
 */
export interface HierarchicalUser {
  user: User
  tenant?: {
    id: string
    name: string
    subdomain: string
    schemaName: string
  }
  level: number
  displayName?: string
  roles?: string[]
}
