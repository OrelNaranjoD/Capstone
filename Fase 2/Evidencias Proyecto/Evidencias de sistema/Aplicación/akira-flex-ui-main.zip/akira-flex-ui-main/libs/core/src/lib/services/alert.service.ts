import { Injectable, signal, computed } from '@angular/core'
import { GlobalAlert } from '../shared'

/**
 * Provides global alert management for the application.
 */
@Injectable({ providedIn: 'root' })
export class AlertService {
  private readonly _alert = signal<GlobalAlert | null>(null)
  readonly alert = computed(() => this._alert())

  /**
   * Show a new alert. Replaces any existing alert.
   * @param alert Alert data (message, type, duration).
   */
  show(alert: GlobalAlert): void {
    this._alert.set(alert)
    if (alert.duration && alert.duration > 0) {
      setTimeout(() => {
        if (this._alert() === alert) this.close()
      }, alert.duration)
    }
  }

  /**
   * Close the current alert (if any).
   */
  close(): void {
    this._alert.set(null)
  }
}
