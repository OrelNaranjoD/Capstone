import { createActionGroup, emptyProps, props } from '@ngrx/store'
import type { User } from '../../shared'

/**
 * User profile actions for managing complete user information.
 */
export const UserProfileActions = createActionGroup({
  source: 'User Profile',
  events: {
    'Load Profile Success': props<{ profile: User }>(),
    'Update Profile': props<{ profile: Partial<User> }>(),
    'Set Loading': props<{ loading: boolean }>(),
    'Set Error': props<{ error: string | null }>(),
    'Clear Profile': emptyProps(),
  },
})
