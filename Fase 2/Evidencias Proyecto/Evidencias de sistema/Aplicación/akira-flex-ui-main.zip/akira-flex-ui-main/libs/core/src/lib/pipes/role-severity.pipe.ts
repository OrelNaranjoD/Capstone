import { Pipe, PipeTransform } from '@angular/core'
import { TenantRole } from '../shared'

type Severity = 'info' | 'success' | 'warn' | 'danger' | 'secondary' | 'contrast'

/**
 * Pipe that transforms a TenantRole enum value to a PrimeNG severity level.
 */
@Pipe({
  name: 'roleSeverity',
  standalone: true,
})
export class RoleSeverityPipe implements PipeTransform {
  /**
   * Transforms a tenant role to its corresponding PrimeNG severity level.
   * @param role The tenant role to transform.
   * @returns The severity level for UI styling.
   */
  transform(role: TenantRole): Severity {
    const severities: Record<TenantRole, Severity> = {
      owner: 'warn',
      admin: 'info',
      manager: 'success',
      user: 'secondary',
      viewer: 'secondary',
    }
    return severities[role] || 'secondary'
  }
}
