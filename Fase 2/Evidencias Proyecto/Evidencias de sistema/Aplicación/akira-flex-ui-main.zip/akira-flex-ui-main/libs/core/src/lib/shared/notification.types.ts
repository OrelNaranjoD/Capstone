// Notification types moved to entities.types.ts
// This file is kept for future notification-specific types

// Export empty object to make this a valid module
export {}
