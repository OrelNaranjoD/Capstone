import { inject } from '@angular/core'
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http'
import { catchError, throwError } from 'rxjs'
import { isPlatformBrowser } from '@angular/common'
import { PLATFORM_ID } from '@angular/core'
import { AuthService } from '../services/auth.service'

/**
 * HTTP interceptor function for handling application errors and logging warnings.
 * @param req The outgoing HTTP request.
 * @param next The next interceptor in the chain.
 * @returns Observable of HTTP events.
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const platformId = inject(PLATFORM_ID)
  const authService = inject(AuthService)

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      handleError(error, platformId, authService)
      return throwError(() => error)
    })
  )
}

/**
 * Handles different types of errors and logs appropriate warnings.
 * @param error The HTTP error response.
 * @param platformId The platform ID to check if running in browser.
 * @param authService The auth service to handle logout on tenant errors.
 */
function handleError(error: HttpErrorResponse, platformId: object, authService: AuthService): void {
  if (!isPlatformBrowser(platformId)) return

  if (error.error instanceof ErrorEvent) {
    console.warn('Client-side error:', error.error.message)
  } else {
    handleServerError(error, authService)
  }
}

/**
 * Handles server-side HTTP errors with appropriate warnings.
 * @param error The HTTP error response from server.
 * @param authService The auth service to handle logout on tenant errors.
 */
function handleServerError(error: HttpErrorResponse, authService: AuthService): void {
  const { status, statusText, url, error: errorBody } = error

  if (status === 404 && errorBody?.message?.includes('Tenant with ID')) {
    console.warn('Tenant not found, logging out user:', errorBody.message)
    authService.logout()
    return
  }

  switch (status) {
    case 400:
      console.warn(`Bad Request (400) - ${url}:`, errorBody?.message || statusText)
      break
    case 401:
      console.warn(`Unauthorized (401) - ${url}: Session expired or invalid credentials`)
      break
    case 403:
      console.warn(`Forbidden (403) - ${url}: Insufficient permissions`)
      break
    case 404:
      console.warn(`Not Found (404) - ${url}: Resource not found`)
      break
    case 422:
      console.warn(`Unprocessable Entity (422) - ${url}:`, errorBody?.message || 'Validation error')
      break
    case 500:
      console.warn(`Internal Server Error (500) - ${url}: Server error occurred`)
      break
    default:
      if (status >= 500) {
        console.warn(`Server Error (${status}) - ${url}:`, statusText)
      } else if (status >= 400) {
        console.warn(`Client Error (${status}) - ${url}:`, errorBody?.message || statusText)
      }
  }
}
