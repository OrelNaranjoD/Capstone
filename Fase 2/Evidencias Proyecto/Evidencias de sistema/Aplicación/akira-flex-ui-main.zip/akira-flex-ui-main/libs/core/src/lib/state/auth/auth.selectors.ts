import { createSelector } from '@ngrx/store'
import { authFeature } from './auth.feature'

export const selectAuthState = authFeature.selectAuthState
export const selectCurrentUser = authFeature.selectUser
export const selectAuthLoading = authFeature.selectLoading
export const selectAuthError = authFeature.selectError
export const selectAuthInitialized = authFeature.selectInitialized
export const selectIsAuthenticated = createSelector(selectCurrentUser, (user) => !!user)
export const selectUserInitials = createSelector(selectCurrentUser, (user) => {
  if (!user || !user.firstName || !user.lastName) return ''
  return (user.firstName.charAt(0) + user.lastName.charAt(0)).toUpperCase()
})
export const selectUserFullName = createSelector(selectCurrentUser, (user) => {
  if (!user || !user.firstName || !user.lastName) return ''
  return `${user.firstName} ${user.lastName}`
})
export const selectUserPrimaryRole = createSelector(selectCurrentUser, (user) => {
  if (!user) return ''
  if (user.tenantRoles && Array.isArray(user.tenantRoles) && user.tenantRoles.length > 0) {
    const ownerRole = user.tenantRoles.find((tr) => tr && tr.role === 'owner')
    if (ownerRole) {
      return 'owner'
    }
    const adminRole = user.tenantRoles.find((tr) => tr && tr.role === 'admin')
    if (adminRole) {
      return 'admin'
    }
  }
  const globalRole = user.globalRole || 'user'
  return globalRole
})
