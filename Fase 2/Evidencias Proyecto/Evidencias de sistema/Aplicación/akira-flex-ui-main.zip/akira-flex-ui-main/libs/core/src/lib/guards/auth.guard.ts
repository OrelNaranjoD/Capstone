import { inject } from '@angular/core'
import { Router } from '@angular/router'
import { CanActivateFn } from '@angular/router'
import { AuthService } from '../services/auth.service'

/**
 * Auth guard that checks if user is authenticated and redirects to login if not.
 * Waits for auth initialization to complete and validates user authentication.
 * @param route The activated route snapshot.
 * @param state The router state snapshot.
 * @returns Promise that resolves to true if authenticated, false otherwise.
 */
export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService)
  const router = inject(Router)

  return new Promise((resolve) => {
    const checkAuth = () => {
      if (!authService.isInitialized()) {
        setTimeout(checkAuth, 50)
        return
      }

      if (authService.isAuthenticated()) {
        resolve(true)
      } else {
        router.navigate(['/auth/sign-in'], {
          queryParams: { returnUrl: state.url },
          replaceUrl: true,
        })
        resolve(false)
      }
    }

    checkAuth()
  })
}
