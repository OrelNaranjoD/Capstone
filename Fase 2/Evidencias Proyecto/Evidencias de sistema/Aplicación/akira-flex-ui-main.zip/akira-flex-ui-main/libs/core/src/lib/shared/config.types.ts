/**
 * Theme-related cookie names.
 */
export const THEME_COOKIES = {
  MODE: 'akira-theme-mode',
} as const
