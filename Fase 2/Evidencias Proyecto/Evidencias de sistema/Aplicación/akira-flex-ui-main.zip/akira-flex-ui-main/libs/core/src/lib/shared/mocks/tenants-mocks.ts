import { Tenant } from '../entities.types'

export const MOCK_TENANTS: Tenant[] = [
  {
    id: 'tenant-1',
    name: 'Empresa Demo S.A.',
    subdomain: 'demo',
    schemaName: 'tenant_1',
    status: 'active',
    plan: 'premium',
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-01'),
  },
]
