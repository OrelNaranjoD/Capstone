/**
 * Alert type for global notifications.
 */
export type GlobalAlertType = 'success' | 'info' | 'warning' | 'error'

/**
 * Represents a global alert notification.
 */
export interface GlobalAlert {
  message: string
  type: GlobalAlertType
  duration?: number
  id?: string
}
