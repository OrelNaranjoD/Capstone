import { PlatformUser, Tenant } from '../entities.types'

/**
 * Mocks for entities from the public schema (Platform Users & Tenants).
 * These mocks simulate how data would look directly from the database.
 */

// --- Platform Users (Public Schema) ---
export const MOCK_PLATFORM_USERS: PlatformUser[] = [
  {
    id: 'pfu-sa-2023',
    email: 'superadmin@platform.com',
    passwordHash: 'hashed_password_sa',
    role: 'platform-admin',
    status: 'active',
    createdAt: new Date('2023-01-01T10:00:00Z'),
    updatedAt: new Date('2024-05-15T10:00:00Z'),
  },
  {
    id: 'pfu-sp-2023',
    email: 'support@platform.com',
    passwordHash: 'hashed_password_sp',
    role: 'user',
    status: 'active',
    createdAt: new Date('2023-03-01T10:00:00Z'),
    updatedAt: new Date('2024-05-15T10:00:00Z'),
  },
]

// --- Tenants (Public Schema) ---
export const MOCK_TENANTS: Tenant[] = [
  {
    id: 'tnt-001',
    name: 'RepUSA Taller Automotriz',
    subdomain: 'repusa',
    schemaName: 'tenant_repusa_001',
    status: 'active',
    plan: 'premium',
    createdAt: new Date('2023-12-01T10:00:00Z'),
    updatedAt: new Date('2024-05-20T10:00:00Z'),
  },
  {
    id: 'tnt-002',
    name: 'Joyas Origen Artesanal',
    subdomain: 'joyasorigen',
    schemaName: 'tenant_joyas_002',
    status: 'on-trial',
    plan: 'basic',
    createdAt: new Date('2024-06-01T10:00:00Z'),
    updatedAt: new Date('2024-06-01T10:00:00Z'),
  },
]
