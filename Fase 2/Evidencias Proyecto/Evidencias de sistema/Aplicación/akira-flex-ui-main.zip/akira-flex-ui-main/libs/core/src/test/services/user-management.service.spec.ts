import '../test'
import { TestBed } from '@angular/core/testing'
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing'
import { provideHttpClient } from '@angular/common/http'
import { Store } from '@ngrx/store'
import { UserManagementService } from '@core'
import { GlobalConfigService } from '@core'
import { APP_COOKIE_PREFIX } from '@core'
import {
  User,
  CreateUserRequest,
  UpdateUserRequest,
  InviteUserRequest,
  InviteUserResponse,
  BulkUserOperationRequest,
  BulkUserOperationResponse,
  UserListQuery,
  UserListResponse,
  UserManagementPermissions,
} from '@core'

describe('UserManagementService', () => {
  let service: UserManagementService
  let httpMock: HttpTestingController

  const mockApiEndpoints = {
    users: {
      list: '/api/users',
      getById: '/api/users/:id',
      create: '/api/users',
      createAdmin: '/api/users',
      update: '/api/users/:id',
      delete: '/api/users/:id',
      restore: '/api/users/:id/restore',
      hardDelete: '/api/users/:id/delete',
      assignRole: '/api/users/:userId/roles/:roleId',
      invite: '/api/users/invite',
      bulkOperation: '/api/users/bulk',
      permissions: '/api/users/permissions',
    },
    auth: {
      invite: '/api/users/invite',
    },
  }

  const mockUser: User = {
    id: '1',
    email: 'test@example.com',
    firstName: 'Test',
    lastName: 'User',
    phone: '+1234567890',
    globalRole: 'user',
    tenantRoles: [
      {
        tenantId: 'tenant-1',
        role: 'user',
        assignedAt: new Date('2023-01-01T00:00:00Z'),
        assignedBy: 'system',
        assignedByRole: 'super_admin',
      },
    ],
    tenant: {
      id: 'tenant-1',
      name: 'Test Tenant',
      subdomain: 'test',
      email: 'tenant@example.com',
      active: true,
    },
    onboardingCompleted: true,
    isActive: true,
    createdAt: new Date('2023-01-01T00:00:00Z'),
    updatedAt: new Date('2023-01-01T00:00:00Z'),
  }

  beforeEach(() => {
    TestBed.resetTestingModule()
    const mockGlobalConfigService = {
      apiEndpoints: mockApiEndpoints,
    }
    const mockStore = {
      select: vi.fn(),
      dispatch: vi.fn(),
      selectSignal: vi.fn(() => vi.fn(() => null)),
    }

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        UserManagementService,
        { provide: GlobalConfigService, useValue: mockGlobalConfigService },
        { provide: APP_COOKIE_PREFIX, useValue: 'test' },
        { provide: Store, useValue: mockStore },
      ],
    })

    service = TestBed.inject(UserManagementService)
    httpMock = TestBed.inject(HttpTestingController)
  })

  afterEach(() => {
    httpMock.verify()
  })

  it('should be created', () => {
    expect(service).toBeTruthy()
  })

  describe('getUsers', () => {
    it('should get users without query params', () => {
      const apiResponse = {
        users: [
          {
            id: '1',
            email: 'test@example.com',
            firstName: 'Test',
            lastName: 'User',
            phone: '+1234567890',
            roles: [{ name: 'user', active: true }],
            active: true,
            tenantId: 'tenant-1',
            tenant: {
              id: 'tenant-1',
              name: 'Test Tenant',
              subdomain: 'test',
              email: 'tenant@example.com',
              active: true,
            },
            createdAt: '2023-01-01T00:00:00.000Z',
            updatedAt: '2023-01-01T00:00:00.000Z',
          },
        ],
        total: 1,
        page: 1,
        limit: 10,
        totalPages: 1,
      }

      service.getUsers().subscribe((response: UserListResponse) => {
        expect(response.total).toBe(1)
        expect(response.page).toBe(1)
        expect(response.limit).toBe(10)
        expect(response.totalPages).toBe(1)
        expect(response.users).toHaveLength(1)
        expect(response.users[0]).toEqual(mockUser)
      })

      const req = httpMock.expectOne('/api/users')
      expect(req.request.method).toBe('GET')
      expect(req.request.params.keys().length).toBe(0)
      req.flush(apiResponse)
    })

    it('should get users with query params', () => {
      const query: UserListQuery = {
        page: 1,
        limit: 10,
        search: 'test',
        tenantRole: 'user',
        isActive: true,
        sortBy: 'email',
        sortOrder: 'asc',
      }
      const apiResponse = {
        users: [
          {
            id: '1',
            email: 'test@example.com',
            firstName: 'Test',
            lastName: 'User',
            phone: '+1234567890',
            roles: [{ name: 'user', active: true }],
            active: true,
            tenantId: 'tenant-1',
            tenant: {
              id: 'tenant-1',
              name: 'Test Tenant',
              subdomain: 'test',
              email: 'tenant@example.com',
              active: true,
            },
            createdAt: '2023-01-01T00:00:00.000Z',
            updatedAt: '2023-01-01T00:00:00.000Z',
          },
        ],
        total: 1,
        page: 1,
        limit: 10,
        totalPages: 1,
      }

      service.getUsers(query).subscribe((response: UserListResponse) => {
        expect(response.total).toBe(1)
        expect(response.page).toBe(1)
        expect(response.limit).toBe(10)
        expect(response.totalPages).toBe(1)
        expect(response.users).toHaveLength(1)
        expect(response.users[0]).toEqual(mockUser)
      })

      const req = httpMock.expectOne((request) => {
        return (
          request.url === '/api/users' &&
          request.params.get('page') === '1' &&
          request.params.get('limit') === '10' &&
          request.params.get('search') === 'test' &&
          request.params.get('tenantRole') === 'user' &&
          request.params.get('isActive') === 'true' &&
          request.params.get('sortBy') === 'email' &&
          request.params.get('sortOrder') === 'asc'
        )
      })
      expect(req.request.method).toBe('GET')
      req.flush(apiResponse)
    })
  })

  describe('createUser', () => {
    it('should create a user', () => {
      const userData: CreateUserRequest = {
        email: 'new@example.com',
        firstName: 'New',
        lastName: 'User',
        globalRole: 'user',
      }

      service.createUser(userData).subscribe((response: User) => {
        expect(response).toEqual(mockUser)
      })

      const req = httpMock.expectOne('/api/users')
      expect(req.request.method).toBe('POST')
      expect(req.request.body).toEqual(userData)
      req.flush(mockUser)
    })
  })

  describe('updateUser', () => {
    it('should update a user', () => {
      const userId = '1'
      const updateData: UpdateUserRequest = {
        firstName: 'Updated',
        lastName: 'Name',
      }
      const updatedUser = { ...mockUser, ...updateData }

      service.updateUser(userId, updateData).subscribe((response: User) => {
        expect(response).toEqual(updatedUser)
      })

      const req = httpMock.expectOne('/api/users/1')
      expect(req.request.method).toBe('PATCH')
      expect(req.request.body).toEqual(updateData)
      req.flush(updatedUser)
    })
  })

  describe('deleteUser', () => {
    it('should delete a user', () => {
      const userId = '1'

      service.deleteUser(userId).subscribe()

      const req = httpMock.expectOne('/api/users/1')
      expect(req.request.method).toBe('DELETE')
      req.flush(null)
    })
  })

  describe('inviteUser', () => {
    it('should invite a user', () => {
      const invitationData: InviteUserRequest = {
        email: 'invite@example.com',
        firstName: 'Invite',
        lastName: 'User',
        roles: ['user'],
        message: 'Welcome!',
      }
      const mockResponse: InviteUserResponse = {
        invitationId: 'inv-123',
        email: 'invite@example.com',
        expiresAt: '2023-12-31T00:00:00Z',
        status: 'sent',
      }

      service.inviteUser(invitationData).subscribe((response: InviteUserResponse) => {
        expect(response).toEqual(mockResponse)
      })

      const req = httpMock.expectOne('/api/users/invite')
      expect(req.request.method).toBe('POST')
      expect(req.request.body).toEqual(invitationData)
      req.flush(mockResponse)
    })
  })

  describe('bulkUserOperation', () => {
    it('should perform bulk operation', () => {
      const operationData: BulkUserOperationRequest = {
        userIds: ['1', '2', '3'],
        operation: 'activate',
      }
      const mockResponse: BulkUserOperationResponse = {
        successCount: 3,
        failureCount: 0,
        failures: [],
      }

      service.bulkUserOperation(operationData).subscribe((response: BulkUserOperationResponse) => {
        expect(response).toEqual(mockResponse)
      })

      const req = httpMock.expectOne('/api/users/bulk')
      expect(req.request.method).toBe('POST')
      expect(req.request.body).toEqual(operationData)
      req.flush(mockResponse)
    })
  })

  describe('getUserManagementPermissions', () => {
    it('should get user management permissions', () => {
      const mockPermissions: UserManagementPermissions = {
        canCreateUsers: true,
        canUpdateUsers: true,
        canDeleteUsers: false,
        canInviteUsers: true,
        canManageRoles: true,
        canViewAllUsers: true,
        canManageTenantUsers: true,
        allowedGlobalRoles: ['user', 'super_admin'],
        allowedTenantRoles: ['user', 'admin', 'manager'],
      }

      service.getUserManagementPermissions().subscribe((response: UserManagementPermissions) => {
        expect(response).toEqual(mockPermissions)
      })

      const req = httpMock.expectOne('/api/users/permissions')
      expect(req.request.method).toBe('GET')
      req.flush(mockPermissions)
    })
  })

  describe('getUser', () => {
    it('should get a specific user', () => {
      const userId = '1'

      service.getUser(userId).subscribe((response: User) => {
        expect(response).toEqual(mockUser)
      })

      const req = httpMock.expectOne('/api/users/1')
      expect(req.request.method).toBe('GET')
      req.flush(mockUser)
    })
  })

  describe('activateUser', () => {
    it('should activate a user', () => {
      const userId = '1'
      const activatedUser = { ...mockUser, isActive: true }

      service.activateUser(userId).subscribe((response: User) => {
        expect(response).toEqual(activatedUser)
      })

      const req = httpMock.expectOne('/api/users/1/restore')
      expect(req.request.method).toBe('PATCH')
      expect(req.request.body).toEqual({})
      req.flush(activatedUser)
    })
  })

  describe('deactivateUser', () => {
    it('should deactivate a user', () => {
      const userId = '1'
      const deactivatedUser = { ...mockUser, isActive: false }

      service.deactivateUser(userId).subscribe((response: User) => {
        expect(response).toEqual(deactivatedUser)
      })

      const req = httpMock.expectOne('/api/users/1')
      expect(req.request.method).toBe('DELETE')
      req.flush(deactivatedUser)
    })
  })
})
