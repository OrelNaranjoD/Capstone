import '@angular/compiler'
import '@analogjs/vitest-angular/setup-zone'

import { platformBrowserTesting, BrowserTestingModule } from '@angular/platform-browser/testing'
import { getTestBed } from '@angular/core/testing'

if (typeof (globalThis as Record<string, unknown>)['$localize'] === 'undefined') {
  ;(globalThis as Record<string, unknown>)['$localize'] = Object.assign(
    (template: TemplateStringsArray, ...expressions: unknown[]) => {
      return template.reduce((acc, str, i) => acc + str + (expressions[i] || ''), '')
    },
    { locale: 'en-US' }
  )
}

const mockCSSVariables = `
  :root {
    --p-button-primary-border-color: #007bff;
    --p-button-primary-background: #007bff;
    --p-button-primary-color: #ffffff;
    --p-button-secondary-border-color: #6c757d;
    --p-button-secondary-background: #6c757d;
    --p-button-secondary-color: #ffffff;
    --p-button-success-border-color: #28a745;
    --p-button-success-background: #28a745;
    --p-button-success-color: #ffffff;
    --p-button-info-border-color: #17a2b8;
    --p-button-info-background: #17a2b8;
    --p-button-info-color: #ffffff;
    --p-button-warning-border-color: #ffc107;
    --p-button-warning-background: #ffc107;
    --p-button-warning-color: #212529;
    --p-button-help-border-color: #6f42c1;
    --p-button-help-background: #6f42c1;
    --p-button-help-color: #ffffff;
    --p-button-danger-border-color: #dc3545;
    --p-button-danger-background: #dc3545;
    --p-button-danger-color: #ffffff;
    --p-surface-ground: #f8f9fa;
    --p-surface-section: #ffffff;
    --p-surface-card: #ffffff;
    --p-surface-overlay: #ffffff;
    --p-surface-border: #e9ecef;
    --p-surface-hover: #f8f9fa;
    --p-text-color: #212529;
    --p-text-muted-color: #6c757d;
    --p-primary-color: #007bff;
    --p-primary-color-text: #007bff;
    --p-input-padding: 0.5rem 0.75rem;
    --p-input-border: 1px solid #ced4da;
    --p-input-border-color: #ced4da;
    --p-input-border-radius: 4px;
    --p-input-focus-border-color: #007bff;
    --p-input-focus-box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    --p-input-error-border-color: #dc3545;
    --p-input-success-border-color: #28a745;
    --p-dialog-border: 0 none;
    --p-dialog-border-radius: 6px;
    --p-dialog-shadow: 0 11px 15px -7px rgba(0, 0, 0, 0.2), 0 24px 38px 3px rgba(0, 0, 0, 0.14), 0 9px 46px 8px rgba(0, 0, 0, 0.12);
    --p-focus-ring: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    --p-transition-duration: 0.2s;
  }
`

if (typeof document !== 'undefined') {
  const style = document.createElement('style')
  style.textContent = mockCSSVariables
  document.head.appendChild(style)

  const originalSetProperty = CSSStyleDeclaration.prototype.setProperty
  CSSStyleDeclaration.prototype.setProperty = function (property: string, value: string | null) {
    try {
      if (value && typeof value === 'string' && value.includes('var(')) {
        return
      }
      return originalSetProperty.call(this, property, value)
    } catch {
      return
    }
  }
}

/**
 * Global test setup for Vitest with Angular.
 * Configures the Angular testing environment with zoneless change detection.
 */
getTestBed().initTestEnvironment(BrowserTestingModule, platformBrowserTesting())
