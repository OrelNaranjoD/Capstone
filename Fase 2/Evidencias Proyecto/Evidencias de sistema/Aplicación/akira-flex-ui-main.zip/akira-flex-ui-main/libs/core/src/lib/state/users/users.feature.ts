import { createFeature, createReducer, on } from '@ngrx/store'
import { User } from '../../shared'
import { usersActions } from './users.actions'

export interface UsersState {
  users: User[]
  total: number
  page: number
  limit: number
  totalPages: number
  loading: boolean
  error: string | null
}

export const initialUsersState: UsersState = {
  users: [],
  total: 0,
  page: 1,
  limit: 10,
  totalPages: 0,
  loading: false,
  error: null,
}

export const usersFeature = createFeature({
  name: 'users',
  reducer: createReducer(
    initialUsersState,
    on(usersActions.loadUsers, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.loadUsersSuccess, (state, { users, total, page, limit, totalPages }) => ({
      ...state,
      users,
      total,
      page,
      limit,
      totalPages,
      loading: false,
      error: null,
    })),
    on(usersActions.loadUsersFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.createUser, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.createUserSuccess, (state, { user }) => ({
      ...state,
      users: [...state.users, user],
      total: state.total + 1,
      loading: false,
      error: null,
    })),
    on(usersActions.createUserFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.updateUser, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.updateUserSuccess, (state, { user }) => ({
      ...state,
      users: state.users.map((u) => (u.id === user.id ? user : u)),
      loading: false,
      error: null,
    })),
    on(usersActions.updateUserFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.deleteUser, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.deleteUserSuccess, (state, { userId }) => ({
      ...state,
      users: state.users.filter((u) => u.id !== userId),
      total: state.total - 1,
      loading: false,
      error: null,
    })),
    on(usersActions.deleteUserFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.activateUser, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.activateUserSuccess, (state, { user }) => ({
      ...state,
      users: state.users.map((u) => (u.id === user.id ? user : u)),
      loading: false,
      error: null,
    })),
    on(usersActions.activateUserFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.deactivateUser, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),
    on(usersActions.deactivateUserSuccess, (state, { user }) => ({
      ...state,
      users: state.users.map((u) => (u.id === user.id ? user : u)),
      loading: false,
      error: null,
    })),
    on(usersActions.deactivateUserFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),
    on(usersActions.clearUsersState, () => initialUsersState)
  ),
})
