// Tenant entity moved to entities.types.ts
// This file is kept for future tenant-specific types

// Export empty object to make this a valid module
export {}
