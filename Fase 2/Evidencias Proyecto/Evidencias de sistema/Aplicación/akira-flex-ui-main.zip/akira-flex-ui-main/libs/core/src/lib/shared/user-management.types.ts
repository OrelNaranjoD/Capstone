/**
 * API response structure for tenant users.
 */
export interface ApiTenantUser {
  id: string
  email: string
  firstName?: string
  lastName?: string
  phone?: string
  roles: Array<{
    id: string
    name: string
    active: boolean
    createdAt: string
    updatedAt: string
    permissions: Array<{
      id: string
      code: string
      description: string
    }>
  }>
  active: boolean
  tenant?: {
    id: string
    name: string
    subdomain: string
    email: string
    active: boolean
  }
  tenantId?: string
  createdAt: string
  updatedAt: string
  lastLogin?: string
}

/**
 * API response structure for user list.
 */
export interface ApiUserListResponse {
  users: ApiTenantUser[]
  total: number
  page: number
  limit: number
  totalPages: number
}
