import { createActionGroup, emptyProps, props } from '@ngrx/store'
import type { BasicUser } from '../../shared'

/**
 * Authentication actions for managing user state.
 */
export const AuthActions = createActionGroup({
  source: 'Auth',
  events: {
    'Initialize Auth': emptyProps(),
    'Login Success': props<{ user: BasicUser }>(),
    Logout: emptyProps(),
    'Set Loading': props<{ loading: boolean }>(),
    'Set Error': props<{ error: string | null }>(),
    'Update User': props<{ user: Partial<BasicUser> }>(),
    'Clear Auth': emptyProps(),
  },
})
