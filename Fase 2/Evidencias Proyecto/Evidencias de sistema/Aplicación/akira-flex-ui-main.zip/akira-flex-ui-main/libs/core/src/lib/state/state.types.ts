import type {
  CompanyInfo,
  BranchInfo,
  BusinessHours,
  ConnectionStatus,
} from '../shared/common.types'
import type { User, BasicUser } from '../shared'

/**
 * Authentication feature state - Only minimal UI state.
 */
export interface AuthState {
  user: BasicUser | null
  loading: boolean
  error: string | null
  initialized: boolean
}

/**
 * User profile feature state - Complete user information.
 */
export interface UserProfileState {
  profile: User | null
  loading: boolean
  error: string | null
}

/**
 * System status feature state.
 */
export interface SystemStatusState {
  companyInfo: CompanyInfo | null
  branchInfo: BranchInfo | null
  appVersion: string | null
  businessHours: BusinessHours | null
  lastSyncTime: string | null
  connectionStatus: ConnectionStatus | null
  loading: boolean
  error: string | null
}
