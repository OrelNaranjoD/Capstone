import { inject } from '@angular/core'
import { HttpInterceptorFn } from '@angular/common/http'
import { HttpHeaders } from '@angular/common/http'
import { APP_COOKIE_PREFIX } from '../shared'
import { getCookie } from '../utils/cookie-utils'

/**
 * HTTP interceptor function that adds authorization headers to outgoing requests.
 * @param req The outgoing HTTP request.
 * @param next The next interceptor in the chain.
 * @returns Observable of HTTP events.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const cookiePrefix = inject(APP_COOKIE_PREFIX)
  const tokenKey = `${cookiePrefix}_access_token`

  if (req.url.includes('/auth/login') || req.url.includes('/auth/register')) {
    return next(req)
  }

  const token = getCookie(tokenKey)

  console.log(`[AUTH INTERCEPTOR] URL: ${req.url}, Token found: ${!!token}`)

  if (token) {
    const authReq = req.clone({
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
      }),
    })
    return next(authReq)
  }

  return next(req)
}
