import {
  Component,
  inject,
  output,
  signal,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  PLATFORM_ID,
} from '@angular/core'
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms'
import { LoginRequest, LoginResponse } from '@core'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { IconFieldModule } from 'primeng/iconfield'
import { InputIconModule } from 'primeng/inputicon'
import { CheckboxModule } from 'primeng/checkbox'
import { ButtonModule } from 'primeng/button'
import { MessageModule } from 'primeng/message'
import { PasswordModule } from 'primeng/password'
import { SignInService } from './sign-in.service'

/**
 * Component for the sign-in form in the landing page header.
 */
@Component({
  selector: 'landing-sign-in',
  imports: [
    DialogModule,
    CheckboxModule,
    InputTextModule,
    ReactiveFormsModule,
    IconFieldModule,
    InputIconModule,
    MessageModule,
    ButtonModule,
    PasswordModule,
  ],
  providers: [SignInService],
  templateUrl: './sign-in.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignIn {
  visible = false
  loginSuccess = output<LoginResponse>()
  requestSignUp = output<void>()
  forgot = output<void>()

  serverError = signal<string | null>(null)
  private fb = inject(FormBuilder)
  private loginService = inject(SignInService)
  private cdr = inject(ChangeDetectorRef)
  private platformId = inject(PLATFORM_ID)

  signInForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    remember: [false],
  })

  /**
   * Handles the sign-in form submission.
   */
  signInSubmit(): void {
    this.signInForm.markAllAsTouched()
    if (this.signInForm.invalid) return

    this.serverError.set(null)

    const payload = this.signInForm.value as LoginRequest

    this.loginService.login(payload).subscribe({
      next: (response: LoginResponse) => {
        if ('requiresVerification' in response && response.requiresVerification) {
          this.signInForm.reset()
          this.visible = false
          return
        }

        this.loginSuccess.emit(response)
        this.signInForm.reset()
        this.visible = false
      },
      error: (err: unknown) => {
        this.serverError.set(
          err instanceof Error
            ? err.message
            : $localize`:@@error.signIn:Error signing in. Please try again.`
        )
      },
    })
  }

  /**
   * Handles the request to open the sign-up form.
   */
  onRequestSignUp(): void {
    this.requestSignUp.emit()
    this.visible = false
    this.cdr.detectChanges()
  }

  /**
   * Shows the sign-in modal.
   */
  show(): void {
    this.visible = true
    this.cdr.detectChanges()
  }

  /**
   * Hides the sign-in modal.
   */
  hide(): void {
    this.visible = false
    this.cdr.detectChanges()
  }

  /**
   * Handles the forgot password action.
   */
  forgotPassword(): void {
    this.forgot.emit()
  }

  /**
   * Programmatically logs in with provided credentials.
   * @param email The user's email.
   * @param password The user's password.
   */
  login(email: string, password: string): void {
    this.serverError.set(null)

    const payload: LoginRequest = {
      email,
      password,
      remember: false,
    }

    this.loginService.login(payload).subscribe({
      next: (response: LoginResponse) => {
        if ('requiresVerification' in response && response.requiresVerification) {
          return
        }

        this.loginSuccess.emit(response)
      },
      error: (err: unknown) => {
        this.serverError.set(
          err instanceof Error
            ? err.message
            : $localize`:@@error.signIn:Error signing in. Please try again.`
        )
      },
    })
  }
}
