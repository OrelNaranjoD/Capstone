import { App } from '../app/app'

describe('App', () => {
  it('should create the app component', () => {
    const component = new App()
    expect(component).toBeTruthy()
  })
})
