import {
  ApplicationConfig,
  provideBrowserGlobalErrorListeners,
  provideZonelessChangeDetection,
  provideAppInitializer,
  inject,
  isDevMode,
} from '@angular/core'
import { provideRouter, withInMemoryScrolling } from '@angular/router'
import { ROUTES } from './app.routes'
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http'
import { provideClientHydration, withEventReplay } from '@angular/platform-browser'
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async'
import { providePrimeNG } from 'primeng/config'
import { DialogService } from 'primeng/dynamicdialog'
import { SkyZincTheme } from './themes/custom-theme.preset'
import { provideState, provideStore } from '@ngrx/store'
import { provideStoreDevtools } from '@ngrx/store-devtools'
import {
  authInterceptor,
  errorInterceptor,
  GlobalConfigService,
  baseUrlInterceptor,
  refreshTokenInterceptor,
  APP_COOKIE_PREFIX,
  authFeature,
  AuthService,
  API_ENDPOINTS,
} from '@core'
import { environment } from '../environments/environment'

/**
 * Initialize application configuration.
 * @param globalConfig The global config service to configure.
 * @param authService The auth service to initialize.
 * @returns Promise that resolves when initialization is complete.
 */
function initializeApp(globalConfig: GlobalConfigService, authService: AuthService): Promise<void> {
  return new Promise((resolve) => {
    globalConfig.configureApiEndpoints(API_ENDPOINTS['landing'])
    globalConfig.configureApiBaseUrl(environment.apiBaseUrl)
    globalConfig.configureAppBaseUrl(environment.appBaseUrl)
    authService.initialize()
    resolve()
  })
}

export const appConfig: ApplicationConfig = {
  providers: [
    { provide: APP_COOKIE_PREFIX, useValue: 'landing' },
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    ...(isDevMode() ? [] : [provideClientHydration(withEventReplay())]),
    provideRouter(
      ROUTES,
      withInMemoryScrolling({ anchorScrolling: 'enabled', scrollPositionRestoration: 'top' })
    ),
    provideHttpClient(
      withFetch(),
      withInterceptors([
        baseUrlInterceptor,
        refreshTokenInterceptor,
        ...(isDevMode() ? [] : []),
        authInterceptor,
        errorInterceptor,
      ])
    ),
    provideAnimationsAsync(),
    providePrimeNG({
      ripple: true,
      theme: {
        preset: SkyZincTheme,
        options: {
          darkModeSelector: '.dark',
          prefix: 'p',
          cssLayer: {
            name: 'primeng',
            order: 'theme, base, primeng',
          },
        },
      },
    }),
    DialogService,
    provideStore(),
    provideState(authFeature),
    provideStoreDevtools({
      maxAge: 25,
      logOnly: !isDevMode(),
    }),
    provideAppInitializer(() => initializeApp(inject(GlobalConfigService), inject(AuthService))),
  ],
}
