import { CommonModule } from '@angular/common'
import { Component, inject, signal } from '@angular/core'
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms'
import { DynamicDialogRef, DynamicDialogConfig } from 'primeng/dynamicdialog'
import { InputTextModule } from 'primeng/inputtext'
import { ButtonModule } from 'primeng/button'
import { MessageModule } from 'primeng/message'
import { AuthService } from '@core'

/**
 * Component for email verification modal in the landing page.
 */
@Component({
  selector: 'landing-verify-email',
  imports: [CommonModule, ReactiveFormsModule, InputTextModule, ButtonModule, MessageModule],
  templateUrl: './verify-email.html',
})
export class VerifyEmail {
  isLoading = signal(false)
  serverError = signal<string | null>(null)
  emailSent = signal(false)
  resendDisabled = signal(false)
  countdown = signal(0)

  private readonly formBuilder = inject(FormBuilder)
  private readonly ref = inject(DynamicDialogRef)
  private readonly config = inject(DynamicDialogConfig)
  private readonly authService = inject(AuthService)

  email = this.config.data?.email || ''

  form = this.formBuilder.group({
    verificationCode: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]],
  })

  /**
   * Handles verification code submission.
   */
  async verifyCode(): Promise<void> {
    this.form.markAllAsTouched()
    if (this.form.invalid || this.isLoading()) return

    this.serverError.set(null)
    this.isLoading.set(true)

    const code = this.form.get('verificationCode')!.value as string

    this.authService.completeEmailVerification(code).subscribe({
      next: () => {
        this.isLoading.set(false)
        this.ref.close('verified')
      },
      error: (err: unknown) => {
        this.isLoading.set(false)
        this.serverError.set(err instanceof Error ? err.message : 'Invalid verification code')
      },
    })
  }

  /**
   * Resends the verification code to the user's email.
   */
  resendCode(): void {
    if (this.resendDisabled()) return

    this.resendDisabled.set(true)
    this.countdown.set(30)
    this.serverError.set(null)

    this.authService.resendVerification({ email: this.email }).subscribe({
      next: () => {
        this.emailSent.set(true)
        const interval = setInterval(() => {
          this.countdown.update((count) => {
            if (count <= 1) {
              clearInterval(interval)
              this.resendDisabled.set(false)
              return 0
            }
            return count - 1
          })
        }, 1000)
      },
      error: (err: unknown) => {
        this.resendDisabled.set(false)
        this.serverError.set(err instanceof Error ? err.message : 'Error resending code')
      },
    })
  }

  /**
   * Closes the verification modal.
   */
  cancel(): void {
    this.ref.close()
  }
}
