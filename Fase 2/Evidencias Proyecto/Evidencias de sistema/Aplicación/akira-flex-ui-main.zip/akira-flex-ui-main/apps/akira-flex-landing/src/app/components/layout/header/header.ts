import {
  Component,
  signal,
  effect,
  inject,
  PLATFORM_ID,
  computed,
  ChangeDetectionStrategy,
} from '@angular/core'
import { isPlatformBrowser } from '@angular/common'
import { Menu } from '../menu/menu'
import { Auth } from '../../../pages/auth/auth'
import { Logotype, Profile, ThemeSwitch, LanguageSwitcher, AuthService } from '@core'

/**
 * Landing header component.
 */
@Component({
  selector: 'landing-header',
  imports: [Menu, Auth, Logotype, Profile, ThemeSwitch, LanguageSwitcher],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './header.html',
})
export class Header {
  private readonly platformId = inject(PLATFORM_ID)
  private readonly authService = inject(AuthService)
  readonly isLoggedIn = computed(() => this.authService.isAuthenticated())
  readonly isScrolled = signal(false)

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const onScroll = () => this.isScrolled.set(window.pageYOffset > 10)
      window.addEventListener('scroll', onScroll)
      effect((onCleanup) => {
        onCleanup(() => window.removeEventListener('scroll', onScroll))
      })
    }
  }
}
