export const environment = {
  production: false,
  apiBaseUrl: 'https://staging-api.example.com/api/v1',
}
