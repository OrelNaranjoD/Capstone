import { Routes } from '@angular/router'

export const ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./components/layout/layout').then((m) => m.Layout),
    children: [
      {
        path: '',
        loadComponent: () => import('./pages/home/home').then((m) => m.Home),
      },
    ],
  },
  {
    path: 'auth',
    children: [
      {
        path: 'password-recovery',
        loadComponent: () =>
          import(
            '../../../../apps/akira-flex-tenant/src/app/pages/auth/password-recovery/password-recovery'
          ).then((m) => m.PasswordRecovery),
      },
    ],
  },
  {
    path: '**',
    loadComponent: () => import('@core').then((m) => m.PageNotFound),
  },
]
