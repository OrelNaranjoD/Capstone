import { Injectable, inject } from '@angular/core'
import { Observable, throwError } from 'rxjs'
import { catchError } from 'rxjs/operators'
import { RegisterRequest, RegisterResponse, AuthService } from '@core'

/**
 * Service for handling user registration via the landing page.
 */
@Injectable()
export class SignUpService {
  private readonly authService = inject(AuthService)

  /**
   * Send register request to API and normalize errors.
   * @param payload Registration payload to send to the API.
   * @returns Observable that emits RegisterResponse on success or throws a normalized error.
   */
  register(payload: RegisterRequest): Observable<RegisterResponse> {
    return this.authService.register(payload).pipe(
      catchError((error) => {
        let message = error.message || 'Registration error.'
        if (error.message?.includes('409') || error.message?.includes('Conflict')) {
          message = 'This email is already registered.'
        }
        return throwError(() => new Error(message))
      })
    )
  }
}
