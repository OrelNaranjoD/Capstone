import { Injectable, inject } from '@angular/core'
import { Observable, throwError } from 'rxjs'
import { catchError, map } from 'rxjs/operators'
import { LoginRequest, LoginResponse } from '@core'
import { AuthService } from '@core'

/**
 * Service for handling user sign in.
 */
@Injectable()
export class SignInService {
  private readonly authService = inject(AuthService)

  /**
   * Send sign-in request to API and normalize errors.
   *
   * @param payload Sign-in payload to send to the API.
   * @returns Observable that emits LoginResponse on success or throws a normalized error.
   */
  public login(payload: LoginRequest): Observable<LoginResponse> {
    return this.authService.login(payload).pipe(
      map(() => {
        const user = this.authService.currentUser()
        const token = this.authService.getToken()
        if (user && token) {
          return {
            user,
            accessToken: token,
          } as LoginResponse
        }
        throw new Error($localize`:@@error.signInFailed:Sign-in failed. Please try again.`)
      }),
      catchError((error) => {
        let message = $localize`:@@error.signIn:Error signing in. Please try again.`
        if (error.message?.includes('401') || error.message?.includes('Unauthorized')) {
          message = $localize`:@@error.invalidCredentials:Invalid credentials. Please check your email and password.`
        } else if (error.message?.includes('EMAIL_NOT_VERIFIED')) {
          message = $localize`:@@error.emailNotVerified:Email not verified. Please check your inbox.`
        }
        return throwError(() => new Error(message))
      })
    )
  }
}
