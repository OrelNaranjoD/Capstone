import {
  Component,
  ChangeDetectionStrategy,
  output,
  ViewChild,
  inject,
  effect,
} from '@angular/core'
import { ButtonModule } from 'primeng/button'
import { SignIn } from './sign-in/sign-in'
import { SignUp } from './sign-up/sign-up'
import { VerifyEmail } from './verify-email/verify-email'
import { DialogService } from 'primeng/dynamicdialog'
import { AuthService } from '@core'
import { Router } from '@angular/router'

/**
 * Authentication Component for Landing Page Header.
 * Provides "Sign In" and "Request Demo" buttons that open respective modal dialogs.
 */
@Component({
  selector: 'landing-auth',
  imports: [ButtonModule, SignIn, SignUp],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './auth.html',
})
export class Auth {
  @ViewChild('signInComponent') signInComponent!: SignIn
  @ViewChild('signUpComponent') signUpComponent!: SignUp

  public readonly loginSuccess = output<void>()

  private readonly dialogService = inject(DialogService)
  private readonly authService = inject(AuthService)
  private readonly router = inject(Router)

  constructor() {
    effect(() => {
      const pendingVerification = this.authService.pendingVerification()
      if (pendingVerification) {
        this.openVerificationModal(pendingVerification.email)
      }
    })
  }

  /**
   * Open email verification modal for pending verification users.
   * @param email The email address that needs verification.
   * @private
   */
  private openVerificationModal(email: string): void {
    const ref = this.dialogService.open(VerifyEmail, {
      header: 'Verify your email',
      width: '400px',
      modal: true,
      closable: false,
      data: { email },
    })

    if (ref) {
      ref.onClose.subscribe((result) => {
        if (result === 'verified') {
          this.loginSuccess.emit()
        }
      })
    }
  }

  /**
   * Handles successful registration and opens email verification modal.
   * @param data The registration data containing email and password.
   * @param data.email
   * @param data.password
   */
  onRegisterSuccess(data: { email: string; password: string }): void {
    this.authService.setPendingVerification(data.email, data.password)

    const ref = this.dialogService.open(VerifyEmail, {
      header: 'Verify your email',
      width: '400px',
      modal: true,
      closable: false,
      data: { email: data.email },
    })

    if (ref) {
      ref.onClose.subscribe((result) => {
        if (result === 'verified') {
          this.signInComponent.login(data.email, data.password)
        }
      })
    }
  }

  /**
   * Opens the sign-up form ('Sign Up') in a modal dialog.
   * Handles navigation to the sign-in dialog if the user chooses to switch.
   */
  public openSignUpDialog(): void {
    this.signUpComponent.show()
  }

  /**
   * Opens the sign-in form ('Sign In') in a modal dialog.
   * Handles navigation to the sign-up dialog if the user chooses to switch.
   */
  public openSignInDialog(): void {
    this.signInComponent.show()
  }

  /**
   * Handles successful login.
   */
  onLoginSuccess(): void {
    this.loginSuccess.emit()
  }

  /**
   * Switches from sign-in to sign-up modal.
   */
  switchToSignUp(): void {
    this.signUpComponent.show()
  }

  /**
   * Switches from sign-up to sign-in modal.
   */
  switchToSignIn(): void {
    this.signInComponent.show()
  }

  /**
   * Handles forgot password action.
   */
  onForgotPassword(): void {
    try {
      this.signInComponent?.hide()
    } catch {
      /* Ignore if viewChild not ready */
    }
    this.router.navigate(['auth/password-recovery'])
  }
}
