import { CommonModule } from '@angular/common'
import {
  Component,
  output,
  input,
  inject,
  signal,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
} from '@angular/core'
import {
  ReactiveFormsModule,
  FormBuilder,
  Validators,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms'
import { DialogModule } from 'primeng/dialog'
import { ButtonModule } from 'primeng/button'
import { InputTextModule } from 'primeng/inputtext'
import { PasswordModule } from 'primeng/password'
import { MessageModule } from 'primeng/message'
import { IconFieldModule } from 'primeng/iconfield'
import { InputIconModule } from 'primeng/inputicon'
import { SignUpService } from './sign-up.service'
import { passwordMatchValidator } from '@core/utils'

/**
 * Component for the registration form in the landing page header.
 */
@Component({
  selector: 'landing-sign-up',
  imports: [
    CommonModule,
    DialogModule,
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    PasswordModule,
    MessageModule,
    IconFieldModule,
    InputIconModule,
  ],
  providers: [SignUpService],
  templateUrl: './sign-up.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SignUp {
  visible = false
  isDropdownOpen = input(false)
  isRegisterOpen = input(false)
  requestSwitch = output<boolean>()
  registerSuccess = output<{ email: string; password: string }>()

  isLoading = signal(false)
  serverError = signal<string | null>(null)

  private readonly formBuilder = inject(FormBuilder)
  private readonly registerService = inject(SignUpService)
  private readonly cdr = inject(ChangeDetectorRef)

  /**
   * Custom validator to ensure email is provided and valid.
   * @param control The form control to validate.
   * @returns Validation errors if email is not provided or invalid, null otherwise.
   */
  private emailValidator = (control: AbstractControl): ValidationErrors | null => {
    const email = control.get('email')?.value

    if (!email) {
      return { emailRequired: true }
    }

    return null
  }

  form = this.formBuilder.group(
    {
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: [passwordMatchValidator, this.emailValidator] }
  )

  /**
   * Handles form submission. If valid, it calls the registration service.
   * On success, it closes the modal.
   */
  async registerSubmit(): Promise<void> {
    this.form.markAllAsTouched()
    if (this.form.invalid || this.isLoading()) return

    this.serverError.set(null)
    this.isLoading.set(true)
    const { firstName, lastName, email, phone, password } = this.form.getRawValue()

    const payload = {
      firstName: firstName!,
      lastName: lastName!,
      email: email!,
      phone: phone || undefined,
      password: password!,
    }

    this.registerService.register(payload).subscribe({
      next: async () => {
        this.isLoading.set(false)
        this.visible = false
        this.registerSuccess.emit({ email: email!, password: password! })
      },
      error: (err: unknown) => {
        this.isLoading.set(false)

        if (err && typeof err === 'object' && 'status' in err) {
          const httpError = err as { status: number; error?: { message?: string } }

          if (httpError.status === 409) {
            this.serverError.set(
              httpError.error?.message || $localize`:@@emailAlreadyInUse:Email already in use`
            )
          } else if (httpError.status === 500) {
            this.serverError.set(
              $localize`:@@registrationFailed:Registration failed. Please try again.`
            )
          } else {
            this.serverError.set(
              $localize`:@@registrationFailed:Registration failed. Please try again.`
            )
          }
        } else {
          this.serverError.set(
            $localize`:@@registrationFailed:Registration failed. Please try again.`
          )
        }
      },
    })
  }

  /**
   * Switches to the sign-in form.
   */
  switchToSignIn(): void {
    this.visible = false
    this.requestSwitch.emit(true)
    this.cdr.detectChanges()
  }

  /**
   * Shows the sign-up modal.
   */
  show(): void {
    this.visible = true
    this.cdr.detectChanges()
  }

  /**
   * Hides the sign-up modal.
   */
  hide(): void {
    this.visible = false
    this.cdr.detectChanges()
  }
}
