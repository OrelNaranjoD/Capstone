export const environment = {
  production: true,
  apiBaseUrl: 'http://localhost:3000/api/v1',
  appBaseUrl: 'https://landing.akiraflex.com',
}
