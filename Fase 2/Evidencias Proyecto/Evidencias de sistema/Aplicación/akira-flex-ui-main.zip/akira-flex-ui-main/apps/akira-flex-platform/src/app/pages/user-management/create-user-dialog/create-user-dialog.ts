import { Component, inject, input, output } from '@angular/core'
import { CommonModule } from '@angular/common'
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms'
import { ButtonModule } from 'primeng/button'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { SelectModule } from 'primeng/select'
import { PasswordModule } from 'primeng/password'
import { MessageModule } from 'primeng/message'
import { PlatformRole } from '@core'

/**
 * Create user dialog component for platform user management.
 * Handles user creation with proper validation and internationalization.
 */
@Component({
  selector: 'platform-create-user-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    SelectModule,
    PasswordModule,
    MessageModule,
  ],
  templateUrl: './create-user-dialog.html',
})
export class CreateUserDialog {
  private readonly fb = inject(FormBuilder)
  readonly visible = input.required<boolean>()
  readonly saving = input.required<boolean>()
  readonly visibleChange = output<boolean>()
  readonly save = output<{
    formValue: {
      firstName: string
      lastName: string
      email?: string
      username?: string
      contactEmail?: string
      phone?: string
      password?: string
      globalRole: PlatformRole
    }
  }>()
  readonly userForm: FormGroup
  readonly globalRoleOptions = [
    {
      label: $localize`:@@platform-admin:Platform Admin`,
      value: 'platform-admin' as PlatformRole,
    },
    {
      label: $localize`:@@super-admin:Super Administrador`,
      value: 'super_admin' as PlatformRole,
    },
  ]

  /**
   * Custom validator to ensure either email or username is provided.
   * @param control The form group control.
   * @returns Validation errors or null.
   */
  private identityValidator = (control: AbstractControl): ValidationErrors | null => {
    const email = control.get('email')?.value
    const username = control.get('username')?.value

    if (!email && !username) {
      return { identityRequired: true }
    }

    if (username && !control.get('contactEmail')?.value) {
      control.get('contactEmail')?.setErrors({ required: true })
    } else if (username && control.get('contactEmail')?.value) {
      const contactEmailErrors = control.get('contactEmail')?.errors
      if (contactEmailErrors?.['required']) {
        delete contactEmailErrors['required']
        control
          .get('contactEmail')
          ?.setErrors(Object.keys(contactEmailErrors).length ? contactEmailErrors : null)
      }
    }

    return null
  }

  constructor() {
    this.userForm = this.fb.group(
      {
        firstName: ['', [Validators.required, Validators.minLength(2)]],
        lastName: ['', [Validators.required, Validators.minLength(2)]],
        email: ['', [Validators.email]],
        username: ['', [Validators.minLength(3)]],
        contactEmail: ['', [Validators.email]],
        phone: [''],
        password: ['', [Validators.minLength(6)]],
        globalRole: ['platform-admin' as PlatformRole, Validators.required],
      },
      { validators: this.identityValidator }
    )
  }

  /**
   * Handle dialog hide event.
   */
  onHide(): void {
    this.visibleChange.emit(false)
    this.userForm.reset({
      globalRole: 'platform-admin' as PlatformRole,
    })
  }

  /**
   * Handle form submission.
   */
  onSave(): void {
    if (this.userForm.valid) {
      const formValue = this.userForm.getRawValue()
      this.save.emit({
        formValue: {
          firstName: formValue.firstName,
          lastName: formValue.lastName,
          email: formValue.email || undefined,
          username: formValue.username || undefined,
          contactEmail: formValue.contactEmail || undefined,
          phone: formValue.phone || undefined,
          password: formValue.password || undefined,
          globalRole: formValue.globalRole,
        },
      })
    }
  }
}
