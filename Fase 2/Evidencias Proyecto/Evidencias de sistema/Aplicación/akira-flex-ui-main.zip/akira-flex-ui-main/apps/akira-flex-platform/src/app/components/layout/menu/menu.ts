import { Component, input } from '@angular/core'
import { PanelMenu } from 'primeng/panelmenu'

/**
 * Platform Menu Component - Dashboard navigation with collapsible support.
 */
@Component({
  selector: 'platform-menu',
  imports: [PanelMenu],
  templateUrl: './menu.html',
})
export class Menu {
  isCollapsed = input(false)
  items = [
    {
      label: 'Dashboard',
      icon: 'pi pi-chart-line',
      routerLink: '/',
    },
    {
      label: 'Users',
      icon: 'pi pi-users',
      routerLink: '/users',
    },
  ]
}
