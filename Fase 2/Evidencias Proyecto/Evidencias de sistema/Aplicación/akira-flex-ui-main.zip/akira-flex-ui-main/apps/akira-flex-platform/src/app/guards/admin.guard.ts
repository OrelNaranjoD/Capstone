import { inject } from '@angular/core'
import { Router, type CanActivateFn } from '@angular/router'
import { AuthService } from '@core'

/**
 * Guard to protect platform admin routes.
 * Only super admins can access platform administration features.
 * @returns True if user is authenticated and is marked as super admin, false otherwise.
 */
export const adminGuard: CanActivateFn = () => {
  const authService = inject(AuthService)
  const router = inject(Router)

  const isAuthenticated = authService.isAuthenticated()
  const currentUser = authService.currentUser()

  if (!isAuthenticated || !currentUser) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  if (!currentUser.isSuperAdmin) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}
