import { Component, inject, signal, OnInit, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { ButtonModule } from 'primeng/button'
import { TableModule } from 'primeng/table'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { TextareaModule } from 'primeng/textarea'
import { ToastModule } from 'primeng/toast'
import { ConfirmDialogModule } from 'primeng/confirmdialog'
import { ToolbarModule } from 'primeng/toolbar'
import { TagModule } from 'primeng/tag'
import { MessageModule } from 'primeng/message'
import { MessageService, ConfirmationService } from 'primeng/api'
import { Store } from '@ngrx/store'
import { Observable, map } from 'rxjs'
import { UserManagementService } from '@core'
import { AuthService } from '@core'
import { User, CreateUserRequest, PlatformRole, UpdateUserRequest, HierarchicalUser } from '@core'
import { CreateUserDialog } from './create-user-dialog/create-user-dialog'
import { EditRolesDialog } from './edit-roles-dialog/edit-roles-dialog'
import { usersActions, selectUsers, selectLoading, selectError } from '@core'
import { MOCK_TENANTS } from '@core/shared/mocks'

/**
 * Platform user management component.
 * Allows super admins to manage all platform users.
 */
@Component({
  selector: 'platform-user-management',
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    TableModule,
    DialogModule,
    InputTextModule,
    TextareaModule,
    ToastModule,
    ConfirmDialogModule,
    ToolbarModule,
    TagModule,
    MessageModule,
    CreateUserDialog,
    EditRolesDialog,
  ],
  providers: [MessageService, ConfirmationService],
  templateUrl: './user-management.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserManagement implements OnInit {
  private readonly store = inject(Store)
  private readonly userManagementService = inject(UserManagementService)
  private readonly messageService = inject(MessageService)
  private readonly confirmationService = inject(ConfirmationService)
  private readonly authService = inject(AuthService)

  readonly users$: Observable<User[]> = this.store.select(selectUsers)
  readonly loading$: Observable<boolean> = this.store.select(selectLoading)
  readonly error$: Observable<string | null> = this.store.select(selectError)

  readonly inviting = signal(false)
  readonly savingRoles = signal(false)
  readonly togglingStatus = signal(false)
  readonly removingUser = signal(false)
  readonly transferringOwnership = signal(false)
  readonly createUserDialogVisible = signal(false)
  readonly editRolesDialogVisible = signal(false)
  readonly selectedUserForAction = signal<HierarchicalUser | null>(null)

  readonly hierarchicalUsers$ = this.users$.pipe(
    map((users: User[]) => this.createHierarchicalUsers(users))
  )

  readonly availableGlobalRoles = [
    { value: 'super_admin' as PlatformRole, label: $localize`:@@super-admin:Super Admin` },
    { value: 'user' as PlatformRole, label: $localize`:@@role.user:User` },
  ]

  /**
   * Initialize component and load users.
   */
  ngOnInit() {
    this.store.dispatch(usersActions.loadUsers())
  }

  /**
   * Open create user dialog.
   */
  openCreateUserDialog() {
    this.createUserDialogVisible.set(true)
  }

  /**
   * Handle create user dialog visibility change.
   * @param visible Whether the dialog is visible.
   */
  onCreateUserDialogVisibleChange(visible: boolean) {
    this.createUserDialogVisible.set(visible)
  }

  /**
   * Handle save user from create user dialog.
   * @param data The user creation data from the dialog.
   * @param data.formValue The form values.
   * @param data.formValue.firstName The user's first name.
   * @param data.formValue.lastName The user's last name.
   * @param data.formValue.email The user's email (optional).
   * @param data.formValue.username The user's username (optional).
   * @param data.formValue.contactEmail The user's contact email (optional).
   * @param data.formValue.phone The user's phone (optional).
   * @param data.formValue.password The user's password (optional).
   * @param data.formValue.globalRole The user's global role.
   */
  onSaveUser(data: {
    formValue: {
      firstName: string
      lastName: string
      email?: string
      username?: string
      contactEmail?: string
      phone?: string
      password?: string
      globalRole: PlatformRole
    }
  }) {
    const formValue = data.formValue

    const createData: CreateUserRequest = {
      firstName: formValue.firstName,
      lastName: formValue.lastName,
      email: formValue.email,
      username: formValue.username,
      contactEmail: formValue.contactEmail,
      phone: formValue.phone,
      password: formValue.password,
      globalRole: formValue.globalRole,
      sendInvitation: !formValue.password,
    }

    this.store.dispatch(usersActions.createUser({ request: createData }))
    this.createUserDialogVisible.set(false)
  }

  /**
   * Open edit roles dialog.
   * @param hierarchicalUser The hierarchical user to edit roles for.
   */
  openEditRolesDialog(hierarchicalUser: HierarchicalUser) {
    this.selectedUserForAction.set(hierarchicalUser)
    this.editRolesDialogVisible.set(true)
  }

  /**
   * Handle edit roles dialog visibility change.
   * @param visible Whether the dialog is visible.
   */
  onEditRolesDialogVisibleChange(visible: boolean) {
    this.editRolesDialogVisible.set(visible)
  }

  /**
   * Handle save user roles from dialog.
   * @param data The role update data from the dialog.
   * @param data.userId The user ID.
   * @param data.role The selected role.
   */
  onSaveUserRoles(data: { userId: string; role: PlatformRole }) {
    const updateRequest: UpdateUserRequest = {
      globalRole: data.role,
    }

    this.store.dispatch(usersActions.updateUser({ userId: data.userId, request: updateRequest }))
    this.editRolesDialogVisible.set(false)
    this.selectedUserForAction.set(null)
  }

  /**
   * Toggle user active status.
   * @param hierarchicalUser The hierarchical user to toggle status for.
   */
  toggleUserStatus(hierarchicalUser: HierarchicalUser) {
    const user = hierarchicalUser.user
    const action = user.isActive ? 'deactivate' : 'activate'
    this.confirmationService.confirm({
      message: $localize`:@@confirmUserStatusToggle:Are you sure you want to ${action} user ${user.firstName} ${user.lastName}?`,
      header: $localize`:@@confirmAction:Confirm Action`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: $localize`:@@yes:Yes`,
      rejectLabel: $localize`:@@no:No`,
      accept: () => {
        if (user.isActive) {
          this.store.dispatch(usersActions.deactivateUser({ userId: user.id }))
        } else {
          this.store.dispatch(usersActions.activateUser({ userId: user.id }))
        }
      },
    })
  }

  /**
   * Confirm user removal.
   * @param hierarchicalUser The hierarchical user to remove.
   */
  confirmRemoveUser(hierarchicalUser: HierarchicalUser) {
    const user = hierarchicalUser.user
    this.confirmationService.confirm({
      message: $localize`:@@confirmUserRemoval:Are you sure you want to remove user ${user.firstName} ${user.lastName}? This action cannot be undone.`,
      header: $localize`:@@confirmRemoval:Confirm Removal`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: $localize`:@@remove:Remove`,
      rejectLabel: $localize`:@@cancel:Cancel`,
      acceptButtonStyleClass: 'p-button-danger',
      accept: () => {
        this.store.dispatch(usersActions.deleteUser({ userId: user.id }))
      },
    })
  }

  /**
   * Check if current user can perform actions on target user.
   * @param targetUser The user to check permissions for.
   * @returns True if actions are allowed, false otherwise.
   */
  canPerformActionsOnUser(targetUser: User): boolean {
    const currentUser = this.authService.currentUser()
    if (!currentUser) return false

    if (currentUser.globalRole !== 'super_admin') return false

    if (currentUser.id === targetUser.id) return false

    return true
  }

  /**
   * Check if current user can edit roles of target user.
   * @param targetUser The user to check permissions for.
   * @returns True if role editing is allowed, false otherwise.
   */
  canEditRolesOfUser(targetUser: User): boolean {
    const currentUser = this.authService.currentUser()
    if (!currentUser) return false

    if (currentUser.globalRole !== 'super_admin') return false

    if (currentUser.id === targetUser.id) return false

    return true
  }

  /**
   * Check if the selected user is the current user.
   * @returns True if the selected user is the current user, false otherwise.
   */
  isSelectedUserCurrentUser(): boolean {
    const currentUser = this.authService.currentUser()
    const selectedUser = this.selectedUserForAction()
    return currentUser && selectedUser ? currentUser.id === selectedUser.user.id : false
  }

  /**
   * Get CSS class for global role badge.
   * @param role The global role.
   * @returns CSS class string for the role badge.
   */
  getRoleBadgeClass(role: PlatformRole): string {
    switch (role) {
      case 'super_admin':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      case 'platform-admin':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
      case 'user':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  /**
   * Get severity for global role tag.
   * @param role The global role.
   * @returns Severity string for the tag.
   */
  getRoleSeverity(
    role: PlatformRole | undefined
  ): 'info' | 'success' | 'warn' | 'danger' | 'secondary' | 'contrast' {
    if (!role) return 'secondary'
    switch (role) {
      case 'super_admin':
        return 'warn'
      case 'platform-admin':
        return 'info'
      case 'user':
        return 'info'
      default:
        return 'secondary'
    }
  }

  /**
   * Get human-readable global role label.
   * @param role The global role.
   * @returns Human-readable label for the role.
   */
  getRoleLabel(role: PlatformRole): string {
    switch (role) {
      case 'super_admin':
        return $localize`:@@super-admin:Super Admin`
      case 'platform-admin':
        return $localize`:@@platform-admin:Platform Admin`
      case 'user':
        return $localize`:@@role.user:User`
      default:
        return role
    }
  }

  /**
   * Get human-readable role label for display.
   * For tenant owners, shows "Tenant Owner" instead of their global role.
   * @param hierarchicalUser The hierarchical user.
   * @returns Human-readable label for the role.
   */
  getDisplayRoleLabel(hierarchicalUser: HierarchicalUser): string {
    const isTenantOwner = hierarchicalUser.user.tenantRoles?.some((role) => role.role === 'owner')
    if (isTenantOwner) {
      return $localize`:@@tenant-owner:Tenant Owner`
    }

    const globalRole = hierarchicalUser.user.globalRole
    return globalRole ? this.getRoleLabel(globalRole) : $localize`:@@role.unknown:Unknown`
  }

  /**
   * Create hierarchical user structure from flat user list.
   * Groups users by tenant ownership for better organization.
   * @param users Flat list of users.
   * @returns Hierarchical user structure.
   */
  private createHierarchicalUsers(users: User[]): HierarchicalUser[] {
    const hierarchicalUsers: HierarchicalUser[] = []

    users.forEach((user) => {
      let tenant: { id: string; name: string; subdomain: string; schemaName: string } | undefined

      if (user.tenant) {
        tenant = {
          id: user.tenant.id,
          name: user.tenant.name,
          subdomain: user.tenant.subdomain,
          schemaName: user.tenant.subdomain,
        }
      } else {
        const tenantRole = user.tenantRoles?.[0]
        if (tenantRole) {
          tenant = MOCK_TENANTS.find((t) => t.id === tenantRole.tenantId)
        }
      }

      hierarchicalUsers.push({
        user,
        tenant,
        level: 0,
      })
    })

    return hierarchicalUsers
  }
}
