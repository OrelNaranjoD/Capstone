import { Component, input, output, signal, effect } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ButtonModule } from 'primeng/button'
import { DialogModule } from 'primeng/dialog'
import { User, PlatformRole } from '@core'

/**
 * Edit user roles dialog component for platform.
 * Allows editing global roles for an existing user.
 */
@Component({
  selector: 'platform-edit-roles-dialog',
  standalone: true,
  imports: [CommonModule, ButtonModule, DialogModule],
  templateUrl: './edit-roles-dialog.html',
})
export class EditRolesDialog {
  readonly visible = input(false)
  readonly saving = input(false)
  readonly user = input<User | null | undefined>(null)
  readonly visibleChange = output<boolean>()
  readonly save = output<{ userId: string; role: PlatformRole }>()
  readonly selectedRole = signal<PlatformRole>('platform-admin')
  readonly availableGlobalRoles = [
    {
      value: 'platform-admin' as PlatformRole,
      label: $localize`:@@platform-admin:Platform Admin`,
    },
    { value: 'super_admin' as PlatformRole, label: $localize`:@@super-admin:Super Admin` },
  ]

  constructor() {
    effect(() => {
      const currentUser = this.user()
      if (currentUser) {
        this.selectedRole.set(currentUser.globalRole || 'platform-admin')
      } else {
        this.selectedRole.set('platform-admin')
      }
    })
  }

  /**
   * Handle dialog visibility change.
   * @param visible Whether the dialog is visible.
   */
  onVisibleChange(visible: boolean) {
    this.visibleChange.emit(visible)
    if (!visible) {
      this.selectedRole.set('platform-admin')
    }
  }

  /**
   * Save role changes.
   */
  saveChanges() {
    if (this.user()) {
      this.save.emit({
        userId: this.user()!.id,
        role: this.selectedRole(),
      })
    }
  }

  /**
   * Check if a role is selected.
   * @param role The role to check.
   * @returns True if the role is selected.
   */
  isRoleSelected(role: PlatformRole): boolean {
    return this.selectedRole() === role
  }

  /**
   * Select a role.
   * @param role The role to select.
   */
  selectRole(role: PlatformRole) {
    this.selectedRole.set(role)
  }
}
