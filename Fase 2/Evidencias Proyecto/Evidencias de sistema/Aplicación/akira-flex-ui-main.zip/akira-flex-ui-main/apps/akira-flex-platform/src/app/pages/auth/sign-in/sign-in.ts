import { Component, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms'
import { Router } from '@angular/router'
import { Card } from 'primeng/card'
import { InputText } from 'primeng/inputtext'
import { Password } from 'primeng/password'
import { Button } from 'primeng/button'
import { Message } from 'primeng/message'
import { AuthService, BackendErrorDetail } from '@core'
import { Logotype } from '@core/components/logotype/logotype'
import { emailValidator } from '@core/utils'

/**
 * Sign-in page component for system administrators.
 * Provides a full-screen sign-in form exclusively for platform administrators.
 */
@Component({
  selector: 'platform-sign-in',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    Card,
    InputText,
    Password,
    Button,
    Message,
    Logotype,
  ],
  templateUrl: './sign-in.html',
})
export class SignIn {
  private readonly fb = inject(FormBuilder)
  private readonly authService = inject(AuthService)
  private readonly router = inject(Router)
  readonly isLoading = signal(false)
  readonly errorMessage = signal<string | null>(null)
  readonly isAccountLocked = signal(false)
  readonly lockoutTimeRemaining = signal(0)
  readonly signInForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, emailValidator]],
    password: ['', [Validators.required, Validators.minLength(8)]],
  })

  /**
   * Map backend error keys to localized messages.
   * @param errorData The error data received from the backend.
   * @returns Localized error message string.
   */
  private mapBackendErrorKey(errorData: BackendErrorDetail): string {
    const { key, details } = errorData

    switch (key) {
      case 'ACCOUNT_LOCKED': {
        const minutes = details?.minutes ?? 30
        this.isAccountLocked.set(true)
        return $localize`:@@accountLocked:Account locked. Try again in ${minutes} minutes.`
      }

      case 'INCORRECT_CREDENTIALS': {
        const remaining = details?.attemptsRemaining
        if (remaining !== undefined && remaining > 0) {
          return $localize`:@@incorrectCredentials:Incorrect credentials. You have ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`
        }
        return $localize`:@@incorrectCredentialsGeneric:Incorrect email or password.`
      }

      case 'UNAUTHORIZED_ADMIN':
        return $localize`:@@unauthorizedAccess:Access denied. Only system administrators can sign in.`

      case 'TOO_MANY_REQUESTS':
        return $localize`:@@tooManyAttempts:Too many attempts. Try again later.`

      default:
        return $localize`:@@error.signIn:Error signing in. Try again.`
    }
  }

  /**
   * Handle form submission.
   */
  onSubmit(): void {
    if (this.signInForm.invalid) {
      this.markFormGroupTouched()
      return
    }

    this.isAccountLocked.set(false)
    this.isLoading.set(true)
    this.errorMessage.set(null)

    const { email, password } = this.signInForm.value

    this.authService.login({ email, password, remember: false }).subscribe({
      next: (response) => {
        if (response.user.isSuperAdmin) {
          this.isLoading.set(false)
          this.authService.logout()
          this.errorMessage.set(
            $localize`:@@unauthorizedAccess:Access denied. Only system administrators can sign in.`
          )
          return
        }

        this.isLoading.set(false)
        this.router.navigate(['/'])
      },
      error: (error) => {
        this.isLoading.set(false)
        this.handleSignInError(error)
      },
    })
  }

  /**
   * Handle sign-in errors by mapping the backend key to a localized message.
   * @param error The error object from the sign-in attempt.
   */
  private handleSignInError(error: unknown): void {
    this.isAccountLocked.set(false)

    if (error && typeof error === 'object' && 'status' in error) {
      const httpError = error as { status: number; error: BackendErrorDetail }

      const errorData = httpError.error

      if (errorData && errorData.key) {
        this.errorMessage.set(this.mapBackendErrorKey(errorData))
      } else if (httpError.status === 429) {
        this.errorMessage.set($localize`:@@tooManyAttempts:Too many attempts. Try again later.`)
      } else {
        this.errorMessage.set($localize`:@@error.signIn:Error signing in. Try again.`)
      }
    } else {
      this.errorMessage.set($localize`:@@error.signIn:Error signing in. Try again.`)
    }
  }

  /**
   * Mark all form controls as touched to show validation errors.
   */
  private markFormGroupTouched(): void {
    Object.keys(this.signInForm.controls).forEach((key) => {
      const control = this.signInForm.get(key)
      control?.markAsTouched()
    })
  }
}
