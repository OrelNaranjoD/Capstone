export const environment = {
  production: true,
  apiBaseUrl: 'http://localhost:3000',
  tenantSubdomain: 'akiraflex',
  appBaseUrl: 'https://akiraflex.com',
}
