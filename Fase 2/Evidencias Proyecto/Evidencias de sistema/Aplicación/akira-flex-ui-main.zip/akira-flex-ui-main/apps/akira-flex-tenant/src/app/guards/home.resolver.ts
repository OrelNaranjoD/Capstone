import { Injectable, inject } from '@angular/core'
import { Resolve } from '@angular/router'
import { Observable, of } from 'rxjs'
import { map } from 'rxjs/operators'
import { UserManagementStateService } from '../pages/user-management/user-management.service'
import { UserListResponse } from '@core'

/**
 * Resolver for home page that ensures tenant user data is loaded.
 * This prevents loading states on the home page after login.
 */
@Injectable({
  providedIn: 'root',
})
export class HomeResolver implements Resolve<UserListResponse | null> {
  private readonly tenantUserState = inject(UserManagementStateService)

  /**
   * Resolve home page data.
   * Ensures user data is available without showing loading states.
   * @returns Observable that completes when data is ready.
   */
  resolve(): Observable<UserListResponse | null> {
    const cachedData = this.tenantUserState.getCachedDataIfFresh(10)
    if (cachedData) {
      return of(cachedData)
    }

    if (!this.tenantUserState.hasData() || this.tenantUserState.isDataStale(10)) {
      return this.tenantUserState
        .loadData({ page: 1, perPage: 10 })
        .pipe(map((response: UserListResponse) => response))
    }

    return of(null)
  }
}
