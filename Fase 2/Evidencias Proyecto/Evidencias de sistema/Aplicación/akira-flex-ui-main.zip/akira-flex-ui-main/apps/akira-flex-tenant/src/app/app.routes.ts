import { Routes } from '@angular/router'
import { authGuard } from '@core'

export const ROUTES: Routes = [
  {
    path: 'auth',
    children: [
      {
        path: 'sign-in',
        loadComponent: () => import('./pages/auth/sign-in/sign-in').then((m) => m.SignIn),
      },
      {
        path: 'password-recovery',
        loadComponent: () =>
          import('./pages/auth/password-recovery/password-recovery').then(
            (m) => m.PasswordRecovery
          ),
      },
    ],
  },
  {
    path: 'activate',
    loadComponent: () => import('./pages/auth/activate/activate').then((m) => m.Activate),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./components/layout/layout').then((m) => m.Layout),
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'home',
      },
      {
        path: 'home',
        loadComponent: () => import('./pages/home/home').then((m) => m.TenantHome),
      },
      {
        path: 'users',
        loadComponent: () =>
          import('./pages/user-management/user-management').then((m) => m.UserManagement),
      },
    ],
  },
  {
    path: '**',
    loadComponent: () => import('@core').then((m) => m.PageNotFound),
  },
]
