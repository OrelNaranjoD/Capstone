import { Component, inject, input, output, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import {
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms'
import { ButtonModule } from 'primeng/button'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { PasswordModule } from 'primeng/password'
import { CheckboxModule } from 'primeng/checkbox'
import { CreateTenantUserRequest, TenantRole } from '@core'

/**
 * Create user dialog component for tenant user management.
 * Handles user creation with proper validation and internationalization.
 */
@Component({
  selector: 'tenant-create-user-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    PasswordModule,
    CheckboxModule,
  ],
  templateUrl: './create-user-dialog.html',
})
export class CreateUserDialog {
  private readonly fb = inject(FormBuilder)

  readonly visible = input.required<boolean>()
  readonly saving = input.required<boolean>()

  readonly visibleChange = output<boolean>()
  readonly save = output<{
    formValue: CreateTenantUserRequest
  }>()

  readonly userForm: FormGroup

  readonly selectedRoles = signal<TenantRole[]>(['user'])

  readonly availableTenantRoles = [
    { value: 'owner' as TenantRole, label: $localize`:@@role.owner:Owner` },
    { value: 'admin' as TenantRole, label: $localize`:@@role.admin:Administrator` },
    { value: 'manager' as TenantRole, label: $localize`:@@role.manager:Manager` },
    { value: 'user' as TenantRole, label: $localize`:@@role.user:User` },
    { value: 'viewer' as TenantRole, label: $localize`:@@role.viewer:Viewer` },
  ]

  constructor() {
    this.userForm = this.fb.group(
      {
        username: ['', [Validators.required, Validators.minLength(3)]],
        firstName: ['', [Validators.required, Validators.minLength(2)]],
        lastName: ['', [Validators.required, Validators.minLength(2)]],
        password: ['', [Validators.required, Validators.minLength(8)]],
        confirmPassword: ['', [Validators.required]],
        contactEmail: ['', [Validators.email]],
      },
      { validators: this.passwordMatchValidator }
    )
  }

  /**
   * Handle dialog hide event.
   */
  onHide(): void {
    this.visibleChange.emit(false)
    this.userForm.reset()
    this.selectedRoles.set(['user'])
  }

  /**
   * Handle form submission.
   */
  onSave(): void {
    if (this.userForm.valid && this.selectedRoles().length > 0) {
      const formValue = this.userForm.value
      const createData: CreateTenantUserRequest = {
        username: formValue.username,
        firstName: formValue.firstName,
        lastName: formValue.lastName,
        password: formValue.password,
        roles: this.selectedRoles(),
        contactEmail: formValue.contactEmail || undefined,
      }
      this.save.emit({ formValue: createData })
    }
  }

  /**
   * Check if a role is selected.
   * @param role The role to check.
   * @returns True if the role is selected.
   */
  isRoleSelected(role: TenantRole): boolean {
    return this.selectedRoles().includes(role)
  }

  /**
   * Toggle a role selection.
   * @param role The role to toggle.
   * @param checked Whether the checkbox is checked.
   */
  toggleRole(role: TenantRole, checked: boolean) {
    if (role === 'owner') {
      return
    }

    if (checked) {
      this.selectedRoles.update((roles) => [...roles, role])
    } else {
      this.selectedRoles.update((roles) => roles.filter((r) => r !== role))
      if (this.selectedRoles().length === 0) {
        this.selectedRoles.set(['user'])
      }
    }
  }

  /**
   * Handle role checkbox change event.
   * @param role The role that changed.
   * @param checked The new checked state.
   */
  onRoleChange(role: TenantRole, checked: boolean): void {
    this.toggleRole(role, checked)
  }

  /**
   * Custom validator to ensure passwords match.
   * @param formGroup The form group to validate.
   * @returns Validation error object or null if valid.
   */
  private passwordMatchValidator(formGroup: FormGroup): { [key: string]: boolean } | null {
    const password = formGroup.get('password')?.value
    const confirmPassword = formGroup.get('confirmPassword')?.value

    if (password && confirmPassword && password !== confirmPassword) {
      return { passwordMismatch: true }
    }

    return null
  }
}
