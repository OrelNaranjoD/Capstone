import {
  HttpInterceptorFn,
  HttpResponse,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http'
import { tap } from 'rxjs'

/**
 * DEBUG interceptor that logs all outgoing HTTP requests and responses.
 * This interceptor is useful for debugging API calls and monitoring network traffic.
 * @param req The outgoing HTTP request.
 * @param next The next interceptor in the chain.
 * @returns Observable of HTTP events.
 */
export const debugInterceptor: HttpInterceptorFn = (req, next) => {
  const startTime = Date.now()
  const requestId = Math.random().toString(36).substr(2, 9)

  console.group(`🚀 [DEBUG] HTTP Request #${requestId}`)
  console.log('Method:', req.method)
  console.log('URL:', req.url)
  console.log('Headers:', formatHeaders(req.headers))
  console.log('Body:', req.body)
  console.log('WithCredentials:', req.withCredentials)
  console.groupEnd()

  return next(req).pipe(
    tap({
      next: (event) => {
        if (event instanceof HttpResponse) {
          const duration = Date.now() - startTime

          console.group(`✅ [DEBUG] HTTP Response #${requestId} (${duration}ms)`)
          console.log('Status:', event.status, event.statusText)
          console.log('URL:', event.url)
          console.log('Headers:', formatHeaders(event.headers))
          console.log('Body:', formatBody(event.body))
          console.groupEnd()
        }
      },
      error: (error) => {
        const duration = Date.now() - startTime

        if (error instanceof HttpErrorResponse) {
          console.group(`[DEBUG] HTTP Error #${requestId} (${duration}ms)`)
          console.log('Status:', error.status, error.statusText)
          console.log('URL:', error.url)
          console.log('Headers:', formatHeaders(error.headers))
          console.log('Error:', error.error)
          console.log('Message:', error.message)
          console.groupEnd()
        } else {
          console.group(`[DEBUG] HTTP Error #${requestId} (${duration}ms)`)
          console.log('Error:', error)
          console.groupEnd()
        }
      },
    })
  )
}

/**
 * Formats HTTP headers for logging.
 * @param headers The headers to format.
 * @returns Formatted headers object.
 */
function formatHeaders(headers: HttpHeaders): Record<string, string> {
  const formatted: Record<string, string> = {}
  headers.keys().forEach((key: string) => {
    formatted[key] = headers.get(key) || ''
  })
  return formatted
}

/**
 * Formats response body for logging, truncating large responses.
 * @param body The response body to format.
 * @returns Formatted body.
 */
function formatBody(body: unknown): unknown {
  if (!body) return body

  try {
    const bodyString = JSON.stringify(body)
    if (bodyString.length > 1000) {
      return `${bodyString.substring(0, 1000)}... [TRUNCATED - ${bodyString.length} chars total]`
    }
    return body
  } catch {
    return body
  }
}
