import { Injectable, signal, computed } from '@angular/core'
import { User, UserListResponse } from '@core'

/**
 * State management service for tenant user data.
 * Provides centralized state for user management across the tenant application.
 */
@Injectable({
  providedIn: 'root',
})
export class UserManagementStateService {
  private readonly _users = signal<User[]>([])
  private readonly _loading = signal(false)
  private readonly _lastUpdated = signal<Date | null>(null)
  private readonly _total = signal(0)
  private readonly _page = signal(1)
  private readonly _limit = signal(10)
  private readonly _totalPages = signal(0)
  readonly users = computed(() => this._users())
  readonly loading = computed(() => this._loading())
  readonly lastUpdated = computed(() => this._lastUpdated())
  readonly hasData = computed(() => this._users().length > 0)
  readonly userCount = computed(() => this._users().length)
  readonly total = computed(() => this._total())
  readonly page = computed(() => this._page())
  readonly limit = computed(() => this._limit())
  readonly totalPages = computed(() => this._totalPages())

  /**
   * Set users data and update timestamp.
   * @param users Array of users to store.
   */
  setUsers(users: User[]): void {
    this._users.set(users)
    this._lastUpdated.set(new Date())
  }

  /**
   * Update loading state.
   * @param loading Whether data is being loaded.
   */
  setLoading(loading: boolean): void {
    this._loading.set(loading)
  }

  /**
   * Set pagination data.
   * @param total Total number of users.
   * @param page Current page.
   * @param limit Items per page.
   * @param totalPages Total number of pages.
   */
  setPagination(total: number, page: number, limit: number, totalPages: number): void {
    this._total.set(total)
    this._page.set(page)
    this._limit.set(limit)
    this._totalPages.set(totalPages)
  }

  /**
   * Set current page.
   * @param page The page number to set.
   */
  setPage(page: number): void {
    this._page.set(page)
  }

  /**
   * Set items per page limit.
   * @param limit The number of items per page.
   */
  setLimit(limit: number): void {
    this._limit.set(limit)
  }

  /**
   * Add a new user to the state.
   * @param user The user to add.
   */
  addUser(user: User): void {
    const currentUsers = this._users()
    this._users.set([...currentUsers, user])
    this._lastUpdated.set(new Date())
  }

  /**
   * Update an existing user in the state.
   * @param updatedUser The updated user data.
   */
  updateUser(updatedUser: User): void {
    const currentUsers = this._users()
    const index = currentUsers.findIndex((u) => u.id === updatedUser.id)

    if (index >= 0) {
      const updatedUsers = [...currentUsers]
      updatedUsers[index] = updatedUser
      this._users.set(updatedUsers)
      this._lastUpdated.set(new Date())
    }
  }

  /**
   * Remove a user from the state.
   * @param userId The ID of the user to remove.
   */
  removeUser(userId: string): void {
    const currentUsers = this._users()
    const filteredUsers = currentUsers.filter((u) => u.id !== userId)
    this._users.set(filteredUsers)
    this._lastUpdated.set(new Date())
  }

  /**
   * Clear all user data.
   */
  clearUsers(): void {
    this._users.set([])
    this._lastUpdated.set(null)
  }

  /**
   * Get user by ID.
   * @param userId The ID of the user to find.
   * @returns The user if found, null otherwise.
   */
  getUserById(userId: string): User | null {
    return this._users().find((u) => u.id === userId) || null
  }

  /**
   * Check if data is stale (older than specified minutes).
   * @param maxAgeMinutes Maximum age in minutes before considering data stale.
   * @returns True if data is stale or missing.
   */
  isDataStale(maxAgeMinutes: number = 5): boolean {
    const lastUpdated = this._lastUpdated()
    if (!lastUpdated) return true

    const now = new Date()
    const diffMs = now.getTime() - lastUpdated.getTime()
    const diffMinutes = diffMs / (1000 * 60)

    return diffMinutes > maxAgeMinutes
  }

  /**
   * Reset all state to initial values.
   */
  reset(): void {
    this._users.set([])
    this._loading.set(false)
    this._lastUpdated.set(null)
    this._total.set(0)
    this._page.set(1)
    this._limit.set(10)
    this._totalPages.set(0)
  }

  /**
   * Check if state is valid and has data.
   * @returns True if state has valid data.
   */
  isValid(): boolean {
    return this._users().length > 0 && this._lastUpdated() !== null
  }

  /**
   * Get users filtered by role.
   * @param role The role to filter by.
   * @returns Array of users with the specified role.
   */
  getUsersByRole(role: string): User[] {
    return this._users().filter((user) => user.tenantRoles?.some((tr) => tr.role === role))
  }

  /**
   * Get active users only.
   * @returns Array of active users.
   */
  getActiveUsers(): User[] {
    return this._users().filter((user) => user.isActive)
  }

  /**
   * Get user statistics.
   * @returns Object with user statistics.
   */
  getUserStats(): {
    total: number
    active: number
    inactive: number
    owners: number
    admins: number
    users: number
  } {
    const users = this._users()
    const active = users.filter((u) => u.isActive).length
    const owners = users.filter((u) => u.tenantRoles?.some((tr) => tr.role === 'owner')).length
    const admins = users.filter((u) => u.tenantRoles?.some((tr) => tr.role === 'admin')).length
    const regularUsers = users.filter((u) => u.tenantRoles?.some((tr) => tr.role === 'user')).length

    return {
      total: users.length,
      active,
      inactive: users.length - active,
      owners,
      admins,
      users: regularUsers,
    }
  }

  /**
   * Refresh data from server response.
   * @param response The server response with user data.
   */
  refreshFromResponse(response: UserListResponse): void {
    this.setUsers(response.users)
    this.setPagination(response.total, response.page, response.limit, response.totalPages)
    this.setLoading(false)
  }
}
