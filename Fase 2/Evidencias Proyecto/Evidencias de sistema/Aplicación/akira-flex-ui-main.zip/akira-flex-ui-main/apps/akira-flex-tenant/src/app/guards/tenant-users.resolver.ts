import { Injectable, inject } from '@angular/core'
import { Resolve, Router } from '@angular/router'
import { Observable, of } from 'rxjs'
import { catchError, map } from 'rxjs/operators'
import { UserManagementService } from '@core'
import { UserListResponse } from '@core'
import { UserManagementStateService } from '../pages/user-management/user-management.service'

/**
 * Resolver for tenant users data.
 * Loads user data before navigating to user management page.
 */
@Injectable({
  providedIn: 'root',
})
export class TenantUsersResolver implements Resolve<UserListResponse | null> {
  private readonly userManagementService = inject(UserManagementService)
  private readonly router = inject(Router)
  private readonly tenantUserState = inject(UserManagementStateService)

  /**
   * Resolve tenant users data.
   * @returns Observable with user list response or null on error.
   */
  resolve(): Observable<UserListResponse | null> {
    const cachedData = this.tenantUserState.getCachedDataIfFresh(5)
    if (cachedData) {
      return of(cachedData)
    }

    this.tenantUserState.setLoading(true)

    return this.userManagementService.getUsers().pipe(
      map((response: UserListResponse) => {
        const tenantUsers = response.users.filter(
          (user) => user.tenantRoles && user.tenantRoles.length > 0
        )

        const filteredResponse = {
          ...response,
          users: tenantUsers,
        }

        this.tenantUserState.refreshFromResponse(filteredResponse)

        return filteredResponse
      }),
      catchError((error) => {
        console.error('TenantUsersResolver: Error loading tenant users:', error)
        this.tenantUserState.setLoading(false)
        return of(null)
      })
    )
  }
}
