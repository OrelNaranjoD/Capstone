interface Environment {
  production: boolean
  apiBaseUrl: string
  tenantSubdomain: string
  appBaseUrl: string
}

export const environment: Environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000/api/v1',
  tenantSubdomain: 'maestranzas-unidos',
  appBaseUrl: 'http://localhost:4202',
}
