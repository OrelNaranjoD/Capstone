import { vi } from 'vitest'
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing'
import { ReactiveFormsModule } from '@angular/forms'
import { of, throwError } from 'rxjs'
import { NO_ERRORS_SCHEMA, Component } from '@angular/core'
import { Store } from '@ngrx/store'
import { UserManagement } from '../../../app/pages/user-management/user-management'
import { UserManagementService } from '@core'
import { AuthService, GlobalConfigService, APP_COOKIE_PREFIX } from '@core'
import { MessageService, ConfirmationService } from 'primeng/api'
import { UserManagementStateService } from '../../../app/pages/user-management/user-management.service'
import { User, TenantRole, PlatformRole } from '@core'

@Component({
  selector: 'tenant-mock-confirm-dialog',
  template: '',
})
class MockConfirmDialog {}

let mockUserManagementService: {
  getUsers: ReturnType<typeof vi.fn>
  inviteUser: ReturnType<typeof vi.fn>
  createTenantUser: ReturnType<typeof vi.fn>
  updateUserRoles: ReturnType<typeof vi.fn>
  activateUser: ReturnType<typeof vi.fn>
  deactivateUser: ReturnType<typeof vi.fn>
  softDeleteUser: ReturnType<typeof vi.fn>
  transferOwnership: ReturnType<typeof vi.fn>
}

let mockAuthService: {
  currentUser: ReturnType<typeof vi.fn>
}

let mockMessageService: {
  add: ReturnType<typeof vi.fn>
}

let mockConfirmationService: {
  confirm: ReturnType<typeof vi.fn>
}

let mockTenantUserState: {
  users: ReturnType<typeof vi.fn>
  loading: ReturnType<typeof vi.fn>
  hasData: ReturnType<typeof vi.fn>
  isDataStale: ReturnType<typeof vi.fn>
  total: ReturnType<typeof vi.fn>
  page: ReturnType<typeof vi.fn>
  limit: ReturnType<typeof vi.fn>
  setLoading: ReturnType<typeof vi.fn>
  refreshFromResponse: ReturnType<typeof vi.fn>
  updateUser: ReturnType<typeof vi.fn>
  removeUser: ReturnType<typeof vi.fn>
}

const mockUsers: User[] = [
  {
    id: '1',
    email: 'owner@example.com',
    firstName: 'John',
    lastName: 'Owner',
    phone: '+1234567890',
    globalRole: 'user' as PlatformRole,
    tenantRoles: [
      {
        tenantId: 'tenant-1',
        role: 'owner' as TenantRole,
        assignedAt: new Date('2023-01-01T00:00:00Z'),
        assignedBy: 'system',
        assignedByRole: 'super_admin',
      },
    ],
    onboardingCompleted: true,
    isActive: true,
    createdAt: new Date('2023-01-01T00:00:00Z'),
    updatedAt: new Date('2023-01-01T00:00:00Z'),
  },
]

describe('UserManagement', () => {
  let component: UserManagement
  let fixture: ComponentFixture<UserManagement>

  beforeEach(async () => {
    mockUserManagementService = {
      getUsers: vi.fn(() => of({ users: [], total: 0, page: 1, limit: 10, totalPages: 1 })),
      inviteUser: vi.fn(),
      createTenantUser: vi.fn(),
      updateUserRoles: vi.fn(),
      activateUser: vi.fn(),
      deactivateUser: vi.fn(),
      softDeleteUser: vi.fn(),
      transferOwnership: vi.fn(),
    }

    mockAuthService = {
      currentUser: vi.fn(),
    }

    mockMessageService = {
      add: vi.fn(),
    }

    mockConfirmationService = {
      confirm: vi.fn((config) => {
        setTimeout(() => config.accept(), 0)
        return of(null)
      }),
    }

    mockTenantUserState = {
      users: vi.fn(() => []),
      loading: vi.fn(() => false),
      hasData: vi.fn(() => true),
      isDataStale: vi.fn(() => false),
      total: vi.fn(() => 0),
      page: vi.fn(() => 1),
      limit: vi.fn(() => 10),
      setLoading: vi.fn(),
      refreshFromResponse: vi.fn(),
      updateUser: vi.fn(),
      removeUser: vi.fn(),
    }

    await TestBed.configureTestingModule({
      imports: [UserManagement, ReactiveFormsModule, MockConfirmDialog],
      providers: [
        { provide: UserManagementService, useValue: mockUserManagementService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: MessageService, useValue: mockMessageService },
        { provide: ConfirmationService, useValue: mockConfirmationService },
        { provide: UserManagementStateService, useValue: mockTenantUserState },
        { provide: APP_COOKIE_PREFIX, useValue: 'tenant' },
        {
          provide: GlobalConfigService,
          useValue: {
            configureApiEndpoints: vi.fn(),
            configureApiBaseUrl: vi.fn(),
            configureTenantSubdomain: vi.fn(),
          },
        },
        {
          provide: Store,
          useValue: {
            select: vi.fn(),
            dispatch: vi.fn(),
            selectSignal: vi.fn(() => vi.fn(() => null)),
          },
        },
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })

    TestBed.overrideComponent(UserManagement, {
      set: {
        template: `<div class="test-host"></div>`,
        imports: [
          (await import('@angular/common')).CommonModule,
          (await import('@angular/forms')).ReactiveFormsModule,
        ],
      },
    })

    await TestBed.compileComponents()

    fixture = TestBed.createComponent(UserManagement)
    component = fixture.componentInstance

    fixture.detectChanges()
  })

  describe('Initialization', () => {
    it('should create the component', () => {
      expect(component).toBeTruthy()
      expect(component.users).toBeDefined()
      expect(component.loading).toBeDefined()
      expect(component.operationInProgress).toBeDefined()
      expect(component.selectedUser).toBeDefined()
      expect(component.activeDialog).toBeDefined()
    })

    it('should not load users on init when data is not stale', () => {
      mockTenantUserState.hasData.mockReturnValue(true)
      mockTenantUserState.isDataStale.mockReturnValue(false)

      component.ngOnInit()

      expect(mockUserManagementService.getUsers).not.toHaveBeenCalled()
    })

    it('should load tenant users on init when data is stale', () => {
      mockTenantUserState.hasData.mockReturnValue(false)
      mockTenantUserState.isDataStale.mockReturnValue(true)
      const mockResponse = { users: mockUsers, total: 1, page: 1, limit: 10, totalPages: 1 }
      mockUserManagementService.getUsers.mockReturnValue(of(mockResponse))

      component.ngOnInit()

      expect(mockUserManagementService.getUsers).toHaveBeenCalled()
    })

    it('should handle error when loading users', fakeAsync(() => {
      mockTenantUserState.hasData.mockReturnValue(false)
      mockTenantUserState.isDataStale.mockReturnValue(true)
      mockUserManagementService.getUsers.mockReturnValue(throwError(() => new Error('API Error')))

      component.ngOnInit()
      tick()

      expect(mockUserManagementService.getUsers).toHaveBeenCalled()
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'error',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))
  })

  describe('Dialog Management', () => {
    it('should open dialog', () => {
      const user = mockUsers[0]
      component.openDialog('invite', user)

      expect(component.selectedUser()).toBe(user)
      expect(component.activeDialog()).toBe('invite')
    })

    it('should close dialog', () => {
      component.activeDialog.set('invite')
      component.selectedUser.set(mockUsers[0])

      component.closeDialog()

      expect(component.activeDialog()).toBe(null)
      expect(component.selectedUser()).toBe(null)
    })
  })

  describe('User Operations', () => {
    beforeEach(() => {
      mockAuthService.currentUser.mockReturnValue(mockUsers[0])
    })

    it('should invite user successfully', fakeAsync(() => {
      const formData = {
        formValue: {
          email: 'invite@example.com',
          firstName: 'Invite',
          lastName: 'User',
          roles: ['user' as TenantRole],
          message: 'Welcome!',
        },
      }
      mockUserManagementService.inviteUser.mockReturnValue(of({}))
      vi.spyOn(component, 'reloadCurrentPage').mockImplementation(() => {})

      component.onInviteUser(formData)
      tick()

      expect(mockUserManagementService.inviteUser).toHaveBeenCalledWith(formData.formValue)
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'success',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))

    it('should handle invite user error', fakeAsync(() => {
      const formData = {
        formValue: {
          email: 'invite@example.com',
          firstName: 'Invite',
          lastName: 'User',
          roles: ['user' as TenantRole],
          message: 'Welcome!',
        },
      }
      mockUserManagementService.inviteUser.mockReturnValue(throwError(() => new Error('API Error')))

      component.onInviteUser(formData)
      tick()

      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'error',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))

    it('should create user successfully', fakeAsync(() => {
      const formData = {
        formValue: {
          firstName: 'New',
          lastName: 'User',
          email: 'new@example.com',
          roles: ['user' as TenantRole],
          password: 'password123',
        },
      }
      mockUserManagementService.createTenantUser.mockReturnValue(of({}))
      vi.spyOn(component, 'reloadCurrentPage').mockImplementation(() => {})

      component.onSaveUser(formData)
      tick()

      expect(mockUserManagementService.createTenantUser).toHaveBeenCalledWith(formData.formValue)
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'success',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))

    it('should save user roles successfully', () => {
      const roleData = { userId: '1', roles: ['admin' as TenantRole] }
      const updatedUser = { ...mockUsers[0] }
      mockUserManagementService.updateUserRoles.mockReturnValue(of(updatedUser))

      component.onSaveUserRoles(roleData)

      expect(mockUserManagementService.updateUserRoles).toHaveBeenCalledWith('1', ['admin'])
      expect(mockTenantUserState.updateUser).toHaveBeenCalledWith(updatedUser)
    })

    it('should toggle user status', fakeAsync(() => {
      const user = { ...mockUsers[0], isActive: false }
      const updatedUser = { ...user, isActive: true }
      mockUserManagementService.activateUser.mockReturnValue(of(updatedUser))
      mockConfirmationService.confirm.mockImplementation((config) => config.accept())

      component.toggleUserStatus(user)
      tick()

      expect(mockConfirmationService.confirm).toHaveBeenCalled()
      expect(mockUserManagementService.activateUser).toHaveBeenCalledWith(user.id)
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'success',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))

    it('should remove user', fakeAsync(() => {
      const user = mockUsers[0]
      mockUserManagementService.softDeleteUser.mockReturnValue(of({}))
      mockConfirmationService.confirm.mockImplementation((config) => config.accept())

      component.confirmRemoveUser(user)
      tick()

      expect(mockConfirmationService.confirm).toHaveBeenCalled()
      expect(mockUserManagementService.softDeleteUser).toHaveBeenCalledWith(user.id)
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'success',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))

    it('should transfer ownership', fakeAsync(() => {
      const newOwner = mockUsers[0]
      mockUserManagementService.transferOwnership.mockReturnValue(of({}))
      mockConfirmationService.confirm.mockImplementation((config) => config.accept())
      vi.spyOn(component, 'reloadCurrentPage').mockImplementation(() => {})

      component.transferOwnership(newOwner)
      tick()

      expect(mockConfirmationService.confirm).toHaveBeenCalled()
      expect(mockUserManagementService.transferOwnership).toHaveBeenCalledWith(newOwner.id)
      expect(mockMessageService.add).toHaveBeenCalledWith({
        severity: 'success',
        summary: expect.any(String),
        detail: expect.any(String),
        life: 3000,
      })
    }))
  })

  describe('Utility Methods', () => {
    it('should get user join date', () => {
      const result = component.getUserJoinDate(mockUsers[0])
      expect(result).toBe(
        mockUsers[0].tenantRoles?.[0]?.assignedAt?.toString() || mockUsers[0].createdAt.toString()
      )
    })

    it('should get permissions for user', () => {
      mockAuthService.currentUser.mockReturnValue(mockUsers[0])
      const permissions = component.getPermissionsFor(mockUsers[0])

      expect(permissions).toHaveProperty('canEdit')
      expect(permissions).toHaveProperty('canToggleStatus')
      expect(permissions).toHaveProperty('canRemove')
      expect(permissions).toHaveProperty('canBeOwner')
    })
  })
})
