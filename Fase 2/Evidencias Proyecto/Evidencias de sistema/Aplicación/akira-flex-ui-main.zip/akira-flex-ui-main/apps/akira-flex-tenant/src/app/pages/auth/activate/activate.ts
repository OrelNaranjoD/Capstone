import { CommonModule } from '@angular/common'
import {
  Component,
  inject,
  signal,
  ChangeDetectionStrategy,
  OnInit,
  DestroyRef,
} from '@angular/core'
import { takeUntilDestroyed } from '@angular/core/rxjs-interop'
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router'
import { ButtonModule } from 'primeng/button'
import { InputTextModule } from 'primeng/inputtext'
import { PasswordModule } from 'primeng/password'
import { CardModule } from 'primeng/card'
import { MessageModule } from 'primeng/message'
import { ProgressSpinnerModule } from 'primeng/progressspinner'
import { AuthService } from '@core'
import { passwordsMatchValidator } from '@core'
import { TagModule } from 'primeng/tag'

/**
 * Component for account activation from invitation email.
 * Allows new users to set their password and complete profile.
 */
@Component({
  selector: 'tenant-activate',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    PasswordModule,
    CardModule,
    MessageModule,
    ProgressSpinnerModule,
    TagModule,
  ],
  templateUrl: './activate.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Activate implements OnInit {
  private readonly fb = inject(FormBuilder)
  private readonly route = inject(ActivatedRoute)
  private readonly router = inject(Router)
  private readonly authService = inject(AuthService)
  private readonly destroyRef = inject(DestroyRef)

  readonly isLoading = signal(false)
  readonly serverError = signal<string | null>(null)
  readonly token = signal<string>('')
  readonly tokenData = signal<{
    email: string
    firstName?: string
    lastName?: string
    roles: string[]
    tenantId: string
    userId: string
    inviterId?: string
    type: string
  } | null>(null)

  readonly activateForm = this.fb.group(
    {
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      phone: [''],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: passwordsMatchValidator }
  )

  /**
   * Initialize component and extract token from URL.
   */
  ngOnInit(): void {
    const tokenParam = this.route.snapshot.queryParams['token']
    if (tokenParam) {
      try {
        const parts = tokenParam.split('.')
        if (parts.length !== 3) {
          throw new Error('Invalid token format')
        }

        const payload = JSON.parse(atob(parts[1]))

        if (payload.exp && payload.exp * 1000 < Date.now()) {
          this.serverError.set($localize`:@@tokenExpired:Activation link has expired`)
          return
        }

        const tokenData = {
          email: payload.email || '',
          firstName: payload.firstName || payload.first_name || '',
          lastName: payload.lastName || payload.last_name || '',
          roles: payload.roles || [],
          tenantId: payload.tenantId || '',
          userId: payload.userId || '',
          inviterId: payload.inviterId || payload.inviteId,
          type: payload.type || '',
        }

        this.tokenData.set(tokenData)
        this.token.set(tokenParam)

        this.preloadForm(tokenData)
      } catch (error) {
        console.error('Token validation error:', error)
        this.serverError.set($localize`:@@invalidToken:Invalid activation token`)
      }
    } else {
      this.serverError.set($localize`:@@invalidActivationLink:Invalid activation link`)
    }
  }

  /**
   * Preload form with data from token.
   * @param tokenData The decoded token data containing email, names and roles.
   * @param tokenData.email The user's email address.
   * @param tokenData.firstName The user's first name.
   * @param tokenData.lastName The user's last name.
   * @param tokenData.roles The user's assigned roles.
   */
  private preloadForm(tokenData: {
    email: string
    firstName?: string
    lastName?: string
    roles: string[]
  }): void {
    console.log('Token data extracted:', {
      email: tokenData.email,
      firstName: tokenData.firstName,
      lastName: tokenData.lastName,
      roles: tokenData.roles,
      hasValidData: !!(
        tokenData.email ||
        tokenData.firstName ||
        tokenData.lastName ||
        tokenData.roles.length > 0
      ),
    })

    if (tokenData.firstName) {
      this.activateForm.patchValue({ firstName: tokenData.firstName })
    }
    if (tokenData.lastName) {
      this.activateForm.patchValue({ lastName: tokenData.lastName })
    }
  }

  /**
   * Handles the form submission for account activation.
   * Validates the form, sends activation request to the server,
   * and handles success/error responses appropriately.
   */
  async onSubmit(): Promise<void> {
    this.activateForm.markAllAsTouched()
    if (this.activateForm.invalid || !this.token()) return

    this.serverError.set(null)
    this.isLoading.set(true)

    const { firstName, lastName, phone, password } = this.activateForm.getRawValue()

    const activateData = {
      token: this.token(),
      password: password!,
      firstName: firstName!,
      lastName: lastName!,
      phone: phone || undefined,
    }

    this.authService
      .activateUser(activateData)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          this.isLoading.set(false)
          this.router.navigate(['/auth/sign-in'], {
            queryParams: { message: 'account_activated' },
          })
        },
        error: (err: unknown) => {
          this.isLoading.set(false)

          if (err && typeof err === 'object' && 'status' in err) {
            const httpError = err as { status: number; error?: { message?: string } }

            if (httpError.status === 0) {
              this.serverError.set(
                $localize`:@@connectionError:Cannot connect to server. Please check your internet connection.`
              )
            } else if (httpError.status === 400) {
              this.serverError.set(
                httpError.error?.message ||
                  $localize`:@@invalidToken:Invalid or expired activation token`
              )
            } else if (httpError.status === 404) {
              this.serverError.set(
                $localize`:@@serverNotFound:Server not found. Please check if the backend is running.`
              )
            } else if (httpError.status === 409) {
              this.serverError.set($localize`:@@accountAlreadyActive:Account is already active`)
            } else if (httpError.status >= 500) {
              this.serverError.set($localize`:@@serverError:Server error. Please try again later.`)
            } else {
              this.serverError.set(
                $localize`:@@activationFailed:Activation failed. Please try again.`
              )
            }
          } else {
            this.serverError.set(
              $localize`:@@activationFailed:Activation failed. Please try again.`
            )
          }
        },
      })
  }
}
