import { inject } from '@angular/core'
import { CanActivateFn, Router } from '@angular/router'
import { AuthService } from '@core'
import { map, take } from 'rxjs/operators'
import { Observable, of } from 'rxjs'
import type { TenantRole, PlatformRole } from '@core'

/**
 * Configuration for authorization guard.
 */
export interface AuthGuardConfig {
  requiredTenantRoles?: TenantRole[]
  requiredPlatformRoles?: PlatformRole[]
  allowSuperAdminBypass?: boolean
}

/**
 * Helper function to check authentication.
 * @returns True if authenticated, false otherwise (redirects to sign-in).
 */
function checkAuthentication(): boolean {
  const authService = inject(AuthService)
  const router = inject(Router)

  const isAuthenticated = authService.isAuthenticated()
  const currentUser = authService.currentUser()

  if (!isAuthenticated || !currentUser) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}

/**
 * Helper function to check tenant role authorization.
 * @param config Authorization configuration.
 * @returns True if authorized, false otherwise.
 */
function checkTenantAuthorization(config: AuthGuardConfig): boolean {
  const authService = inject(AuthService)
  const router = inject(Router)

  const currentUser = authService.currentUser()!
  const currentTenantId = authService.getCurrentTenantId()

  if (!currentTenantId) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  const tenantRole = currentUser.tenantRoles?.find((tr) => tr.tenantId === currentTenantId)

  const hasRequiredTenantRole =
    config.requiredTenantRoles?.some((role) => tenantRole?.role === role) ?? true // If no roles required, pass

  const isSuperAdmin = currentUser.globalRole === ('super_admin' as PlatformRole)
  const superAdminBypass = config.allowSuperAdminBypass && isSuperAdmin

  if (!hasRequiredTenantRole && !superAdminBypass) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}

/**
 * Helper function to check platform role authorization.
 * @param config Authorization configuration.
 * @returns True if authorized, false otherwise.
 */
function checkPlatformAuthorization(config: AuthGuardConfig): boolean {
  const authService = inject(AuthService)
  const router = inject(Router)

  const currentUser = authService.currentUser()!

  const hasRequiredPlatformRole =
    config.requiredPlatformRoles?.some((role) => currentUser.globalRole === role) ?? true // If no roles required, pass

  if (!hasRequiredPlatformRole) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}

/**
 * Flexible authorization guard that can check authentication and role-based permissions.
 * @param config Configuration for authorization requirements.
 * @returns Guard function.
 */
export function authGuard(config: AuthGuardConfig = {}): CanActivateFn {
  return (): Observable<boolean> => {
    const authService = inject(AuthService)
    const router = inject(Router)

    if (!authService.isInitialized()) {
      return of(authService.isAuthenticated()).pipe(
        take(1),
        map((isAuth) => {
          if (!isAuth) {
            router.navigate(['auth', 'sign-in'])
            return false
          }

          if (config.requiredTenantRoles || config.requiredPlatformRoles) {
            return checkTenantAuthorization(config) && checkPlatformAuthorization(config)
          }

          return true
        })
      )
    }

    if (!checkAuthentication()) {
      return of(false)
    }

    if (config.requiredTenantRoles || config.requiredPlatformRoles) {
      if (!checkTenantAuthorization(config) || !checkPlatformAuthorization(config)) {
        return of(false)
      }
    }

    return of(true)
  }
}

/**
 * Legacy auth guard for backward compatibility.
 * Only checks authentication, no role validation.
 * @deprecated Use authGuard() with config instead.
 */
export const AuthGuard: CanActivateFn = authGuard()

/**
 * Pre-configured guard for owner/admin tenant roles.
 * Equivalent to the old ownerGuard.
 */
export const ownerAuthGuard: CanActivateFn = authGuard({
  requiredTenantRoles: ['owner', 'admin'],
  allowSuperAdminBypass: true,
})

/**
 * Pre-configured guard for platform admin roles.
 */
export const platformAdminAuthGuard: CanActivateFn = authGuard({
  requiredPlatformRoles: ['platform-admin', 'super_admin'],
})
