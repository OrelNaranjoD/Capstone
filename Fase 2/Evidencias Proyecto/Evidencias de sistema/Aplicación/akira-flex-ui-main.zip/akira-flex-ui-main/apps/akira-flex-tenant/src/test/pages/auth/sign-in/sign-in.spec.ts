import { ComponentFixture, TestBed } from '@angular/core/testing'
import { ReactiveFormsModule } from '@angular/forms'
import { Router } from '@angular/router'
import { ActivatedRoute } from '@angular/router'
import { provideHttpClient } from '@angular/common/http'
import { Store } from '@ngrx/store'
import { of } from 'rxjs'
import { SignIn } from '../../../../app/pages/auth/sign-in/sign-in'
import { AuthService, GlobalConfigService, APP_COOKIE_PREFIX } from '@core'

describe('SignIn', () => {
  let component: SignIn
  let fixture: ComponentFixture<SignIn>

  beforeEach(async () => {
    TestBed.resetTestingModule()
    const mockStore = {
      select: vi.fn(),
      dispatch: vi.fn(),
      selectSignal: vi.fn(() => vi.fn(() => null)),
    }
    await TestBed.configureTestingModule({
      imports: [SignIn, ReactiveFormsModule],
      providers: [
        provideHttpClient(),
        AuthService,
        Router,
        { provide: APP_COOKIE_PREFIX, useValue: 'tenant' },
        { provide: Store, useValue: mockStore },
        {
          provide: GlobalConfigService,
          useValue: {
            configureApiEndpoints: vi.fn(),
            configureApiBaseUrl: vi.fn(),
            configureTenantSubdomain: vi.fn(),
            apiEndpoints: {
              auth: {
                login: '/api/v1/tenants/auth/login',
              },
            },
          },
        },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: { params: {}, queryParams: {} },
            params: of({}),
            queryParams: of({}),
          },
        },
      ],
    }).compileComponents()

    fixture = TestBed.createComponent(SignIn)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })

  it('should initialize form with empty values', () => {
    expect(component.signInForm.get('email')?.value).toBe('')
    expect(component.signInForm.get('password')?.value).toBe('')
  })

  it('should validate email field as required', () => {
    const emailControl = component.signInForm.get('email')
    emailControl?.setValue('')
    emailControl?.markAsTouched()
    expect(emailControl?.hasError('required')).toBe(true)
  })

  it('should validate email format', () => {
    const emailControl = component.signInForm.get('email')
    emailControl?.setValue('invalid-email')
    emailControl?.markAsTouched()
    expect(emailControl?.hasError('invalidEmail')).toBe(true)
  })

  it('should validate password minimum length', () => {
    const passwordControl = component.signInForm.get('password')
    passwordControl?.setValue('short')
    expect(passwordControl?.hasError('minlength')).toBe(true)
  })

  it('should not submit if form is invalid', () => {
    component.signInForm.get('email')?.setValue('')
    component.signInForm.get('password')?.setValue('')
    component.onSubmit()
    expect(component.signInForm.valid).toBe(false)
  })

  it('should handle login error with invalid credentials', async () => {
    component.signInForm.get('email')?.setValue('wrong@tenant.com')
    component.signInForm.get('password')?.setValue('wrongpassword')
    component.onSubmit()
    await new Promise((resolve) => setTimeout(resolve, 1100))
    expect(component.errorMessage()).toBeTruthy()
  })

  it('should display company data', () => {
    expect(component.companyData).toBeDefined()
    expect(component.companyData.name).toBeDefined()
  })
})
