import { Component, input, output, inject, signal } from '@angular/core'
import { CommonModule } from '@angular/common'
import {
  ReactiveFormsModule,
  FormsModule,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms'
import { ButtonModule } from 'primeng/button'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { TextareaModule } from 'primeng/textarea'
import { CheckboxModule } from 'primeng/checkbox'
import { InviteUserRequest, TenantRole } from '@core'

/**
 * Dialog component for inviting users to the tenant.
 */
@Component({
  selector: 'tenant-invite-user-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    TextareaModule,
    CheckboxModule,
  ],
  templateUrl: './invite-user-dialog.html',
})
export class InviteUserDialog {
  visible = input.required<boolean>()
  saving = input.required<boolean>()

  invite = output<{ formValue: InviteUserRequest }>()
  visibleChange = output<boolean>()

  readonly inviteForm: FormGroup
  readonly selectedRoles = signal<TenantRole[]>(['user'])

  readonly availableTenantRoles = [
    { value: 'owner' as TenantRole, label: $localize`:@@role.owner:Owner` },
    { value: 'admin' as TenantRole, label: $localize`:@@role.admin:Administrator` },
    { value: 'manager' as TenantRole, label: $localize`:@@role.manager:Manager` },
    { value: 'user' as TenantRole, label: $localize`:@@role.user:User` },
    { value: 'viewer' as TenantRole, label: $localize`:@@role.viewer:Viewer` },
  ]

  private readonly fb = inject(FormBuilder)

  constructor() {
    this.inviteForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      message: [''],
    })
  }

  /**
   * Gets the dialog visibility state.
   * @returns The current visibility state of the dialog.
   */
  get dialogVisible(): boolean {
    return this.visible()
  }

  /**
   * Sets the dialog visibility state and emits the change.
   */
  set dialogVisible(value: boolean) {
    this.visibleChange.emit(value)
  }

  /**
   * Handles form submission when sending user invitation.
   */
  onSubmit(): void {
    if (this.inviteForm.valid && this.selectedRoles().length > 0) {
      const formValue = this.inviteForm.value
      const inviteData: InviteUserRequest = {
        email: formValue.email,
        firstName: formValue.firstName,
        lastName: formValue.lastName,
        roles: this.selectedRoles().map((role) => role.toUpperCase() as TenantRole),
        message: formValue.message || undefined,
      }
      this.invite.emit({ formValue: inviteData })
    }
  }

  /**
   * Handles dialog cancellation and resets the form.
   */
  onCancel(): void {
    this.inviteForm.reset()
    this.selectedRoles.set(['user'])
    this.visibleChange.emit(false)
  }

  /**
   * Check if a role is selected.
   * @param role The role to check.
   * @returns True if the role is selected.
   */
  isRoleSelected(role: TenantRole): boolean {
    return this.selectedRoles().includes(role)
  }

  /**
   * Toggle a role selection.
   * @param role The role to toggle.
   * @param checked Whether the checkbox is checked.
   */
  toggleRole(role: TenantRole, checked: boolean) {
    if (role === 'owner') {
      return
    }

    const currentRoles = this.selectedRoles()

    if (checked) {
      if (!currentRoles.includes(role)) {
        this.selectedRoles.set([...currentRoles, role])
      }
    } else {
      const newRoles = currentRoles.filter((r) => r !== role)
      this.selectedRoles.set(newRoles)
    }
  }

  /**
   * Handle role checkbox change event.
   * @param role The role that changed.
   * @param checked The new checked state.
   */
  onRoleChange(role: TenantRole, checked: boolean): void {
    this.toggleRole(role, checked)
  }
}
