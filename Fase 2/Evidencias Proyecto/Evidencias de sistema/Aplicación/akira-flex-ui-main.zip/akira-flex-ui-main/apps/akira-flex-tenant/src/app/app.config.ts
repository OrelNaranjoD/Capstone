import {
  ApplicationConfig,
  provideBrowserGlobalErrorListeners,
  provideZonelessChangeDetection,
  provideAppInitializer,
  inject,
  isDevMode,
} from '@angular/core'
import { provideRouter } from '@angular/router'
import { ROUTES } from './app.routes'
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http'
import { provideClientHydration, withEventReplay } from '@angular/platform-browser'
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async'
import { providePrimeNG } from 'primeng/config'
import { provideState, provideStore } from '@ngrx/store'
import { provideEffects } from '@ngrx/effects'
import { provideStoreDevtools } from '@ngrx/store-devtools'
import {
  authInterceptor,
  errorInterceptor,
  systemStatusFeature,
  SystemStatusEffects,
  authFeature,
  GlobalConfigService,
  tenantInterceptor,
  baseUrlInterceptor,
  refreshTokenInterceptor,
  APP_COOKIE_PREFIX,
  AuthService,
  API_ENDPOINTS,
} from '@core'
import TealSlateTheme from './themes/custom-theme.preset'
import { environment } from '../environments/environment'
import { debugInterceptor } from './interceptors/debug.interceptor'

/**
 * Initialize application configuration.
 * @param globalConfig The global config service to configure.
 * @param authService The auth service to initialize.
 * @returns Promise that resolves when initialization is complete.
 */
function initializeApp(globalConfig: GlobalConfigService, authService: AuthService): Promise<void> {
  return new Promise((resolve) => {
    globalConfig.configureApiEndpoints(API_ENDPOINTS['tenant'])
    globalConfig.configureApiBaseUrl(environment.apiBaseUrl)
    globalConfig.configureTenantSubdomain(environment.tenantSubdomain)
    globalConfig.configureAppBaseUrl(environment.appBaseUrl)
    authService.initialize()
    resolve()
  })
}

export const appConfig: ApplicationConfig = {
  providers: [
    { provide: APP_COOKIE_PREFIX, useValue: 'tenant' },
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    ...(isDevMode() ? [] : [provideClientHydration(withEventReplay())]),
    provideRouter(ROUTES),
    provideHttpClient(
      withFetch(),
      withInterceptors([
        baseUrlInterceptor,
        tenantInterceptor,
        refreshTokenInterceptor,
        authInterceptor,
        errorInterceptor,
        debugInterceptor,
      ])
    ),
    provideAnimationsAsync(),
    providePrimeNG({
      ripple: true,
      theme: {
        preset: TealSlateTheme,
        options: {
          darkModeSelector: '.dark',
          prefix: 'p',
          cssLayer: {
            name: 'primeng',
            order: 'theme, base, primeng',
          },
        },
      },
    }),
    provideStore(),
    provideState(systemStatusFeature),
    provideState(authFeature),
    provideEffects(SystemStatusEffects),
    provideStoreDevtools({
      maxAge: 25,
      logOnly: !isDevMode(),
    }),
    provideAppInitializer(() => initializeApp(inject(GlobalConfigService), inject(AuthService))),
  ],
}
