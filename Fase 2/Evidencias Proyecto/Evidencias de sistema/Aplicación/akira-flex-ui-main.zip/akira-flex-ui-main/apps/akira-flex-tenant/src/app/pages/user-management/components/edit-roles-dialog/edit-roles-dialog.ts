import { Component, input, output, signal, effect } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ButtonModule } from 'primeng/button'
import { DialogModule } from 'primeng/dialog'
import { User, TenantRole, TenantRoleAssignment } from '@core'

/**
 * Edit user roles dialog component.
 * Allows editing tenant roles for an existing user.
 */
@Component({
  selector: 'tenant-edit-roles-dialog',
  standalone: true,
  imports: [CommonModule, ButtonModule, DialogModule],
  templateUrl: './edit-roles-dialog.html',
})
export class EditRolesDialog {
  readonly visible = input(false)
  readonly saving = input(false)
  readonly user = input<User | null>(null)
  readonly visibleChange = output<boolean>()
  readonly save = output<{ userId: string; roles: TenantRole[] }>()
  readonly selectedRoles = signal<TenantRole[]>([])
  readonly availableTenantRoles = [
    { value: 'admin' as TenantRole, label: $localize`:@@role.admin:Administrator` },
    { value: 'manager' as TenantRole, label: $localize`:@@role.manager:Manager` },
    { value: 'user' as TenantRole, label: $localize`:@@role.user:User` },
    { value: 'viewer' as TenantRole, label: $localize`:@@role.viewer:Viewer` },
  ]

  constructor() {
    effect(() => {
      const currentUser = this.user()
      if (currentUser) {
        const userRoles = currentUser.tenantRoles?.map((tr: TenantRoleAssignment) => tr.role) || []
        this.selectedRoles.set(userRoles)
      } else {
        this.selectedRoles.set([])
      }
    })
  }

  /**
   * Handle dialog visibility change.
   * @param visible Whether the dialog is visible.
   */
  onVisibleChange(visible: boolean) {
    this.visibleChange.emit(visible)
    if (!visible) {
      this.selectedRoles.set([])
    }
  }

  /**
   * Save role changes.
   */
  saveChanges() {
    if (this.user() && this.selectedRoles().length > 0) {
      this.save.emit({
        userId: this.user()!.id,
        roles: this.selectedRoles().map((role) => role.toUpperCase() as TenantRole),
      })
    }
  }

  /**
   * Check if a role is selected.
   * @param role The role to check.
   * @returns True if the role is selected.
   */
  isRoleSelected(role: TenantRole): boolean {
    return this.selectedRoles().includes(role)
  }

  /**
   * Toggle a role selection.
   * @param role The role to toggle.
   * @param event The change event.
   */
  toggleRole(role: TenantRole, event: Event) {
    const checkbox = event.target as HTMLInputElement
    const currentRoles = this.selectedRoles()

    if (checkbox.checked) {
      if (!currentRoles.includes(role)) {
        this.selectedRoles.set([...currentRoles, role])
      }
    } else {
      const newRoles = currentRoles.filter((r) => r !== role)
      if (newRoles.length > 0) {
        this.selectedRoles.set(newRoles)
      } else {
        checkbox.checked = true
      }
    }
  }
}
