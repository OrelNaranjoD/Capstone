import { inject } from '@angular/core'
import { Router, type CanActivateFn } from '@angular/router'
import { AuthService } from '@core'
import type { TenantRole, PlatformRole } from '@core'

/**
 * Helper function to check authentication.
 * @returns True if authenticated, false otherwise (redirects to sign-in).
 */
function checkAuthentication(): boolean {
  const authService = inject(AuthService)
  const router = inject(Router)

  const isAuthenticated = authService.isAuthenticated()
  const currentUser = authService.currentUser()

  if (!isAuthenticated || !currentUser) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}

/**
 * Guard to protect tenant owner/admin routes.
 * Checks if user has appropriate tenant role in current tenant.
 * Super admins can access as owner only if explicitly assigned by tenant owner.
 *
 * @returns True if user has owner/admin role in current tenant, false otherwise.
 */
export const ownerGuard: CanActivateFn = () => {
  const authService = inject(AuthService)
  const router = inject(Router)

  if (!checkAuthentication()) {
    return false
  }

  const currentUser = authService.currentUser()!

  const currentTenantId = authService.getCurrentTenantId()

  if (!currentTenantId) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  const tenantRole = currentUser.tenantRoles?.find((tr) => tr.tenantId === currentTenantId)

  const hasOwnerAccess =
    tenantRole?.role === ('owner' as TenantRole) || tenantRole?.role === ('admin' as TenantRole)

  const isSuperAdmin = currentUser.globalRole === ('super_admin' as PlatformRole)
  const superAdminHasExplicitAccess = isSuperAdmin && hasOwnerAccess

  if (!hasOwnerAccess && !superAdminHasExplicitAccess) {
    router.navigate(['/auth/sign-in'])
    return false
  }

  return true
}
