import {
  Component,
  computed,
  inject,
  signal,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { ReactiveFormsModule } from '@angular/forms'
import { ButtonModule } from 'primeng/button'
import { TableModule } from 'primeng/table'
import { DialogModule } from 'primeng/dialog'
import { InputTextModule } from 'primeng/inputtext'
import { TextareaModule } from 'primeng/textarea'
import { ToastModule } from 'primeng/toast'
import { ConfirmDialogModule } from 'primeng/confirmdialog'
import { ToolbarModule } from 'primeng/toolbar'
import { TagModule } from 'primeng/tag'
import { MessageModule } from 'primeng/message'
import { PaginatorModule } from 'primeng/paginator'
import { MessageService, ConfirmationService } from 'primeng/api'
import { PaginatorState } from 'primeng/paginator'
import {
  UserManagementService,
  AuthService,
  User,
  InviteUserRequest,
  CreateTenantUserRequest,
  UserListQuery,
  UserListResponse,
  TenantRole,
  RoleLabelPipe,
  RoleSeverityPipe,
} from '@core'

import { UserManagementStateService } from './user-management.service'

import { InviteUserDialog } from './components/invite-user-dialog/invite-user-dialog'
import { EditRolesDialog } from './components/edit-roles-dialog/edit-roles-dialog'
import { CreateUserDialog } from './components/create-user-dialog/create-user-dialog'

/**
 * @typedef {'invite' | 'create' | 'editRoles' | null} DialogType - The type of dialog currently active.
 */
type DialogType = 'invite' | 'create' | 'editRoles' | null

/**
 * Component for managing tenant users.
 * @description Manages users within a tenant, including invitations, role assignments, and status changes.
 */
@Component({
  selector: 'tenant-user-management',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ButtonModule,
    TableModule,
    DialogModule,
    InputTextModule,
    TextareaModule,
    ToastModule,
    ConfirmDialogModule,
    ToolbarModule,
    TagModule,
    MessageModule,
    PaginatorModule,
    RoleLabelPipe,
    RoleSeverityPipe,
    InviteUserDialog,
    EditRolesDialog,
    CreateUserDialog,
  ],
  templateUrl: './user-management.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserManagement implements OnInit {
  private readonly userManagementService = inject(UserManagementService)
  private readonly messageService = inject(MessageService)
  private readonly confirmationService = inject(ConfirmationService)
  private readonly authService = inject(AuthService)
  private readonly tenantUserState = inject(UserManagementStateService)
  private readonly cdr = inject(ChangeDetectorRef)

  readonly users = this.tenantUserState.users
  readonly loading = this.tenantUserState.loading
  readonly operationInProgress = signal(false)
  readonly selectedUser = signal<User | null>(null)
  readonly activeDialog = signal<DialogType>(null)

  readonly totalRecords = signal(0)
  readonly first = signal(0)
  readonly rows = signal(10)
  readonly rowsPerPageOptions = [10, 20, 30]

  readonly currentUser = this.authService.currentUser

  readonly isCurrentUserOwner = computed(() => {
    const user = this.currentUser()
    return user?.tenantRoles?.some((tr) => tr.role === 'owner') ?? false
  })

  readonly sortedUsers = computed(() => {
    const userList = this.users()
    return [...userList].sort((a, b) => {
      const aIsOwner = a.tenantRoles?.some((tr) => tr.role === 'owner') ?? false
      const bIsOwner = b.tenantRoles?.some((tr) => tr.role === 'owner') ?? false

      if (aIsOwner && !bIsOwner) return -1
      if (!aIsOwner && bIsOwner) return 1
      return 0
    })
  })

  /**
   * OnInit lifecycle hook.
   */
  ngOnInit() {
    if (this.tenantUserState.hasData() && !this.tenantUserState.isDataStale(5)) {
      this.totalRecords.set(this.tenantUserState.total())
      this.first.set((this.tenantUserState.page() - 1) * this.tenantUserState.limit())
      this.rows.set(this.tenantUserState.limit())
    } else {
      this.loadTenantUsers()
    }
  }

  /**
   * Opens a dialog.
   * @param dialog The type of dialog to open.
   * @param user Optional user to select when opening the dialog.
   */
  openDialog(dialog: DialogType, user?: User): void {
    if (user) this.selectedUser.set(user)
    this.activeDialog.set(dialog)
  }

  /**
   * Closes any active dialog.
   */
  closeDialog(): void {
    this.activeDialog.set(null)
    this.selectedUser.set(null)
  }

  /**
   * Loads users for the current tenant.
   * @param first First record index (0-based).
   * @param rows Number of records per page.
   */
  loadTenantUsers(first: number = 0, rows: number = 10): void {
    this.tenantUserState.setLoading(true)
    const page = Math.floor(first / rows) + 1
    const query: UserListQuery = {
      page,
      limit: rows,
    }

    this.userManagementService.getUsers(query).subscribe({
      next: (response: UserListResponse) => {
        const tenantUsers = response.users.filter((u) => u.tenantRoles?.length)
        const filteredResponse = {
          ...response,
          users: tenantUsers,
        }
        this.tenantUserState.refreshFromResponse(filteredResponse)
        this.totalRecords.set(response.total)
        this.first.set(first)
        this.rows.set(rows)
        this.cdr.detectChanges()
      },
      error: () =>
        this.showToast(
          'error',
          $localize`:@@error:Error`,
          $localize`:@@failedToLoadTenantUsers:Failed to load tenant users`
        ),
      complete: () => this.tenantUserState.setLoading(false),
    })
  }

  /**
   * Reloads the current page of users.
   */
  public reloadCurrentPage(): void {
    this.loadTenantUsers(this.first(), this.rows())
  }

  /**
   * Handles page change events from the paginator.
   * @param event The page change event from PrimeNG Paginator.
   */
  onPageChange(event: PaginatorState): void {
    const first = event.first ?? 0
    const rows = event.rows ?? 10
    const page = Math.floor(first / rows) + 1
    const cachedPage = this.tenantUserState.getCachedPageIfFresh(page)
    if (cachedPage) {
      this.tenantUserState.setUsers(cachedPage)
      this.tenantUserState.setPage(page)
      this.tenantUserState.setLimit(rows)
      this.first.set(first)
      this.rows.set(rows)
      this.cdr.detectChanges()
    } else {
      this.loadTenantUsers(first, rows)
    }
  }

  /**
   * Gets the current tenant ID from the route parameters.
   * @param data The form values for the new user.
   * @param data.formValue The form values.
   */
  onInviteUser(data: { formValue: InviteUserRequest }): void {
    this.operationInProgress.set(true)
    this.userManagementService.inviteUser(data.formValue).subscribe({
      next: () => {
        this.showToast(
          'success',
          $localize`:@@success:Success`,
          $localize`:@@invitationSent:Invitation sent successfully`
        )
        this.reloadCurrentPage()
        this.closeDialog()
      },
      error: () =>
        this.showToast(
          'error',
          $localize`:@@error:Error`,
          $localize`:@@failedToSendInvitation:Failed to send invitation`
        ),
      complete: () => this.operationInProgress.set(false),
    })
  }

  /**
   * Shows a toast message.
   * @param data The form values for the new user.
   * @param data.formValue The form values.
   * @param data.formValue.firstName The first name of the user.
   * @param data.formValue.lastName The last name of the user.
   * @param data.formValue.email The email of the user.
   * @param data.formValue.role The role of the user.
   */
  onSaveUser(data: { formValue: CreateTenantUserRequest }): void {
    this.operationInProgress.set(true)
    this.userManagementService.createTenantUser(data.formValue).subscribe({
      next: () => {
        this.showToast(
          'success',
          $localize`:@@success:Success`,
          $localize`:@@tenantUserCreatedSuccess:Tenant user created successfully`
        )
        this.reloadCurrentPage()
        this.closeDialog()
      },
      error: () =>
        this.showToast(
          'error',
          $localize`:@@error:Error`,
          $localize`:@@tenantUserCreatedError:Failed to create tenant user`
        ),
      complete: () => this.operationInProgress.set(false),
    })
  }

  /**
   * Saves the roles assigned to a user.
   * @param data The user ID and roles to assign.
   * @param data.userId The ID of the user to update.
   * @param data.roles The roles to assign to the user.
   */
  onSaveUserRoles(data: { userId: string; roles: TenantRole[] }): void {
    this.operationInProgress.set(true)
    this.userManagementService.updateUserRoles(data.userId, data.roles).subscribe({
      next: (updatedUser) => {
        this.showToast(
          'success',
          $localize`:@@success:Success`,
          $localize`:@@userRolesUpdatedSuccessfully:User roles updated successfully`
        )
        this.tenantUserState.updateUser(updatedUser)
        this.closeDialog()
      },
      error: () =>
        this.showToast(
          'error',
          $localize`:@@error:Error`,
          $localize`:@@failedToUpdateUserRoles:Failed to update user roles`
        ),
      complete: () => this.operationInProgress.set(false),
    })
  }

  /**
   * Gets the join date of the user based on tenant role assignment or account creation date.
   * @param user The user to get the join date for.
   * @returns The join date as a string.
   */
  getUserJoinDate(user: User): string {
    const tenantRole = user.tenantRoles?.[0]
    return tenantRole?.assignedAt?.toString() || user.createdAt.toString()
  }

  /**
   * Gets the permissions for the specified user.
   * @param targetUser The user to get permissions for.
   * @returns The permissions for the user.
   */
  getPermissionsFor(targetUser: User): {
    canEdit: boolean
    canToggleStatus: boolean
    canRemove: boolean
    canBeOwner: boolean
  } {
    const currentUser = this.currentUser()
    const defaults = { canEdit: false, canToggleStatus: false, canRemove: false, canBeOwner: false }

    if (
      !currentUser ||
      currentUser.id === targetUser.id ||
      targetUser.tenantRoles?.some((tr) => tr.role === 'owner')
    ) {
      return defaults
    }

    const isCurrentUserAdminOrOwner =
      currentUser.tenantRoles?.some((tr) => ['owner', 'admin'].includes(tr.role)) ?? false

    return {
      canEdit: isCurrentUserAdminOrOwner,
      canToggleStatus: isCurrentUserAdminOrOwner,
      canRemove: isCurrentUserAdminOrOwner,
      canBeOwner: this.isCurrentUserOwner(),
    }
  }

  /**
   * Toggles the status of the specified user.
   * @param user The user to toggle the status for.
   */
  toggleUserStatus(user: User): void {
    const actionLabel = user.isActive
      ? $localize`:@@deactivate:deactivate`
      : $localize`:@@activate:activate`
    const confirmMessage = $localize`:@@confirmToggleUserStatus:Are you sure you want to ${actionLabel} user ${user.firstName}?`

    this.confirmAction(confirmMessage, () => {
      this.operationInProgress.set(true)
      const operation = user.isActive
        ? this.userManagementService.deactivateUser(user.id)
        : this.userManagementService.activateUser(user.id)

      operation.subscribe({
        next: (updatedUser) => {
          const successMessage = user.isActive
            ? $localize`:@@userDeactivatedSuccessfully:User deactivated successfully`
            : $localize`:@@userActivatedSuccessfully:User activated successfully`

          this.showToast('success', $localize`:@@success:Success`, successMessage)
          this.tenantUserState.updateUser(updatedUser)
        },
        error: () => {
          const errorMessage = user.isActive
            ? $localize`:@@failedToDeactivateUser:Failed to deactivate user`
            : $localize`:@@failedToActivateUser:Failed to activate user`

          this.showToast('error', $localize`:@@error:Error`, errorMessage)
        },
        complete: () => this.operationInProgress.set(false),
      })
    })
  }

  /**
   * Removes the specified user from the tenant.
   * @param user The user to remove.
   */
  confirmRemoveUser(user: User): void {
    this.confirmAction(
      $localize`:@@confirmRemoveUser:This will remove ${user.firstName} from the tenant. Are you sure?`,
      () => {
        this.operationInProgress.set(true)
        this.userManagementService.softDeleteUser(user.id).subscribe({
          next: () => {
            this.showToast(
              'success',
              $localize`:@@success:Success`,
              $localize`:@@userRemovedSuccessfully:User removed successfully`
            )
            this.tenantUserState.removeUser(user.id)
            if (this.selectedUser()?.id === user.id) this.selectedUser.set(null)
          },
          error: () =>
            this.showToast(
              'error',
              $localize`:@@error:Error`,
              $localize`:@@failedToRemoveUser:Failed to remove user`
            ),
          complete: () => this.operationInProgress.set(false),
        })
      },
      { acceptButtonStyleClass: 'p-button-danger', acceptLabel: $localize`:@@remove:Remove` }
    )
  }

  /**
   * Transfers ownership to the specified user.
   * @param newOwner The user to transfer ownership to.
   */
  transferOwnership(newOwner: User): void {
    this.confirmAction(
      $localize`:@@confirmTransferOwnership:Transfer ownership to ${newOwner.firstName}? This cannot be undone.`,
      () => {
        this.operationInProgress.set(true)
        this.userManagementService.transferOwnership(newOwner.id).subscribe({
          next: () => {
            this.showToast(
              'success',
              $localize`:@@success:Success`,
              $localize`:@@ownershipTransferredSuccessfully:Ownership transferred successfully`
            )
            this.reloadCurrentPage()
          },
          error: () =>
            this.showToast(
              'error',
              $localize`:@@error:Error`,
              $localize`:@@failedToTransferOwnership:Failed to transfer ownership`
            ),
          complete: () => this.operationInProgress.set(false),
        })
      },
      { acceptButtonStyleClass: 'p-button-danger', acceptLabel: $localize`:@@transfer:Transfer` }
    )
  }

  /**
   * Displays a toast notification.
   * @param severity The severity level of the toast.
   * @param summary The summary text for the toast.
   * @param detail The detailed text for the toast.
   */
  private showToast(
    severity: 'success' | 'error' | 'info' | 'warn',
    summary: string,
    detail: string
  ): void {
    this.messageService.add({ severity, summary, detail, life: 3000 })
  }

  /**
   * Displays a confirmation dialog before performing an action.
   * @param message The confirmation message.
   * @param accept The function to execute on acceptance.
   * @param options Additional dialog options.
   * @param options.acceptButtonStyleClass CSS class for the accept button.
   * @param options.acceptLabel Label for the accept button.
   */
  private confirmAction(
    message: string,
    accept: () => void,
    options: { acceptButtonStyleClass?: string; acceptLabel?: string } = {}
  ): void {
    this.confirmationService.confirm({
      message,
      header: $localize`:@@confirmAction:Confirm Action`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: options.acceptLabel || $localize`:@@yes:Yes`,
      rejectLabel: $localize`:@@no:No`,
      ...options,
      accept,
    })
  }
}
