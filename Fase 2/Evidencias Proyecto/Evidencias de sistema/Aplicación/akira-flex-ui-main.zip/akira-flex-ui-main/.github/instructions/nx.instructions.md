---
applyTo: '**'
---

# Akira Flex UI - NX Workspace Instructions

This project is an NX monorepo that uses Angular 18+ to develop multiple
applications related to Akira Flex. The structure is designed to maintain shared
code in a single consolidated library.

## Project Structure

### General Architecture

- **NX Monorepo**: Manages multiple applications and libraries in a single
  repository.
- **Package Manager**: npm
- **Framework**: Angular with standalone components, signals for local state,
  and NgRx for global state.
- **Shared Library**: `akira-flex-core` is the only shared library containing
  all reusable code.

### Main Directories

#### `apps/`

Contains the specific applications:

- `akira-flex-landing/`: Landing page application
- `akira-flex-platform/`: Main platform
- `akira-flex-tenant/`: Tenant application

Each application has its own TypeScript configuration, environment, and build
files.

#### `libs/`

Contains the consolidated shared library:

- `akira-flex-core/`: Single library with all shared code
  - `components/`: Reusable components (checkbox, loading, logotype, etc.)
  - `config/`: Environment configuration and variables
  - `services/`: Shared services (auth, theme, page-title)
  - `interceptors/`: HTTP interceptors (auth, error)
  - `utils/`: Utilities (cookies, delays)
  - `public/`: Shared assets (favicon, fonts, styles)

### How It Works

#### Dependency Management

- NX automatically handles dependencies between projects.
- The `akira-flex-core` library is imported using the `@shared` alias configured
  in `tsconfig.base.json`.
- All applications depend on `akira-flex-core` for common components, services,
  and utilities.

#### Environment Variables

- Environment variables are defined in `environment.ts` files in each
  application.
- Variables are injected into applications using Angular's `environment.ts`
  files.
- API endpoints are configured per application using the `GlobalConfigService`.
- Each app defines its own `api-endpoints.ts` file in `src/app/config/`.

#### Build and Development

- NX Commands: `npx nx build <app>`, `npx nx serve <app>`, `npx nx test <lib>`.
- Each application can run independently but shares the core library.
- Builds generate optimized bundles with tree-shaking.

## Development Guides

### Code Generation

If the user wants to generate something new:

1. Use `nx_workspace` to understand the current structure.
2. List available generators with `nx_generators`.
3. Get the generator schema with `nx_generator_schema`.
4. Open the generation UI with `nx_open_generate_ui`.
5. Review the log with `nx_read_generator_log` after generation.

### Running Tasks

For tasks like build, test, lint:

1. Use `nx_current_running_tasks_details` to see active tasks.
2. If there are errors, use `nx_current_running_task_output` for details.
3. Re-run with `nx run <taskId>` if necessary.
4. Do not re-run continuous tasks (like serve).

### Environment Configuration

- Use Angular's `environment.ts` files for environment-specific configuration.
- Configure API endpoints using the `GlobalConfigService` pattern:
  - Each app has its own `src/app/config/api-endpoints.ts` file
  - Endpoints are configured via `provideAppInitializer` in `app.config.ts`
  - The shared `AuthService` reads endpoints from `GlobalConfigService`
- This approach maintains app separation while sharing common services.

### Best Practices

- Keep `akira-flex-core` as the only shared library.
- Use standalone components and signals.
- Follow naming conventions: kebab-case for files, PascalCase for classes.
- Document with JSDoc in English.
- Maintain test coverage >80%.
