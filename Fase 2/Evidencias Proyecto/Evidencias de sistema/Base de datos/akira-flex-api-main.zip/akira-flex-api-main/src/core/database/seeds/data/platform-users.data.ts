/**
 * Platform users data for seeding.
 */
export const PLATFORM_USERS_DATA = [
  {
    email: 'admin@akiraflex.com',
    firstName: 'Platform',
    lastName: 'Administrator',
    phone: '+525566667777',
    roleName: 'SUPER_ADMIN',
  },
  {
    email: 'auditor@akiraflex.com',
    firstName: 'Platform',
    lastName: 'Auditor',
    phone: '+525566668888',
    roleName: 'AUDITOR',
  },
  {
    email: 'landing@akiraflex.com',
    firstName: 'Landing',
    lastName: 'User',
    phone: '+525566668888',
    roleName: 'USER',
  },
];
