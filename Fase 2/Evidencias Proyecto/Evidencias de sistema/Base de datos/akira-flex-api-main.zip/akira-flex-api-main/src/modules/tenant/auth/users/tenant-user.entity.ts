import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  BeforeInsert,
  BeforeUpdate,
} from 'typeorm';
import * as bcrypt from 'bcrypt';
import { TenantUserEntity } from '@orelnaranjod/flex-shared-lib';

/**
 * Represents a tenant user within a specific company.
 * @class TenantUser
 */
@Entity('user_tenants')
export class TenantUser implements TenantUserEntity {
  /**
   * Unique identifier for the user.
   * @type {string}
   */
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /**
   * User email address.
   * @type {string}
   */
  @Column({ type: 'varchar', unique: true })
  email: string;

  /**
   * Hashed user password.
   * @type {string}
   */
  @Column({ type: 'varchar' })
  password: string;

  /**
   * User first name.
   * @type {string}
   */
  @Column({ type: 'varchar', name: 'first_name' })
  firstName: string;

  /**
   * User last name.
   * @type {string}
   */
  @Column({ type: 'varchar', name: 'last_name' })
  lastName: string;

  /**
   * User phone number.
   * @type {string}
   */
  @Column({ type: 'varchar', nullable: true })
  phone: string;

  /**
   * User roles within the tenant.
   * @type {string[]}
   */
  @Column('simple-array', { default: 'USER' })
  roles: string[];

  /**
   * User activation status.
   * @type {boolean}
   */
  @Column({ type: 'boolean', default: true })
  active: boolean;

  /**
   * ID of the tenant this user belongs to.
   * @type {string}
   */
  @Column({ name: 'tenant_id', type: 'uuid' })
  tenantId: string;

  /**
   * Date when the user was created.
   * @type {Date}
   */
  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  /**
   * Date when the user was last updated.
   * @type {Date}
   */
  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  /**
   * Date of last successful login.
   * @type {Date}
   */
  @Column({ type: 'timestamp', name: 'last_login', nullable: true })
  lastLogin: Date;

  /**
   * Hashed refresh token for token rotation.
   * @type {string}
   */
  @Column({ type: 'varchar', name: 'refresh_token_hash', nullable: true })
  refreshTokenHash: string | null;

  /**
   * Hashes password before inserting or updating into database.
   * @private
   */
  @BeforeInsert()
  @BeforeUpdate()
  async hashPassword() {
    if (this.password && !this.password.startsWith('$2b$')) {
      this.password = await bcrypt.hash(this.password, 10);
    }
  }

  /**
   * Compares provided password with stored hash.
   * @param {string} password - Password to compare.
   * @returns {Promise<boolean>} True if passwords match.
   */
  async comparePassword(password: string): Promise<boolean> {
    return bcrypt.compare(password, this.password);
  }
}
